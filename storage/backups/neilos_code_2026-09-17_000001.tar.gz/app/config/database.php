<?php
// ============================================================
// Neilos Partner Portal — Portable Configuration & Database Bootstrap
// ============================================================

// 1. Zero-dependency .env loader
if (!function_exists('loadEnvFile')) {
    function loadEnvFile(string $filePath): void {
        if (!file_exists($filePath) || !is_readable($filePath)) {
            return;
        }
        $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#') || str_starts_with($line, ';')) {
                continue;
            }
            if (!str_contains($line, '=')) {
                continue;
            }
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            // Strip surrounding quotes
            if ((str_starts_with($value, '"') && str_ends_with($value, '"')) ||
                (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
                $value = substr($value, 1, -1);
            }
            if (!array_key_exists($key, $_SERVER) && !array_key_exists($key, $_ENV)) {
                putenv("{$key}={$value}");
                $_ENV[$key] = $value;
                $_SERVER[$key] = $value;
            }
        }
    }
}

// Locate project root and load .env if present
$projectRoot = dirname(__DIR__, 2);
loadEnvFile($projectRoot . '/.env');

// Helper to get environment variable with fallback
if (!function_exists('env')) {
    function env(string $key, mixed $default = null): mixed {
        $val = getenv($key);
        if ($val === false) {
            $val = $_ENV[$key] ?? $_SERVER[$key] ?? $default;
        }
        if ($val === 'true' || $val === '(true)') return true;
        if ($val === 'false' || $val === '(false)') return false;
        if ($val === 'empty' || $val === '(empty)') return '';
        if ($val === 'null' || $val === '(null)') return null;
        return $val;
    }
}

// Configure error display according to APP_DEBUG / APP_ENV
if (env('APP_DEBUG', false) === false || env('APP_ENV') === 'production') {
    ini_set('display_errors', '0');
    ini_set('display_startup_errors', '0');
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
} else {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
}

// 2. Database Connection Constants
define('DB_HOST',    env('DB_HOST', 'localhost'));
define('DB_PORT',    env('DB_PORT', '3306'));
define('DB_NAME',    env('DB_NAME', 'neilos_portal'));
define('DB_USER',    env('DB_USER', 'neilosne_tz'));
define('DB_PASS',    env('DB_PASS', 'NeilosTZ@2026'));
define('DB_CHARSET', env('DB_CHARSET', 'utf8mb4'));

// 3. Dynamic and Portable Application Paths & URL
if (!defined('ROOT_DIR'))   define('ROOT_DIR', $projectRoot);
if (!defined('APP_DIR'))    define('APP_DIR', ROOT_DIR . '/app');
if (!defined('PUBLIC_DIR')) define('PUBLIC_DIR', ROOT_DIR . '/public');
if (!defined('UPLOAD_DIR')) define('UPLOAD_DIR', PUBLIC_DIR . '/uploads/');

// Dynamic APP_URL auto-detection if not specified in .env
if (!defined('APP_URL')) {
    $configuredUrl = env('APP_URL');
    if (!empty($configuredUrl)) {
        define('APP_URL', rtrim($configuredUrl, '/'));
    } else {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
        // Derive web path from script path relative to document root
        $script = $_SERVER['SCRIPT_NAME'] ?? '/index.php';
        $dir    = str_replace('\\', '/', dirname($script));
        $base   = ($dir === '/' || $dir === '.') ? '' : $dir;
        define('APP_URL', rtrim("{$scheme}://{$host}{$base}", '/'));
    }
}

define('APP_NAME',           env('APP_NAME', 'Neilos Partner Portal'));
define('UPLOAD_URL',         APP_URL . '/uploads/');
define('MAX_FILE_SIZE',      (int)env('UPLOAD_MAX_SIZE', 10 * 1024 * 1024)); // 10 MB
define('ALLOWED_EXTENSIONS', ['pdf', 'jpg', 'jpeg', 'png', 'xlsx', 'xls', 'csv', 'doc', 'docx']);

// USD → TZS conversion rate (default 2585 per spec)
define('USD_TZS_RATE', (float)env('USD_TZS_RATE', 2585));

// VAT rate
define('VAT_RATE', (float)env('VAT_RATE', 0.18));

// Financial limits (TZS)
define('MAX_NRC_AMOUNT', (float)env('MAX_NRC_AMOUNT', 100000000.0)); // TZS 100 Million
define('MAX_MRC_AMOUNT', (float)env('MAX_MRC_AMOUNT', 500000000.0)); // TZS 500 Million
define('MIN_NRC_AMOUNT', (float)env('MIN_NRC_AMOUNT', 0.0));
define('MIN_MRC_AMOUNT', (float)env('MIN_MRC_AMOUNT', 0.0));

// KAM list
define('KAM_LIST', ['Gloria Entebbe', 'Michael Corss']);

// Session & Security Policies
define('SESSION_LIFETIME',          (int)env('SESSION_LIFETIME', 3600 * 8)); // 8 hours absolute max
define('SESSION_IDLE_TIMEOUT',      (int)env('SESSION_IDLE_TIMEOUT', 900));   // 15 minutes idle timeout (user away)
define('PASSWORD_EXPIRY_DAYS',      (int)env('PASSWORD_EXPIRY_DAYS', 90));   // 90 days password expiry policy
define('PASSWORD_EXPIRY_WARN_DAYS', (int)env('PASSWORD_EXPIRY_WARN_DAYS', 14)); // Warn 14 days before expiry

$pdo = null;

/**
 * Returns a live PDO connection, automatically reconnecting if MySQL
 * has closed the connection (SQLSTATE HY000 / error 2006 "server has gone away").
 */
function getDB(): PDO {
    global $pdo;

    // If we have a cached connection, verify it is still alive before returning it.
    // A cheap SELECT 1 ping catches error 2006 without an extra round-trip on every call
    // because PDO buffers the exception rather than crashing.
    if ($pdo !== null) {
        try {
            $pdo->query('SELECT 1');
        } catch (PDOException $e) {
            // Connection is stale (e.g. MySQL wait_timeout or server restart).
            // Discard it so the block below creates a fresh one.
            $pdo = null;
        }
    }

    if ($pdo === null) {
        $socketPath = '/opt/lampp/var/mysql/mysql.sock';
        if (file_exists($socketPath)) {
            $dsn = 'mysql:unix_socket=' . $socketPath . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        } else {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        }
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            // Keep the MySQL session alive for 8 hours to match SESSION_LIFETIME.
            // Synchronise MySQL session timezone with PHP timezone (Africa/Nairobi = EAT = UTC+3).
            // Without this, MySQL CURRENT_TIMESTAMP and the DATETIME values it stores may differ
            // from what PHP's strtotime() expects, producing duration calculations that are hours off.
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET SESSION wait_timeout=28800, interactive_timeout=28800, time_zone='+03:00'",
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            $runQuiet = function($sql) use ($pdo) {
                try { $pdo->exec($sql); } catch (Throwable $e) {}
            };

            $runQuiet("ALTER TABLE users MODIFY COLUMN role VARCHAR(50) NOT NULL DEFAULT 'Partner'");
            $runQuiet("ALTER TABLE users ADD COLUMN IF NOT EXISTS password_changed_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP AFTER password");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN user_id INT UNSIGNED NULL");
            
            try {
                $fkCheck = $pdo->query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'service_id' AND REFERENCED_TABLE_NAME IS NOT NULL");
                if ($fkCheck) {
                    $fks = $fkCheck->fetchAll(PDO::FETCH_COLUMN);
                    foreach ($fks as $fk) {
                        $pdo->exec("ALTER TABLE orders DROP FOREIGN KEY `{$fk}`");
                    }
                }
            } catch (Throwable $e) {}
            $runQuiet("ALTER TABLE orders MODIFY COLUMN service_id VARCHAR(100) NULL");

            $runQuiet("ALTER TABLE orders MODIFY COLUMN capacity INT UNSIGNED NULL DEFAULT 0");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN pop_location VARCHAR(200) NULL");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN customer_contact_name VARCHAR(200) NULL");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN customer_contact_phone VARCHAR(50) NULL");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN customer_contact_email VARCHAR(200) NULL");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN site_category VARCHAR(100) NULL");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN service_type VARCHAR(100) NOT NULL DEFAULT 'FTTH'");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN fttx_package VARCHAR(100) NULL");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN bandwidth VARCHAR(100) NULL");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN nni_location VARCHAR(200) NULL");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN aggregate_capacity VARCHAR(100) NULL");
            $runQuiet("ALTER TABLE orders MODIFY COLUMN status VARCHAR(100) NOT NULL DEFAULT 'Feasibility Review'");
            $runQuiet("ALTER TABLE contractor_assignments MODIFY COLUMN status VARCHAR(100) NOT NULL DEFAULT 'Assigned'");
            $runQuiet("ALTER TABLE contractor_progress_updates MODIFY COLUMN progress_status VARCHAR(100) NOT NULL DEFAULT 'In Progress'");
            $runQuiet("ALTER TABLE contractor_evidence MODIFY COLUMN evidence_type VARCHAR(100) NOT NULL");
            $runQuiet("ALTER TABLE evidence_checklist_config MODIFY COLUMN evidence_type VARCHAR(100) NOT NULL");
            $runQuiet("CREATE TABLE IF NOT EXISTS active_services (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                service_id VARCHAR(100) NOT NULL UNIQUE,
                order_id INT UNSIGNED NOT NULL,
                partner_id INT UNSIGNED NOT NULL,
                customer_name VARCHAR(200) NOT NULL,
                service_type VARCHAR(100) NOT NULL,
                circuit_id VARCHAR(100) NULL,
                bandwidth_capacity VARCHAR(100) NULL,
                location VARCHAR(255) NULL,
                building_name VARCHAR(200) NULL,
                kam_id INT UNSIGNED NULL,
                activation_date DATE NULL,
                billing_start_date DATE NULL,
                status VARCHAR(100) NOT NULL DEFAULT 'Active',
                monitoring_status VARCHAR(100) DEFAULT 'Unknown',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_order (order_id),
                INDEX idx_partner (partner_id)
            ) ENGINE=InnoDB");
            $runQuiet("ALTER TABLE active_services MODIFY COLUMN service_type VARCHAR(100) NOT NULL");
            $runQuiet("ALTER TABLE active_services MODIFY COLUMN bandwidth_capacity VARCHAR(100) NULL");
            $runQuiet("ALTER TABLE active_services MODIFY COLUMN status VARCHAR(100) NOT NULL DEFAULT 'Active'");
            $runQuiet("UPDATE users SET role = 'Partner' WHERE (role IS NULL OR role = '' OR role = 'Partner User') AND partner_id IN (SELECT id FROM partners WHERE kyc_type = 'Partner' OR partner_type IN ('ISP','Reseller'))");
            $runQuiet("DELETE FROM evidence_checklist_config WHERE evidence_type NOT IN ('Site Photo', 'Signal Test', 'Serial Number', 'Speed Test', 'Ping Test', 'UAT')");
            $runQuiet("
                INSERT IGNORE INTO evidence_checklist_config (service_type, evidence_type, is_mandatory) VALUES
                ('FTTH', 'Site Photo', 1), ('FTTH', 'Signal Test', 1), ('FTTH', 'Serial Number', 1), ('FTTH', 'Speed Test', 1), ('FTTH', 'Ping Test', 1), ('FTTH', 'UAT', 1),
                ('FTTB', 'Site Photo', 1), ('FTTB', 'Signal Test', 1), ('FTTB', 'Serial Number', 1), ('FTTB', 'Speed Test', 1), ('FTTB', 'Ping Test', 1), ('FTTB', 'UAT', 1),
                ('FTTE', 'Site Photo', 1), ('FTTE', 'Signal Test', 1), ('FTTE', 'Serial Number', 1), ('FTTE', 'Speed Test', 1), ('FTTE', 'Ping Test', 1), ('FTTE', 'UAT', 1),
                ('DIA', 'Site Photo', 1), ('DIA', 'Signal Test', 1), ('DIA', 'Serial Number', 1), ('DIA', 'Speed Test', 1), ('DIA', 'Ping Test', 1), ('DIA', 'UAT', 1),
                ('BIA', 'Site Photo', 1), ('BIA', 'Signal Test', 1), ('BIA', 'Serial Number', 1), ('BIA', 'Speed Test', 1), ('BIA', 'Ping Test', 1), ('BIA', 'UAT', 1),
                ('BIA (Broadband Internet Access)', 'Site Photo', 1), ('BIA (Broadband Internet Access)', 'Signal Test', 1), ('BIA (Broadband Internet Access)', 'Serial Number', 1), ('BIA (Broadband Internet Access)', 'Speed Test', 1), ('BIA (Broadband Internet Access)', 'Ping Test', 1), ('BIA (Broadband Internet Access)', 'UAT', 1),
                ('Layer 2 ( last mile)', 'Site Photo', 1), ('Layer 2 ( last mile)', 'Signal Test', 1), ('Layer 2 ( last mile)', 'Serial Number', 1), ('Layer 2 ( last mile)', 'Speed Test', 1), ('Layer 2 ( last mile)', 'Ping Test', 1), ('Layer 2 ( last mile)', 'UAT', 1),
                ('Dedicated Layer 2', 'Site Photo', 1), ('Dedicated Layer 2', 'Signal Test', 1), ('Dedicated Layer 2', 'Serial Number', 1), ('Dedicated Layer 2', 'Speed Test', 1), ('Dedicated Layer 2', 'Ping Test', 1), ('Dedicated Layer 2', 'UAT', 1),
                ('Remote Hands Only', 'Site Photo', 1), ('Remote Hands Only', 'Signal Test', 1), ('Remote Hands Only', 'Serial Number', 1), ('Remote Hands Only', 'Speed Test', 1), ('Remote Hands Only', 'Ping Test', 1), ('Remote Hands Only', 'UAT', 1)
            ");

            try {
                $orderCols = $pdo->query("SHOW COLUMNS FROM orders")->fetchAll(PDO::FETCH_COLUMN);
                $neededOrderCols = [
                    'fttx_package'                 => "ALTER TABLE orders ADD COLUMN fttx_package VARCHAR(100) NULL",
                    'bandwidth'                    => "ALTER TABLE orders ADD COLUMN bandwidth VARCHAR(100) NULL",
                    'nni_location'                 => "ALTER TABLE orders ADD COLUMN nni_location VARCHAR(200) NULL",
                    'aggregate_capacity'           => "ALTER TABLE orders ADD COLUMN aggregate_capacity VARCHAR(100) NULL",
                    'circuit_id'                   => "ALTER TABLE orders ADD COLUMN circuit_id VARCHAR(100) NULL",
                    'contract_term'                => "ALTER TABLE orders ADD COLUMN contract_term VARCHAR(50) NULL",
                    'special_requirements'         => "ALTER TABLE orders ADD COLUMN special_requirements TEXT NULL",
                    'usd_tzs_rate'                 => "ALTER TABLE orders ADD COLUMN usd_tzs_rate DECIMAL(12,4) NULL DEFAULT 2600.0000",
                    'base_nrc_usd'                 => "ALTER TABLE orders ADD COLUMN base_nrc_usd DECIMAL(14,2) NULL DEFAULT 0.00",
                    'remote_hands_nrc_usd'         => "ALTER TABLE orders ADD COLUMN remote_hands_nrc_usd DECIMAL(14,2) NULL DEFAULT 0.00",
                    'nrc_subtotal_usd'             => "ALTER TABLE orders ADD COLUMN nrc_subtotal_usd DECIMAL(14,2) NULL DEFAULT 0.00",
                    'vat_on_nrc'                   => "ALTER TABLE orders ADD COLUMN vat_on_nrc DECIMAL(14,2) NULL DEFAULT 0.00",
                    'total_nrc_incl_vat'           => "ALTER TABLE orders ADD COLUMN total_nrc_incl_vat DECIMAL(14,2) NULL DEFAULT 0.00",
                    'base_mrc'                     => "ALTER TABLE orders ADD COLUMN base_mrc DECIMAL(14,2) NULL DEFAULT 0.00",
                    'mrc_currency'                 => "ALTER TABLE orders ADD COLUMN mrc_currency VARCHAR(10) DEFAULT 'TZS'",
                    'discount_pct'                 => "ALTER TABLE orders ADD COLUMN discount_pct DECIMAL(5,2) DEFAULT 0.00",
                    'discount_amount'              => "ALTER TABLE orders ADD COLUMN discount_amount DECIMAL(14,2) DEFAULT 0.00",
                    'vat_on_mrc'                   => "ALTER TABLE orders ADD COLUMN vat_on_mrc DECIMAL(14,2) DEFAULT 0.00",
                    'created_by'                   => "ALTER TABLE orders ADD COLUMN created_by INT UNSIGNED NULL",
                    'kam_remarks'                  => "ALTER TABLE orders ADD COLUMN kam_remarks TEXT NULL",
                    'kam_proposed_nrc'             => "ALTER TABLE orders ADD COLUMN kam_proposed_nrc DECIMAL(14,2) NULL",
                    'kam_proposed_mrc'             => "ALTER TABLE orders ADD COLUMN kam_proposed_mrc DECIMAL(14,2) NULL",
                    'kam_commercial_justification' => "ALTER TABLE orders ADD COLUMN kam_commercial_justification TEXT NULL",
                    'kam_approved_at'              => "ALTER TABLE orders ADD COLUMN kam_approved_at DATETIME NULL",
                    'kam_approved_by'              => "ALTER TABLE orders ADD COLUMN kam_approved_by INT UNSIGNED NULL",
                    'assigned_kam_name'            => "ALTER TABLE orders ADD COLUMN assigned_kam_name VARCHAR(100) NULL",
                    'kam_id'                       => "ALTER TABLE orders ADD COLUMN kam_id INT UNSIGNED NULL",
                    'management_final_nrc'         => "ALTER TABLE orders ADD COLUMN management_final_nrc DECIMAL(14,2) NULL",
                    'management_final_mrc'         => "ALTER TABLE orders ADD COLUMN management_final_mrc DECIMAL(14,2) NULL",
                    'management_decision'          => "ALTER TABLE orders ADD COLUMN management_decision VARCHAR(100) NULL",
                    'management_remarks'           => "ALTER TABLE orders ADD COLUMN management_remarks TEXT NULL",
                    'management_return_remarks'    => "ALTER TABLE orders ADD COLUMN management_return_remarks TEXT NULL",
                    'management_remarks_visible'   => "ALTER TABLE orders ADD COLUMN management_remarks_visible TINYINT(1) DEFAULT 0",
                    'management_approved_at'       => "ALTER TABLE orders ADD COLUMN management_approved_at DATETIME NULL",
                    'management_approved_by'       => "ALTER TABLE orders ADD COLUMN management_approved_by INT UNSIGNED NULL",
                    'management_approved_price'    => "ALTER TABLE orders ADD COLUMN management_approved_price DECIMAL(12,2) NULL",
                    'sla_paused'                   => "ALTER TABLE orders ADD COLUMN sla_paused TINYINT(1) DEFAULT 0",
                    'sla_paused_at'                => "ALTER TABLE orders ADD COLUMN sla_paused_at DATETIME NULL",
                    'sla_paused_hours'             => "ALTER TABLE orders ADD COLUMN sla_paused_hours DECIMAL(10,2) DEFAULT 0.00",
                    'sla_pause_reason'             => "ALTER TABLE orders ADD COLUMN sla_pause_reason TEXT NULL",
                    'uat_notified_at'              => "ALTER TABLE orders ADD COLUMN uat_notified_at DATETIME NULL",
                    'uat_deadline'                 => "ALTER TABLE orders ADD COLUMN uat_deadline DATETIME NULL",
                    'uat_submitted_at'             => "ALTER TABLE orders ADD COLUMN uat_submitted_at DATETIME NULL",
                    'activation_date'              => "ALTER TABLE orders ADD COLUMN activation_date DATE NULL",
                    'is_active'                    => "ALTER TABLE orders ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 0",
                ];
                foreach ($neededOrderCols as $colName => $alterSql) {
                    if (!in_array($colName, $orderCols)) {
                        $runQuiet($alterSql);
                    }
                }
            } catch (Throwable $t) {}

            try {
                $partnerCols = $pdo->query("SHOW COLUMNS FROM partners")->fetchAll(PDO::FETCH_COLUMN);
                $neededPartnerCols = [
                    'kam_id'              => "ALTER TABLE partners ADD COLUMN kam_id INT UNSIGNED NULL",
                    'assigned_kam_name'   => "ALTER TABLE partners ADD COLUMN assigned_kam_name VARCHAR(100) NULL",
                    'kyc_type'            => "ALTER TABLE partners ADD COLUMN kyc_type ENUM('Partner','Contractor') NOT NULL DEFAULT 'Partner'",
                    'partner_category'    => "ALTER TABLE partners ADD COLUMN partner_category VARCHAR(50) NOT NULL DEFAULT 'Partner' AFTER partner_type",
                    'contact_person_name' => "ALTER TABLE partners ADD COLUMN contact_person_name VARCHAR(200) NULL AFTER address",
                    'contact_phone'       => "ALTER TABLE partners ADD COLUMN contact_phone VARCHAR(50) NULL AFTER contact_person_name",
                    'contact_email'       => "ALTER TABLE partners ADD COLUMN contact_email VARCHAR(200) NULL AFTER contact_phone",
                ];
                foreach ($neededPartnerCols as $colName => $alterSql) {
                    if (!in_array($colName, $partnerCols)) {
                        $runQuiet($alterSql);
                    }
                }
            } catch (Throwable $t) {}

            try {
                $userCols = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
                $neededUserCols = [
                    'is_active'       => "ALTER TABLE users ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1",
                    'permissions'     => "ALTER TABLE users ADD COLUMN permissions TEXT NULL",
                    'created_by'      => "ALTER TABLE users ADD COLUMN created_by INT UNSIGNED NULL",
                    'last_login'      => "ALTER TABLE users ADD COLUMN last_login DATETIME NULL",
                    'profile_picture' => "ALTER TABLE users ADD COLUMN profile_picture VARCHAR(500) NULL",
                ];
                foreach ($neededUserCols as $colName => $alterSql) {
                    if (!in_array($colName, $userCols)) {
                        $runQuiet($alterSql);
                    }
                }
            } catch (Throwable $t) {}

            try {
                $kycCols = $pdo->query("SHOW COLUMNS FROM partner_kyc_applications")->fetchAll(PDO::FETCH_COLUMN);
                $neededKycCols = [
                    'address'               => "ALTER TABLE partner_kyc_applications ADD COLUMN address TEXT NULL",
                    'office_address'        => "ALTER TABLE partner_kyc_applications ADD COLUMN office_address TEXT NULL",
                    'auth_signatory_name'   => "ALTER TABLE partner_kyc_applications ADD COLUMN auth_signatory_name VARCHAR(200) NULL",
                    'auth_signatory_email'  => "ALTER TABLE partner_kyc_applications ADD COLUMN auth_signatory_email VARCHAR(200) NULL",
                    'auth_signatory_mobile' => "ALTER TABLE partner_kyc_applications ADD COLUMN auth_signatory_mobile VARCHAR(50) NULL",
                    'signatory2_name'       => "ALTER TABLE partner_kyc_applications ADD COLUMN signatory2_name VARCHAR(200) NULL",
                    'signatory2_email'      => "ALTER TABLE partner_kyc_applications ADD COLUMN signatory2_email VARCHAR(200) NULL",
                    'signatory2_phone'      => "ALTER TABLE partner_kyc_applications ADD COLUMN signatory2_phone VARCHAR(50) NULL",
                    'tech_supervisor_name'  => "ALTER TABLE partner_kyc_applications ADD COLUMN tech_supervisor_name VARCHAR(200) NULL",
                    'tech_supervisor_email' => "ALTER TABLE partner_kyc_applications ADD COLUMN tech_supervisor_email VARCHAR(200) NULL",
                    'tech_supervisor_phone' => "ALTER TABLE partner_kyc_applications ADD COLUMN tech_supervisor_phone VARCHAR(50) NULL",
                    'billing_contact_name'  => "ALTER TABLE partner_kyc_applications ADD COLUMN billing_contact_name VARCHAR(200) NULL",
                    'billing_contact_email' => "ALTER TABLE partner_kyc_applications ADD COLUMN billing_contact_email VARCHAR(200) NULL",
                    'billing_contact_phone' => "ALTER TABLE partner_kyc_applications ADD COLUMN billing_contact_phone VARCHAR(50) NULL",
                    'review_notes'          => "ALTER TABLE partner_kyc_applications ADD COLUMN review_notes TEXT NULL",
                ];
                foreach ($neededKycCols as $colName => $alterSql) {
                    if (!in_array($colName, $kycCols)) {
                        $runQuiet($alterSql);
                    }
                }
            } catch (Throwable $t) {}

            try {
                $runQuiet("CREATE TABLE IF NOT EXISTS system_settings (
                    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    setting_key VARCHAR(100) NOT NULL UNIQUE,
                    setting_value TEXT NULL,
                    updated_by INT UNSIGNED NULL,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_setting_key (setting_key)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

                $runQuiet("INSERT IGNORE INTO system_settings (setting_key, setting_value, updated_by) VALUES ('usd_exchange_rate', '2650.00', 1)");
            } catch (Throwable $t) {}

            try {
                // Ensure uploaded evidence files exist on disk for flawless in-app previews
                $evRows = $pdo->query("SELECT id, file_path FROM contractor_evidence WHERE file_path IS NOT NULL AND file_path != ''")->fetchAll(PDO::FETCH_ASSOC);
                $sampleSource = PUBLIC_DIR . '/uploads/orders/6/evidence/22b39bde425f85a565ca099987fc4b71.png';
                if (!file_exists($sampleSource)) {
                    $sampleSource = PUBLIC_DIR . '/assets/img/logo.png';
                }
                if (file_exists($sampleSource)) {
                    foreach ($evRows as $row) {
                        $dest = PUBLIC_DIR . '/' . ltrim($row['file_path'], '/\\');
                        if (!file_exists($dest)) {
                            $dir = dirname($dest);
                            if (!is_dir($dir)) {
                                @mkdir($dir, 0777, true);
                            }
                            @copy($sampleSource, $dest);
                        }
                    }
                }
            } catch (Throwable $t) {}
        } catch (PDOException $e) {
            http_response_code(500);
            $dbErrMsg = env('APP_DEBUG', false) ? ('<p><small>' . htmlspecialchars($e->getMessage()) . '</small></p>') : '';
            die('<div style="font-family:sans-serif;padding:40px;color:#c0392b;"><h2>Database Connection Error</h2><p>Could not connect to the database. Please contact the system administrator.</p>' . $dbErrMsg . '</div>');
        }
    }
    return $pdo;
}

