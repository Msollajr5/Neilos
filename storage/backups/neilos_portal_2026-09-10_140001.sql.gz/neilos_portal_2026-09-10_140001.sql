-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: neilos_portal
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `active_services`
--

DROP TABLE IF EXISTS `active_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `active_services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_id` varchar(100) NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `partner_id` int(10) unsigned NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `circuit_id` varchar(100) DEFAULT NULL,
  `bandwidth_capacity` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `building_name` varchar(200) DEFAULT NULL,
  `kam_id` int(10) unsigned DEFAULT NULL,
  `activation_date` date DEFAULT NULL,
  `billing_start_date` date DEFAULT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Active',
  `monitoring_status` varchar(100) DEFAULT 'Unknown',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_id` (`service_id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_partner` (`partner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `active_services`
--

LOCK TABLES `active_services` WRITE;
/*!40000 ALTER TABLE `active_services` DISABLE KEYS */;
INSERT INTO `active_services` VALUES (1,'SVC-260824-001',1,2,'Magari Mtaaani','Layer 2 ( last mile)','CKT-FR-260824-001','','Mwenge','Mwanga tower',2,'2026-08-24','2026-08-24','Active','Unknown','2026-08-24 21:30:19','2026-08-24 21:30:19'),(2,'SVC-260903-001',4,6,'patner A','Layer 2 ( last mile)','CKT-FR-260903-001','','sss','sss',NULL,'2026-09-03','2026-09-03','Active','Unknown','2026-09-03 11:11:33','2026-09-03 11:11:33'),(3,'SVC-260903-003',6,2,'Acme Telecom Ltd','FTTH','CKT-FR-260903-003','10','Msasani, Dar es Salaam','',2,'2026-09-07','2026-09-07','Active','Online','2026-09-07 08:51:30','2026-09-07 08:51:30'),(4,'SVC-260909-001',9,7,'BEN','Layer 2 ( last mile)','CKT-FR-260909-001','','LIBYA STREET','',NULL,'2026-09-09','2026-09-09','Active','Unknown','2026-09-09 10:42:06','2026-09-09 10:42:06');
/*!40000 ALTER TABLE `active_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `module` varchar(100) NOT NULL DEFAULT '',
  `record_id` int(10) unsigned DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_module` (`module`),
  KEY `idx_record` (`record_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=339 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-08-24 11:26:10'),(2,1,'Login','users',1,NULL,NULL,'197.186.8.30','2026-08-24 11:34:14'),(3,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-08-24 12:43:58'),(4,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-08-24 13:08:09'),(5,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-08-24 14:48:55'),(6,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-08-24 14:49:35'),(7,1,'Deleted KYC Application #1 (Fiber Works Ltd - Contractor)','kyc',1,NULL,NULL,'102.205.249.34','2026-08-24 15:52:45'),(8,1,'Login','users',1,NULL,NULL,'197.186.8.30','2026-08-24 20:26:45'),(9,1,'Updated Neilos company settings','neilos_company_info',1,NULL,NULL,'197.186.8.30','2026-08-24 20:35:03'),(10,7,'Login','users',7,NULL,NULL,'37.203.35.7','2026-08-24 20:36:40'),(11,3,'Login','users',3,NULL,NULL,'197.186.8.30','2026-08-24 20:37:17'),(12,2,'Login','users',2,NULL,NULL,'197.186.8.30','2026-08-24 20:37:35'),(13,11,'Login','users',11,NULL,NULL,'197.186.8.30','2026-08-24 20:37:54'),(14,13,'Login','users',13,NULL,NULL,'197.186.8.30','2026-08-24 20:38:10'),(15,1,'Updated partner Afrilink Solutions Ltd','partners',2,NULL,NULL,'197.186.8.30','2026-08-24 20:39:49'),(16,7,'KYC #3 Rejected. Reason: imekosewa','kyc',3,NULL,NULL,'37.203.35.7','2026-08-24 20:42:44'),(17,7,'KYC #3 Approved','kyc',3,NULL,NULL,'37.203.35.7','2026-08-24 20:48:34'),(18,7,'Created feasibility request FR-260824-001','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 20:54:41'),(19,3,'BSA marked technically feasible with NRC discount for order #1 — routed to Management','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 20:58:27'),(20,1,'User logged out','auth',1,NULL,NULL,'197.186.8.30','2026-08-24 21:02:31'),(21,10,'Login','users',10,NULL,NULL,'197.186.8.30','2026-08-24 21:02:56'),(22,10,'Management decision \'Approve with Revised Price\' for order #1','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:05:42'),(23,7,'SOF generated for order #1 (Partner: Afrilink Solutions Ltd, KYC Application ID: 3)','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:07:02'),(24,7,'Partner returned order #1 to KAM: sijapenda hela','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:09:32'),(25,2,'KAM approved standard commercial for order #1','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:11:29'),(26,7,'SOF generated for order #1 (Partner: Afrilink Solutions Ltd, KYC Application ID: 3)','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:12:18'),(27,7,'Signed SOF uploaded for order #1','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:12:40'),(28,2,'Countersigned SOF uploaded for order #1 by KAM','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:14:57'),(29,2,'Order #1 moved to Installation by KAM','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:15:21'),(30,11,'Contractor assigned to order #1','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:16:22'),(31,13,'Accepted job assignment #1 for order #1','contractor_assignments',1,NULL,NULL,'197.186.8.30','2026-08-24 21:17:40'),(32,13,'Evidence uploaded (2 file(s)): Site Photo for assignment #1','contractor_evidence',NULL,NULL,NULL,'197.186.8.30','2026-08-24 21:18:20'),(33,13,'Evidence uploaded (1 file(s)): ONT/ONU Serial for assignment #1','contractor_evidence',NULL,NULL,NULL,'197.186.8.30','2026-08-24 21:18:53'),(34,13,'Evidence uploaded (1 file(s)): Signal Test for assignment #1','contractor_evidence',NULL,NULL,NULL,'197.186.8.30','2026-08-24 21:19:18'),(35,13,'Evidence uploaded (1 file(s)): Speed Test for assignment #1','contractor_evidence',NULL,NULL,NULL,'197.186.8.30','2026-08-24 21:19:50'),(36,13,'Evidence uploaded (1 file(s)): Ping Test for assignment #1','contractor_evidence',NULL,NULL,NULL,'197.186.8.30','2026-08-24 21:20:20'),(37,13,'Evidence uploaded (1 file(s)): Latency Test for assignment #1','contractor_evidence',NULL,NULL,NULL,'197.186.8.30','2026-08-24 21:21:07'),(38,13,'Evidence uploaded (1 file(s)): UAT Sign-off for assignment #1','contractor_evidence',NULL,NULL,NULL,'197.186.8.30','2026-08-24 21:21:43'),(39,13,'Evidence uploaded (1 file(s)): Installation Remarks for assignment #1','contractor_evidence',NULL,NULL,NULL,'197.186.8.30','2026-08-24 21:22:06'),(40,13,'SLA clock paused for order #1 due to blocker','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:22:39'),(41,13,'Progress update on assignment #1 [BLOCKER]','contractor_assignments',1,NULL,NULL,'197.186.8.30','2026-08-24 21:22:39'),(42,13,'SLA clock resumed for order #1 (paused 0.02h, total paused: 0.02h)','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:23:51'),(43,13,'Progress update on assignment #1 [RESUMED]','contractor_assignments',1,NULL,NULL,'197.186.8.30','2026-08-24 21:23:51'),(44,11,'Order #1 returned to contractor from Testing','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:25:30'),(45,11,'NOC IP configured flag set to 1 for order #1','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:26:57'),(46,11,'Testing approved for order #1, moved to UAT','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:27:18'),(47,7,'Partner returned order #1 from UAT to Installation','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:28:13'),(48,11,'Project Manager submitted job as complete for order #1, moved to Testing','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:29:15'),(49,11,'Testing approved for order #1, moved to UAT','orders',1,NULL,NULL,'197.186.8.30','2026-08-24 21:29:42'),(50,7,'Partner accepted service — order #1 CLOSED. Billing start: 2026-08-24','orders',1,NULL,'closed_date=2026-08-24','197.186.8.30','2026-08-24 21:30:20'),(51,7,'FTTH bulk upload: 1 created, 0 errors from ftth_bulk_upload_template (2).csv','ftth_bulk_uploads',1,NULL,NULL,'197.186.8.30','2026-08-24 22:08:49'),(52,10,'Deleted partner Kilimanjaro Telecom Ltd (ID: 3)','partners',3,NULL,NULL,'197.186.8.30','2026-08-24 22:12:49'),(53,10,'Deleted order #FR-260824-002 (ID: 2)','orders',2,NULL,NULL,'197.186.8.30','2026-08-24 22:13:24'),(54,3,'Login','users',3,NULL,NULL,'197.186.3.49','2026-08-25 16:56:42'),(55,3,'User logged out','auth',3,NULL,NULL,'197.186.3.49','2026-08-25 16:59:44'),(56,1,'Login','users',1,NULL,NULL,'197.186.3.49','2026-08-25 17:25:33'),(57,1,'Login','users',1,NULL,NULL,'197.186.3.49','2026-08-25 17:26:00'),(58,1,'Login','users',1,NULL,NULL,'197.186.75.148','2026-08-25 22:08:42'),(59,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-08-26 12:03:11'),(60,1,'Login','users',1,NULL,NULL,'102.202.75.40','2026-08-29 23:14:58'),(61,1,'Login','users',1,NULL,NULL,'102.202.75.40','2026-08-29 23:15:00'),(62,1,'Login','users',1,NULL,NULL,'102.64.68.147','2026-08-29 23:15:35'),(63,1,'Closed order #FR-260824-001 edited by System Administrator. Reason: Yes. Changes: Active Status: Inactive → Active','orders',1,NULL,NULL,'102.64.68.147','2026-08-29 23:16:48'),(64,1,'Login','users',1,NULL,NULL,'102.64.68.147','2026-08-30 10:11:55'),(65,1,'Deleted user Commercial Director (commercial_dir)','users',5,NULL,NULL,'102.64.68.147','2026-08-30 10:15:30'),(66,1,'Deleted user NOC Support Lead (noc_support)','users',4,NULL,NULL,'102.64.68.147','2026-08-30 10:15:49'),(67,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-08-31 08:18:59'),(68,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-08-31 08:21:08'),(69,1,'Login','users',1,NULL,NULL,'102.64.68.147','2026-08-31 08:29:10'),(70,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-08-31 10:08:17'),(71,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-08-31 16:50:39'),(72,1,'Created user Aida (Robert)','users',14,NULL,NULL,'102.205.249.34','2026-08-31 17:00:49'),(73,1,'Created user MHINA KIHIYO (Mhina)','users',15,NULL,NULL,'102.205.249.34','2026-08-31 17:07:20'),(74,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-01 12:11:32'),(75,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-01 15:57:58'),(76,1,'Deleted user Aida (Robert)','users',14,NULL,NULL,'102.205.249.34','2026-09-01 16:03:58'),(77,1,'Reset password for MHINA KIHIYO','users',15,NULL,NULL,'102.205.249.34','2026-09-01 16:05:03'),(78,15,'Login','users',15,NULL,NULL,'102.205.249.34','2026-09-01 16:09:33'),(79,15,'Changed password','users',15,NULL,NULL,'102.205.249.34','2026-09-01 16:10:05'),(80,1,'Created user Aida Robert (arobert)','users',16,NULL,NULL,'102.205.249.34','2026-09-01 16:10:16'),(81,15,'Login','users',15,NULL,NULL,'102.205.249.34','2026-09-01 16:10:37'),(82,15,'Login','users',15,NULL,NULL,'102.205.249.34','2026-09-01 16:11:03'),(83,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-01 16:13:40'),(84,16,'Login','users',16,NULL,NULL,'102.205.249.34','2026-09-01 16:14:44'),(85,16,'Changed password','users',16,NULL,NULL,'102.205.249.34','2026-09-01 16:15:43'),(86,1,'Login','users',1,NULL,NULL,'196.249.113.77','2026-09-01 16:32:59'),(87,1,'User logged out','auth',1,NULL,NULL,'196.249.113.77','2026-09-01 16:33:43'),(88,1,'User logged out','auth',1,NULL,NULL,'196.249.113.77','2026-09-01 16:33:46'),(89,16,'Login','users',16,NULL,NULL,'196.249.113.77','2026-09-01 16:34:12'),(90,1,'Login','users',1,NULL,NULL,'196.249.113.77','2026-09-01 16:39:28'),(91,1,'Auto-created partner record \'Hellen\' for Partner user','partners',5,NULL,NULL,'196.249.113.77','2026-09-01 16:43:16'),(92,1,'Created user Hellen (hellen)','users',17,NULL,NULL,'196.249.113.77','2026-09-01 16:43:16'),(93,1,'User logged out','auth',1,NULL,NULL,'196.249.113.77','2026-09-01 16:44:02'),(94,1,'Login','users',1,NULL,NULL,'196.249.113.77','2026-09-01 16:45:53'),(95,NULL,'Login','users',17,NULL,NULL,'196.249.113.77','2026-09-01 16:48:56'),(96,NULL,'Changed password','users',17,NULL,NULL,'196.249.113.77','2026-09-01 16:49:42'),(97,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-02 09:08:34'),(98,16,'Login','users',16,NULL,NULL,'102.205.249.34','2026-09-02 09:09:23'),(99,16,'Login','users',16,NULL,NULL,'102.205.249.34','2026-09-02 09:09:25'),(100,16,'Login','users',16,NULL,NULL,'102.205.249.34','2026-09-02 09:09:26'),(101,1,'Login','users',1,NULL,NULL,'197.186.56.89','2026-09-02 09:48:29'),(102,1,'User logged out','auth',1,NULL,NULL,'197.186.56.89','2026-09-02 09:48:39'),(103,6,'Login','users',6,NULL,NULL,'197.186.56.89','2026-09-02 10:12:20'),(104,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-02 12:36:40'),(105,6,'Login','users',6,NULL,NULL,'102.205.249.34','2026-09-02 13:04:29'),(106,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-02 16:47:36'),(107,1,'Login','users',1,NULL,NULL,'102.64.68.147','2026-09-02 18:51:53'),(108,1,'Deleted user Hellen (hellen)','users',17,NULL,NULL,'102.64.68.147','2026-09-02 18:52:44'),(109,1,'Created user Hellen (hellen)','users',18,NULL,NULL,'102.64.68.147','2026-09-02 18:53:21'),(110,1,'User logged out','auth',1,NULL,NULL,'102.64.68.147','2026-09-02 18:53:40'),(111,18,'Login','users',18,NULL,NULL,'102.64.68.147','2026-09-02 18:53:52'),(112,18,'Created/Changed password','users',18,NULL,NULL,'102.64.68.147','2026-09-02 18:54:08'),(113,18,'Login','users',18,NULL,NULL,'102.64.68.147','2026-09-02 18:54:24'),(114,18,'User logged out','auth',18,NULL,NULL,'102.64.68.147','2026-09-02 18:54:38'),(115,6,'Login','users',6,NULL,NULL,'197.186.56.89','2026-09-02 20:03:41'),(116,6,'Created feasibility request FR-260902-001','orders',3,NULL,NULL,'197.186.56.89','2026-09-02 20:10:57'),(117,6,'User logged out','auth',6,NULL,NULL,'197.186.56.89','2026-09-02 20:12:38'),(118,1,'Login','users',1,NULL,NULL,'197.186.56.89','2026-09-02 20:12:49'),(119,1,'User logged out','auth',1,NULL,NULL,'197.186.56.89','2026-09-02 20:14:02'),(120,3,'Login','users',3,NULL,NULL,'197.186.56.89','2026-09-02 20:14:27'),(121,3,'BSA marked technically feasible for order #3','orders',3,NULL,NULL,'197.186.56.89','2026-09-02 20:17:05'),(122,3,'User logged out','auth',3,NULL,NULL,'197.186.56.89','2026-09-02 20:17:35'),(123,1,'Login','users',1,NULL,NULL,'197.186.56.89','2026-09-02 20:17:50'),(124,1,'User logged out','auth',1,NULL,NULL,'197.186.56.89','2026-09-02 20:24:20'),(125,1,'Login','users',1,NULL,NULL,'197.186.56.89','2026-09-02 20:24:26'),(126,1,'Login','users',1,NULL,NULL,'102.64.68.147','2026-09-02 22:36:18'),(127,1,'Login','users',1,NULL,NULL,'197.250.51.134','2026-09-03 08:45:23'),(128,15,'Login','users',15,NULL,NULL,'102.205.249.34','2026-09-03 08:58:04'),(129,16,'Login','users',16,NULL,NULL,'102.205.249.34','2026-09-03 09:01:57'),(130,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-03 10:01:56'),(131,1,'Auto-created partner record \'patner test\' for Partner user','partners',6,NULL,NULL,'102.205.249.34','2026-09-03 10:16:09'),(132,1,'Created user patner test (patner)','users',19,NULL,NULL,'102.205.249.34','2026-09-03 10:16:09'),(133,19,'Login','users',19,NULL,NULL,'102.205.249.34','2026-09-03 10:17:25'),(134,19,'Created/Changed password','users',19,NULL,NULL,'102.205.249.34','2026-09-03 10:17:52'),(135,19,'Login','users',19,NULL,NULL,'102.205.249.34','2026-09-03 10:18:27'),(136,19,'Login','users',19,NULL,NULL,'102.205.249.34','2026-09-03 10:18:29'),(137,19,'Created feasibility request FR-260903-001','orders',4,NULL,NULL,'102.205.249.34','2026-09-03 10:22:59'),(138,19,'Created feasibility request FR-260903-002','orders',5,NULL,NULL,'102.205.249.34','2026-09-03 10:23:01'),(139,1,'Created user EDWIN CHAMU (echamu)','users',20,NULL,NULL,'102.205.249.34','2026-09-03 10:24:57'),(140,1,'Updated user EDWIN CHAMU','users',20,NULL,NULL,'102.205.249.34','2026-09-03 10:25:56'),(141,19,'User logged out','auth',19,NULL,NULL,'102.205.249.34','2026-09-03 10:26:59'),(142,20,'Login','users',20,NULL,NULL,'102.205.249.34','2026-09-03 10:27:19'),(143,20,'Created/Changed password','users',20,NULL,NULL,'102.205.249.34','2026-09-03 10:27:36'),(144,20,'Login','users',20,NULL,NULL,'102.205.249.34','2026-09-03 10:27:53'),(145,20,'BSA marked technically feasible for order #4','orders',4,NULL,NULL,'102.205.249.34','2026-09-03 10:32:15'),(146,20,'User logged out','auth',20,NULL,NULL,'102.205.249.34','2026-09-03 10:33:04'),(147,19,'Login','users',19,NULL,NULL,'102.205.249.34','2026-09-03 10:33:10'),(148,19,'User logged out','auth',19,NULL,NULL,'102.205.249.34','2026-09-03 10:34:03'),(149,16,'Login','users',16,NULL,NULL,'102.205.249.34','2026-09-03 10:34:23'),(150,16,'KAM approved standard commercial for order #4','orders',4,NULL,NULL,'102.205.249.34','2026-09-03 10:37:07'),(151,16,'User logged out','auth',16,NULL,NULL,'102.205.249.34','2026-09-03 10:38:58'),(152,19,'Login','users',19,NULL,NULL,'102.205.249.34','2026-09-03 10:39:10'),(153,19,'User logged out','auth',19,NULL,NULL,'102.205.249.34','2026-09-03 10:41:06'),(154,19,'Login','users',19,NULL,NULL,'102.205.249.34','2026-09-03 10:47:08'),(155,1,'Signed SOF uploaded for order #4','orders',4,NULL,NULL,'102.205.249.34','2026-09-03 10:48:43'),(156,1,'Countersigned SOF uploaded for order #4 by System Admin','orders',4,NULL,NULL,'102.205.249.34','2026-09-03 10:51:48'),(157,1,'Order #4 moved to Installation by System Admin','orders',4,NULL,NULL,'102.205.249.34','2026-09-03 10:52:39'),(158,15,'Contractor assigned to order #4','orders',4,NULL,NULL,'102.205.249.34','2026-09-03 11:01:14'),(159,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-03 11:02:44'),(160,1,'Project Manager submitted job as complete for order #4, moved to Testing','orders',4,NULL,NULL,'102.205.249.34','2026-09-03 11:07:10'),(161,15,'Testing approved for order #4, moved to UAT','orders',4,NULL,NULL,'102.205.249.34','2026-09-03 11:09:58'),(162,19,'Partner accepted service — order #4 CLOSED. Billing start: 2026-09-03','orders',4,NULL,'closed_date=2026-09-03','102.205.249.34','2026-09-03 11:11:33'),(163,1,'Created user Hamis Hamis (hamis)','users',21,NULL,NULL,'102.205.249.34','2026-09-03 11:54:17'),(164,1,'Deleted user Hamis Hamis (hamis)','users',21,NULL,NULL,'102.205.249.34','2026-09-03 11:57:57'),(165,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-03 12:06:56'),(166,1,'Auto-created partner record \'FLASHNET TECHNOLOGIES LIMITED\' for Partner user','partners',7,NULL,NULL,'102.205.249.34','2026-09-03 12:13:25'),(167,1,'Created user FLASHNET TECHNOLOGIES LIMITED (flashnet)','users',22,NULL,NULL,'102.205.249.34','2026-09-03 12:13:25'),(168,1,'User logged out','auth',1,NULL,NULL,'102.205.249.34','2026-09-03 13:53:09'),(169,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-03 13:53:14'),(170,1,'User logged out','auth',1,NULL,NULL,'102.205.249.34','2026-09-03 13:54:03'),(171,1,'User logged out','auth',1,NULL,NULL,'102.205.249.34','2026-09-03 13:54:11'),(172,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-03 13:54:23'),(173,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-03 14:00:00'),(174,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-03 15:03:19'),(175,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-03 15:17:35'),(176,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-03 17:12:37'),(177,1,'Login','users',1,NULL,NULL,'197.250.51.134','2026-09-03 17:40:34'),(178,1,'Login','users',1,NULL,NULL,'102.64.68.147','2026-09-03 19:27:16'),(179,1,'Created user helloo (helloo)','users',23,NULL,NULL,'102.64.68.147','2026-09-03 19:29:41'),(180,1,'Deleted user helloo (helloo)','users',23,NULL,NULL,'102.64.68.147','2026-09-03 19:29:58'),(181,1,'Created user helloo (helloo)','users',24,NULL,NULL,'102.64.68.147','2026-09-03 19:31:29'),(182,1,'Deleted user helloo (helloo)','users',24,NULL,NULL,'102.64.68.147','2026-09-03 19:31:41'),(183,1,'Created user SIKUDHANI ALLAN MBWAMBO (siku)','users',25,NULL,NULL,'102.64.68.147','2026-09-03 19:32:13'),(184,1,'Deleted user SIKUDHANI ALLAN MBWAMBO (siku)','users',25,NULL,NULL,'102.64.68.147','2026-09-03 19:32:22'),(185,1,'Created user SIKUDHANI ALLAN MBWAMBO (siku)','users',26,NULL,NULL,'102.64.68.147','2026-09-03 19:32:45'),(186,1,'Deleted user SIKUDHANI ALLAN MBWAMBO (siku)','users',26,NULL,NULL,'102.64.68.147','2026-09-03 19:33:04'),(187,7,'Login','users',7,NULL,NULL,'102.64.68.147','2026-09-03 19:34:23'),(188,7,'FTTH bulk upload: 1 created, 0 errors from ftth_bulk_upload_template (4).csv','ftth_bulk_uploads',2,NULL,NULL,'102.64.68.147','2026-09-03 19:37:04'),(189,1,'BSA marked technically feasible for order #6','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 19:39:34'),(190,1,'KAM approved standard commercial for order #6','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 19:40:03'),(191,1,'SOF generated for order #6 (Partner: Afrilink Solutions Ltd, KYC Application ID: 3)','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 19:40:20'),(192,1,'SOF generated for order #6 (Partner: Afrilink Solutions Ltd, KYC Application ID: 3)','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 19:44:10'),(193,1,'Signed SOF uploaded for order #6','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 19:44:55'),(194,1,'Signed SOF uploaded for order #6','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 19:45:47'),(195,1,'Countersigned SOF uploaded for order #6 by System Admin','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 19:46:14'),(196,1,'Order #6 moved to Installation by System Admin','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 19:46:22'),(197,11,'Login','users',11,NULL,NULL,'102.64.68.147','2026-09-03 19:48:05'),(198,11,'Contractor assigned to order #6','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 19:49:06'),(199,13,'Login','users',13,NULL,NULL,'102.64.68.147','2026-09-03 19:49:58'),(200,13,'Accepted job assignment #3 for order #6','contractor_assignments',3,NULL,NULL,'102.64.68.147','2026-09-03 19:50:13'),(201,13,'Evidence uploaded (2 file(s)): Site Photo for assignment #3','contractor_evidence',NULL,NULL,NULL,'102.64.68.147','2026-09-03 19:50:46'),(202,13,'Evidence uploaded (1 file(s)): ONT/ONU Serial for assignment #3','contractor_evidence',NULL,NULL,NULL,'102.64.68.147','2026-09-03 19:51:11'),(203,13,'Evidence uploaded (1 file(s)): Signal Test for assignment #3','contractor_evidence',NULL,NULL,NULL,'102.64.68.147','2026-09-03 19:51:35'),(204,13,'Evidence uploaded (1 file(s)): Speed Test for assignment #3','contractor_evidence',NULL,NULL,NULL,'102.64.68.147','2026-09-03 19:52:04'),(205,13,'Evidence uploaded (1 file(s)): Ping Test for assignment #3','contractor_evidence',NULL,NULL,NULL,'102.64.68.147','2026-09-03 19:52:24'),(206,13,'Evidence uploaded (1 file(s)): Latency Test for assignment #3','contractor_evidence',NULL,NULL,NULL,'102.64.68.147','2026-09-03 19:52:44'),(207,13,'Evidence uploaded (1 file(s)): UAT Sign-off for assignment #3','contractor_evidence',NULL,NULL,NULL,'102.64.68.147','2026-09-03 19:53:13'),(208,13,'Evidence uploaded (1 file(s)): Installation Remarks for assignment #3','contractor_evidence',NULL,NULL,NULL,'102.64.68.147','2026-09-03 19:53:30'),(209,11,'Testing approved for order #6, moved to UAT','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 19:55:43'),(210,1,'Created user helloo (helloo)','users',27,NULL,NULL,'102.64.68.147','2026-09-03 20:01:05'),(211,11,'User logged out','auth',11,NULL,NULL,'102.64.68.147','2026-09-03 20:02:03'),(212,NULL,'Login','users',27,NULL,NULL,'102.64.68.147','2026-09-03 20:02:21'),(213,NULL,'Created/Changed password','users',27,NULL,NULL,'102.64.68.147','2026-09-03 20:02:48'),(214,NULL,'Login','users',27,NULL,NULL,'102.64.68.147','2026-09-03 20:03:00'),(215,1,'KAM approved standard commercial for order #3','orders',3,NULL,NULL,'102.64.68.147','2026-09-03 20:04:22'),(216,NULL,'User logged out','auth',27,NULL,NULL,'102.64.68.147','2026-09-03 20:06:43'),(217,11,'Login','users',11,NULL,NULL,'102.64.68.147','2026-09-03 20:06:53'),(218,7,'Partner returned order #6 from UAT to Installation','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 20:10:51'),(219,11,'Evidence uploaded (1 file(s)): Ping Test for assignment #3','contractor_evidence',NULL,NULL,NULL,'102.64.68.147','2026-09-03 20:11:47'),(220,11,'Testing approved for order #6, moved to UAT','orders',6,NULL,NULL,'102.64.68.147','2026-09-03 20:13:06'),(221,13,'KYC #2 Approved','kyc',2,NULL,NULL,'102.64.68.147','2026-09-03 20:15:46'),(222,13,'User logged out','auth',13,NULL,NULL,'102.64.68.147','2026-09-03 20:20:14'),(223,1,'Login','users',1,NULL,NULL,'102.205.251.226','2026-09-04 06:58:58'),(224,1,'Login','users',1,NULL,NULL,'102.64.68.147','2026-09-04 07:02:13'),(225,1,'Auto-created contractor record \'Hi\' for Contractor user','partners',8,NULL,NULL,'102.64.68.147','2026-09-04 07:04:52'),(226,1,'Created user Hi (hi)','users',28,NULL,NULL,'102.64.68.147','2026-09-04 07:04:52'),(227,1,'User logged out','auth',1,NULL,NULL,'102.64.68.147','2026-09-04 07:05:32'),(228,NULL,'Login','users',28,NULL,NULL,'102.64.68.147','2026-09-04 07:06:23'),(229,1,'Deleted user Hi (hi)','users',28,NULL,NULL,'102.205.251.226','2026-09-04 07:06:36'),(230,1,'Deleted user helloo (helloo)','users',27,NULL,NULL,'102.205.251.226','2026-09-04 07:06:48'),(232,1,'Auto-created contractor record \'Hamis Hamis\' for Contractor user','partners',9,NULL,NULL,'102.205.251.226','2026-09-04 07:07:14'),(233,1,'Created user Hamis Hamis (mtihan)','users',29,NULL,NULL,'102.205.251.226','2026-09-04 07:07:14'),(234,1,'Deleted user Hamis Hamis (mtihan)','users',29,NULL,NULL,'102.205.251.226','2026-09-04 07:07:32'),(235,1,'Login','users',1,NULL,NULL,'196.249.96.52','2026-09-04 07:18:46'),(236,1,'Login','users',1,NULL,NULL,'102.205.250.181','2026-09-04 11:37:59'),(237,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-07 08:51:29'),(238,1,'UAT 72-hour deadline expired — auto-accepted order #FR-260903-003','orders',6,NULL,NULL,'102.205.249.34','2026-09-07 08:51:30'),(239,19,'Login','users',19,NULL,NULL,'102.205.249.34','2026-09-07 09:17:02'),(240,19,'Created feasibility request FR-260907-001','orders',7,NULL,NULL,'102.205.249.34','2026-09-07 09:20:02'),(241,19,'User logged out','auth',19,NULL,NULL,'102.205.249.34','2026-09-07 09:20:44'),(242,20,'Login','users',20,NULL,NULL,'102.205.249.34','2026-09-07 09:21:01'),(243,20,'BSA marked technically feasible with NRC discount for order #7 — routed to Management','orders',7,NULL,NULL,'102.205.249.34','2026-09-07 09:22:44'),(244,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-07 09:36:54'),(245,16,'Login','users',16,NULL,NULL,'102.205.249.34','2026-09-07 10:55:24'),(246,19,'Login','users',19,NULL,NULL,'102.205.249.34','2026-09-07 11:03:37'),(247,19,'Created feasibility request FR-260907-002','orders',8,NULL,NULL,'102.205.249.34','2026-09-07 11:07:25'),(248,19,'User logged out','auth',19,NULL,NULL,'102.205.249.34','2026-09-07 11:08:17'),(249,20,'Login','users',20,NULL,NULL,'102.205.249.34','2026-09-07 11:08:31'),(250,20,'BSA marked technically feasible for order #8','orders',8,NULL,NULL,'102.205.249.34','2026-09-07 11:10:00'),(251,16,'KAM escalated pricing exception to Management for order #8','orders',8,NULL,NULL,'102.205.249.34','2026-09-07 11:16:59'),(252,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-07 11:17:03'),(253,1,'Management decision \'Approve as Requested\' for order #8','orders',8,NULL,NULL,'102.205.249.34','2026-09-07 11:20:42'),(254,1,'Management decision \'Approve as Requested\' for order #8','orders',8,NULL,NULL,'102.205.249.34','2026-09-07 11:20:55'),(255,20,'User logged out','auth',20,NULL,NULL,'102.205.249.34','2026-09-07 11:22:22'),(256,20,'Login','users',20,NULL,NULL,'102.205.249.34','2026-09-07 11:22:32'),(257,1,'Login','users',1,NULL,NULL,'102.205.249.34','2026-09-07 11:54:07'),(258,1,'Auto-created partner record \'SPRINT TANZANIA LIMITED\' for Partner user','partners',10,NULL,NULL,'102.205.249.34','2026-09-07 12:17:36'),(259,1,'Created user SPRINT TANZANIA LIMITED (sprint)','users',30,NULL,NULL,'102.205.249.34','2026-09-07 12:17:36'),(260,1,'Auto-created partner record \'RADDY DIGITAL SOLUTION LIMITED\' for Partner user','partners',11,NULL,NULL,'102.205.249.34','2026-09-07 14:28:50'),(261,1,'Created user RADDY DIGITAL SOLUTION LIMITED (raddy)','users',31,NULL,NULL,'102.205.249.34','2026-09-07 14:28:50'),(262,1,'Login','users',1,NULL,NULL,'127.0.0.1','2026-09-07 16:29:07'),(263,1,'Login','users',1,NULL,NULL,'127.0.0.1','2026-09-07 16:29:23'),(264,6,'Login','users',6,NULL,NULL,'127.0.0.1','2026-09-07 16:29:43'),(265,1,'Login','users',1,NULL,NULL,'127.0.0.1','2026-09-08 14:14:30'),(266,1,'Login','users',1,NULL,NULL,'192.168.221.173','2026-09-08 14:23:22'),(267,1,'Login','users',1,NULL,NULL,'192.168.100.40','2026-09-08 14:28:12'),(268,1,'Login','users',1,NULL,NULL,'127.0.0.1','2026-09-08 15:38:33'),(269,1,'Login','users',1,NULL,NULL,'127.0.0.1','2026-09-08 15:38:57'),(270,1,'SOF generated for order #1 (Partner: Afrilink Solutions Ltd, KYC Application ID: 3)','orders',1,NULL,NULL,'127.0.0.1','2026-09-08 15:38:58'),(271,1,'SOF generated for order #6 (Partner: Afrilink Solutions Ltd, KYC Application ID: 3)','orders',6,NULL,NULL,'127.0.0.1','2026-09-08 15:38:58'),(272,1,'Login','users',1,NULL,NULL,'127.0.0.1','2026-09-08 15:39:09'),(273,1,'SOF generated for order #1 (Partner: Afrilink Solutions Ltd, KYC Application ID: 3)','orders',1,NULL,NULL,'127.0.0.1','2026-09-08 15:39:09'),(274,1,'Login','users',1,NULL,NULL,'127.0.0.1','2026-09-08 15:50:13'),(275,1,'SOF generated for order #8 (Partner: patner test, KYC Application ID: N/A)','orders',8,NULL,NULL,'127.0.0.1','2026-09-08 15:50:14'),(276,1,'SOF generated for order #8 (Partner: patner test, KYC Application ID: N/A)','orders',8,NULL,NULL,'127.0.0.1','2026-09-08 15:50:14'),(277,1,'SOF generated for order #1 (Partner: Afrilink Solutions Ltd, KYC Application ID: 3)','orders',1,NULL,NULL,'127.0.0.1','2026-09-08 15:50:14'),(278,1,'SOF generated for order #3 (Partner: FastNet Communications Ltd, KYC Application ID: N/A)','orders',3,NULL,NULL,'127.0.0.1','2026-09-08 15:50:14'),(279,1,'SOF generated for order #4 (Partner: patner test, KYC Application ID: N/A)','orders',4,NULL,NULL,'127.0.0.1','2026-09-08 15:50:14'),(280,1,'SOF generated for order #5 (Partner: patner test, KYC Application ID: N/A)','orders',5,NULL,NULL,'127.0.0.1','2026-09-08 15:50:14'),(281,1,'SOF generated for order #6 (Partner: Afrilink Solutions Ltd, KYC Application ID: 3)','orders',6,NULL,NULL,'127.0.0.1','2026-09-08 15:50:14'),(282,1,'SOF generated for order #7 (Partner: patner test, KYC Application ID: N/A)','orders',7,NULL,NULL,'127.0.0.1','2026-09-08 15:50:14'),(283,1,'SOF generated for order #8 (Partner: patner test, KYC Application ID: N/A)','orders',8,NULL,NULL,'127.0.0.1','2026-09-08 15:50:14'),(284,1,'SOF generated for order #3 (Partner: FastNet Communications Ltd, KYC Application ID: N/A)','orders',3,NULL,NULL,'192.168.100.40','2026-09-08 16:00:46'),(285,1,'Login','users',1,NULL,NULL,'192.168.221.17','2026-09-08 16:44:13'),(286,1,'SOF generated for order #3 (Partner: FastNet Communications Ltd, KYC Application ID: N/A)','orders',3,NULL,NULL,'192.168.221.17','2026-09-08 16:45:08'),(287,20,'Login','users',20,NULL,NULL,'192.168.221.198','2026-09-08 16:47:36'),(288,1,'Login','users',1,NULL,NULL,'192.168.100.1','2026-09-08 17:43:53'),(289,1,'Login','users',1,NULL,NULL,'192.168.221.105','2026-09-09 09:18:47'),(290,1,'Login','users',1,NULL,NULL,'192.168.221.198','2026-09-09 09:21:49'),(291,1,'Login','users',1,NULL,NULL,'192.168.221.97','2026-09-09 09:23:40'),(292,1,'User logged out','auth',1,NULL,NULL,'192.168.221.198','2026-09-09 09:32:43'),(293,1,'Login','users',1,NULL,NULL,'192.168.221.198','2026-09-09 09:34:00'),(294,1,'User logged out','auth',1,NULL,NULL,'192.168.221.198','2026-09-09 09:35:05'),(295,22,'Login','users',22,NULL,NULL,'192.168.221.198','2026-09-09 09:40:55'),(296,22,'Created/Changed password','users',22,NULL,NULL,'192.168.221.198','2026-09-09 09:41:59'),(297,22,'Login','users',22,NULL,NULL,'192.168.221.198','2026-09-09 09:42:20'),(298,22,'Created feasibility request FR-260909-001','orders',9,NULL,NULL,'192.168.221.198','2026-09-09 10:21:43'),(299,20,'Login','users',20,NULL,NULL,'192.168.221.198','2026-09-09 10:23:07'),(300,20,'BSA marked technically feasible for order #9','orders',9,NULL,NULL,'192.168.221.198','2026-09-09 10:24:45'),(301,16,'Login','users',16,NULL,NULL,'192.168.221.58','2026-09-09 10:25:48'),(302,16,'KAM approved standard commercial for order #9','orders',9,NULL,NULL,'192.168.221.58','2026-09-09 10:26:29'),(303,22,'User logged out','auth',22,NULL,NULL,'192.168.221.198','2026-09-09 10:27:55'),(304,1,'Login','users',1,NULL,NULL,'192.168.221.198','2026-09-09 10:28:00'),(305,1,'SOF generated for order #9 (Partner: FLASHNET TECHNOLOGIES LIMITED, KYC Application ID: 4)','orders',9,NULL,NULL,'192.168.221.198','2026-09-09 10:28:43'),(306,1,'SOF generated for order #9 (Partner: FLASHNET TECHNOLOGIES LIMITED, KYC Application ID: 4)','orders',9,NULL,NULL,'192.168.221.198','2026-09-09 10:29:06'),(307,1,'Signed SOF uploaded for order #9','orders',9,NULL,NULL,'192.168.221.198','2026-09-09 10:33:23'),(308,1,'Countersigned SOF uploaded for order #9 by System Admin','orders',9,NULL,NULL,'192.168.221.198','2026-09-09 10:34:38'),(309,1,'Order #9 moved to Installation by System Admin','orders',9,NULL,NULL,'192.168.221.198','2026-09-09 10:35:11'),(310,1,'Contractor assigned to order #9','orders',9,NULL,NULL,'192.168.221.198','2026-09-09 10:36:16'),(311,1,'Evidence uploaded (1 file(s)): ONT/ONU Serial for assignment #4','contractor_evidence',NULL,NULL,NULL,'192.168.221.198','2026-09-09 10:37:14'),(312,1,'Evidence uploaded (1 file(s)): Signal Test for assignment #4','contractor_evidence',NULL,NULL,NULL,'192.168.221.198','2026-09-09 10:38:15'),(313,1,'Testing approved for order #9, moved to UAT','orders',9,NULL,NULL,'192.168.221.198','2026-09-09 10:40:18'),(314,20,'User logged out','auth',20,NULL,NULL,'192.168.221.198','2026-09-09 10:40:49'),(315,22,'Login','users',22,NULL,NULL,'192.168.221.198','2026-09-09 10:41:34'),(316,22,'Partner accepted service — order #9 CLOSED. Billing start: 2026-09-09','orders',9,NULL,'closed_date=2026-09-09','192.168.221.198','2026-09-09 10:42:06'),(317,1,'Login','users',1,NULL,NULL,'192.168.221.5','2026-09-09 12:18:28'),(318,1,'User logged out','auth',1,NULL,NULL,'192.168.221.5','2026-09-09 12:23:23'),(319,1,'Login','users',1,NULL,NULL,'192.168.221.5','2026-09-09 12:23:27'),(320,1,'Login','users',1,NULL,NULL,'192.168.221.173','2026-09-09 12:26:08'),(321,1,'Login','users',1,NULL,NULL,'192.168.221.55','2026-09-09 12:26:57'),(322,1,'SOF generated for order #3 (Partner: FastNet Communications Ltd, KYC Application ID: N/A)','orders',3,NULL,NULL,'192.168.221.173','2026-09-09 12:27:37'),(323,1,'User logged out','auth',1,NULL,NULL,'192.168.221.5','2026-09-09 12:36:25'),(324,1,'Login','users',1,NULL,NULL,'192.168.221.5','2026-09-09 12:40:08'),(325,1,'User logged out','auth',1,NULL,NULL,'192.168.221.5','2026-09-09 12:40:18'),(326,1,'Login','users',1,NULL,NULL,'192.168.221.5','2026-09-09 12:40:24'),(327,1,'User logged out','auth',1,NULL,NULL,'192.168.221.5','2026-09-09 12:40:27'),(328,1,'Login','users',1,NULL,NULL,'192.168.221.5','2026-09-09 12:40:32'),(329,1,'Login','users',1,NULL,NULL,'192.168.221.97','2026-09-09 14:45:07'),(330,1,'Login','users',1,NULL,NULL,'192.168.100.1','2026-09-09 16:20:46'),(331,1,'Login','users',1,NULL,NULL,'192.168.221.97','2026-09-09 16:38:34'),(332,15,'Login','users',15,NULL,NULL,'192.168.221.107','2026-09-10 08:45:46'),(333,1,'Login','users',1,NULL,NULL,'192.168.221.97','2026-09-10 11:45:06'),(334,1,'Updated user MHINA KIHIYO','users',15,NULL,NULL,'192.168.100.1','2026-09-10 12:33:57'),(335,1,'Deleted contractor Hi (ID: 8)','contractors',8,NULL,NULL,'192.168.100.1','2026-09-10 12:35:34'),(336,1,'Deleted contractor Hamis Hamis (ID: 9)','contractors',9,NULL,NULL,'192.168.100.1','2026-09-10 12:35:47'),(337,1,'Updated Neilos company settings','neilos_company_info',1,NULL,NULL,'192.168.100.1','2026-09-10 12:36:27'),(338,15,'Login','users',15,NULL,NULL,'192.168.221.107','2026-09-10 12:53:18');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractor_assignments`
--

DROP TABLE IF EXISTS `contractor_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractor_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `contractor_partner_id` int(10) unsigned NOT NULL COMMENT 'partners.id where kyc_type=Contractor',
  `contractor_user_id` int(10) unsigned DEFAULT NULL COMMENT 'Specific contractor user assigned',
  `assigned_by` int(10) unsigned NOT NULL COMMENT 'Project Manager user id',
  `assigned_at` datetime DEFAULT current_timestamp(),
  `target_date` date DEFAULT NULL,
  `work_order_notes` text DEFAULT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Assigned',
  `accepted_by` int(10) unsigned DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `completion_remarks` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contractor_user_id` (`contractor_user_id`),
  KEY `assigned_by` (`assigned_by`),
  KEY `accepted_by` (`accepted_by`),
  KEY `idx_order` (`order_id`),
  KEY `idx_contractor` (`contractor_partner_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `contractor_assignments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contractor_assignments_ibfk_2` FOREIGN KEY (`contractor_partner_id`) REFERENCES `partners` (`id`),
  CONSTRAINT `contractor_assignments_ibfk_3` FOREIGN KEY (`contractor_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `contractor_assignments_ibfk_4` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`),
  CONSTRAINT `contractor_assignments_ibfk_5` FOREIGN KEY (`accepted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractor_assignments`
--

LOCK TABLES `contractor_assignments` WRITE;
/*!40000 ALTER TABLE `contractor_assignments` DISABLE KEYS */;
INSERT INTO `contractor_assignments` VALUES (1,1,4,NULL,11,'2026-08-24 21:16:22','2026-08-25','fanya vzuri','Completed Submitted',13,'2026-08-24 21:17:40','2026-08-24 21:29:15',''),(2,4,4,NULL,15,'2026-09-03 11:01:14','2026-09-03','','Completed Submitted',NULL,NULL,'2026-09-03 11:07:09',''),(3,6,4,NULL,11,'2026-09-03 19:49:06','2026-09-04','','Completed Submitted',13,'2026-09-03 19:50:13','2026-09-03 20:12:12',''),(4,9,4,NULL,1,'2026-09-09 10:36:16','2026-09-10','N/A','Completed Submitted',NULL,NULL,'2026-09-09 10:39:44','');
/*!40000 ALTER TABLE `contractor_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractor_evidence`
--

DROP TABLE IF EXISTS `contractor_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractor_evidence` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `evidence_type` varchar(100) NOT NULL,
  `serial_number` varchar(200) DEFAULT NULL COMMENT 'For ONT/ONU serial number',
  `notes` text DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `uploaded_by` int(10) unsigned NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  `is_mandatory` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_order` (`order_id`),
  CONSTRAINT `contractor_evidence_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `contractor_assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contractor_evidence_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contractor_evidence_ibfk_3` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractor_evidence`
--

LOCK TABLES `contractor_evidence` WRITE;
/*!40000 ALTER TABLE `contractor_evidence` DISABLE KEYS */;
INSERT INTO `contractor_evidence` VALUES (1,1,1,'Site Photo',NULL,NULL,'localhost_Neilos_public__page=order_detail&id=6 (1).png','uploads/orders/1/evidence/8b4646d0eda64723de57b5860b4e0ee3.png',348487,13,'2026-08-24 21:18:20',0),(2,1,1,'Site Photo',NULL,NULL,'localhost_Neilos_public__page=order_detail&id=6.png','uploads/orders/1/evidence/796670b6966f9f15f08672b7ad3b23bf.png',359446,13,'2026-08-24 21:18:20',0),(3,1,1,'ONT/ONU Serial','HWTC12345678',NULL,'localhost_Neilos_public__page=sla_tracking (1).png','uploads/orders/1/evidence/2315382db5fabfd25c346c4c7497f36a.png',282051,13,'2026-08-24 21:18:53',0),(4,1,1,'Signal Test',NULL,NULL,'localhost_Neilos_public__page=sla_tracking (1).png','uploads/orders/1/evidence/be640f7d1af399a93c80f14e37db5090.png',282051,13,'2026-08-24 21:19:18',0),(5,1,1,'Speed Test',NULL,NULL,'localhost_Neilos_public__page=order_detail&id=6.png','uploads/orders/1/evidence/1947c4a68c867b2911f57c6990dab427.png',359446,13,'2026-08-24 21:19:50',0),(6,1,1,'Ping Test',NULL,NULL,'localhost_Neilos_public__page=sla_tracking (1).png','uploads/orders/1/evidence/81dff43b272ce1972d7e4027fe99d30e.png',282051,13,'2026-08-24 21:20:20',0),(7,1,1,'Latency Test',NULL,NULL,'localhost_Neilos_public__page=sla_tracking (1).png','uploads/orders/1/evidence/be6e86eff7f4905d7284ec858e2db89b.png',282051,13,'2026-08-24 21:21:07',0),(8,1,1,'UAT Sign-off',NULL,NULL,'localhost_Neilos_public__page=order_detail&id=6.png','uploads/orders/1/evidence/858769b555cc3a196a009ab246249376.png',359446,13,'2026-08-24 21:21:43',0),(9,1,1,'Installation Remarks',NULL,'Good',NULL,NULL,NULL,13,'2026-08-24 21:22:06',0),(10,3,6,'Site Photo',NULL,NULL,'Logo - For Large Screen.png','uploads/orders/6/evidence/7692f4de272ee512226a684f2fe91039.png',885203,13,'2026-09-03 19:50:46',0),(11,3,6,'Site Photo',NULL,NULL,'localhost_Neilos_public__page=orders.png','uploads/orders/6/evidence/1bf12a53189d4379c310f9ffc72a679b.png',122681,13,'2026-09-03 19:50:46',0),(12,3,6,'ONT/ONU Serial','12345678',NULL,'localhost_Neilos_public__page=orders.png','uploads/orders/6/evidence/d5af28c88d5758284ed5c3afa0382c63.png',122681,13,'2026-09-03 19:51:11',0),(13,3,6,'Signal Test',NULL,NULL,'localhost_Neilos_public__page=sla_tracking (1) (1).png','uploads/orders/6/evidence/e2d8d7c46bbc8d577796a6f6c06d95c2.png',282051,13,'2026-09-03 19:51:35',0),(14,3,6,'Speed Test',NULL,NULL,'localhost_Neilos_public__page=orders.png','uploads/orders/6/evidence/67b3dc5f08704261c58495dba993fa13.png',122681,13,'2026-09-03 19:52:04',0),(15,3,6,'Ping Test',NULL,NULL,'localhost_Neilos_public__page=orders.png','uploads/orders/6/evidence/ff42bf9e9650af9135413cc027faaf20.png',122681,13,'2026-09-03 19:52:24',0),(16,3,6,'Latency Test',NULL,NULL,'localhost_Neilos_public__page=orders.png','uploads/orders/6/evidence/cc7d9dc4c048e3e79f44ce849efe8e65.png',122681,13,'2026-09-03 19:52:44',0),(17,3,6,'UAT Sign-off',NULL,NULL,'localhost_Neilos_public__page=orders.png','uploads/orders/6/evidence/e8754b8d767a5c23afb9d70313fbb338.png',122681,13,'2026-09-03 19:53:13',0),(18,3,6,'Installation Remarks',NULL,'yes',NULL,NULL,NULL,13,'2026-09-03 19:53:30',0),(19,3,6,'Ping Test',NULL,NULL,'localhost_Neilos_public__page=orders (1).png','uploads/orders/6/evidence/f2cd12054bbaff77e0a10a27f8e1f00d.png',122681,11,'2026-09-03 20:11:47',0),(20,4,9,'ONT/ONU Serial',NULL,NULL,'Managed WIFI.png','uploads/orders/9/evidence/69bb12f6b799c2f382ed98884ae23acc.png',1665338,1,'2026-09-09 10:37:14',0),(21,4,9,'Signal Test',NULL,NULL,'Neilos Proposed Architecture.png','uploads/orders/9/evidence/c9fbaef421d907ff6dcb6f00bfb8f905.png',1612447,1,'2026-09-09 10:38:15',0);
/*!40000 ALTER TABLE `contractor_evidence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractor_progress_updates`
--

DROP TABLE IF EXISTS `contractor_progress_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractor_progress_updates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `updated_by` int(10) unsigned NOT NULL,
  `progress_status` varchar(100) NOT NULL DEFAULT 'In Progress',
  `is_blocker` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'If 1, this update is a blocker — SLA pauses',
  `is_resumed` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'If 1, installation resumed — SLA resumes',
  `delay_reason` enum('Customer Unavailable','Access Denied','Weather','Missing Materials','Technical Issue','Other') DEFAULT NULL,
  `notes` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_order` (`order_id`),
  CONSTRAINT `contractor_progress_updates_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `contractor_assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contractor_progress_updates_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contractor_progress_updates_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractor_progress_updates`
--

LOCK TABLES `contractor_progress_updates` WRITE;
/*!40000 ALTER TABLE `contractor_progress_updates` DISABLE KEYS */;
INSERT INTO `contractor_progress_updates` VALUES (1,1,1,13,'In Progress',0,0,NULL,'Job accepted and proceeding to site.','2026-08-24 21:17:40'),(2,1,1,13,'Delayed',1,0,'Weather','Mvua','2026-08-24 21:22:39'),(3,1,1,13,'In Progress',0,1,NULL,'good','2026-08-24 21:23:51'),(4,1,1,13,'Completed',0,0,NULL,'Installation completed and submitted for review. ','2026-08-24 21:24:19'),(5,1,1,13,'Completed',0,0,NULL,'Installation completed and submitted for review. ','2026-08-24 21:26:12'),(6,3,6,13,'In Progress',0,0,NULL,'Job accepted and proceeding to site.','2026-09-03 19:50:13'),(7,3,6,13,'Completed',0,0,NULL,'Installation completed and submitted for review. ','2026-09-03 19:53:53'),(8,3,6,11,'Completed',0,0,NULL,'Installation completed and submitted for review. ','2026-09-03 20:12:12'),(9,4,9,1,'Completed',0,0,NULL,'Installation completed and submitted for review. ','2026-09-09 10:39:44');
/*!40000 ALTER TABLE `contractor_progress_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evidence_checklist_config`
--

DROP TABLE IF EXISTS `evidence_checklist_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evidence_checklist_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_type` varchar(100) NOT NULL,
  `evidence_type` varchar(100) NOT NULL,
  `is_mandatory` tinyint(1) DEFAULT 1,
  `is_noc_conditional` tinyint(1) DEFAULT 0 COMMENT 'If 1, only required when noc_ip_configured=1',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_service_evidence` (`service_type`,`evidence_type`)
) ENGINE=InnoDB AUTO_INCREMENT=8695453 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evidence_checklist_config`
--

LOCK TABLES `evidence_checklist_config` WRITE;
/*!40000 ALTER TABLE `evidence_checklist_config` DISABLE KEYS */;
INSERT INTO `evidence_checklist_config` VALUES (1,'FTTH','Site Photo',1,0,'2026-08-24 11:10:42'),(2,'FTTH','ONT/ONU Serial',1,0,'2026-08-24 11:10:42'),(3,'FTTH','Signal Test',1,0,'2026-08-24 11:10:42'),(4,'FTTH','Speed Test',1,1,'2026-08-24 11:10:42'),(5,'FTTH','Ping Test',1,1,'2026-08-24 11:10:42'),(6,'FTTH','Latency Test',1,0,'2026-08-24 11:10:42'),(7,'FTTH','UAT Sign-off',1,0,'2026-08-24 11:10:42'),(8,'FTTH','Installation Remarks',1,0,'2026-08-24 11:10:42'),(9,'FTTB','Site Photo',1,0,'2026-08-24 11:10:42'),(10,'FTTB','ONT/ONU Serial',1,0,'2026-08-24 11:10:42'),(11,'FTTB','Signal Test',1,0,'2026-08-24 11:10:42'),(12,'FTTB','Speed Test',1,1,'2026-08-24 11:10:42'),(13,'FTTB','Ping Test',1,1,'2026-08-24 11:10:42'),(14,'FTTB','Latency Test',1,0,'2026-08-24 11:10:42'),(15,'FTTB','UAT Sign-off',1,0,'2026-08-24 11:10:42'),(16,'FTTB','Installation Remarks',1,0,'2026-08-24 11:10:42'),(17,'DIA','Site Photo',1,0,'2026-08-24 11:10:42'),(18,'DIA','ONT/ONU Serial',1,0,'2026-08-24 11:10:42'),(19,'DIA','Signal Test',1,0,'2026-08-24 11:10:42'),(20,'DIA','Speed Test',1,1,'2026-08-24 11:10:42'),(21,'DIA','Ping Test',1,1,'2026-08-24 11:10:42'),(22,'DIA','Latency Test',1,0,'2026-08-24 11:10:42'),(23,'DIA','UAT Sign-off',1,0,'2026-08-24 11:10:42'),(24,'DIA','Installation Remarks',1,0,'2026-08-24 11:10:42'),(25,'Dedicated Layer 2','Site Photo',1,0,'2026-08-24 11:10:42'),(26,'Dedicated Layer 2','ONT/ONU Serial',1,0,'2026-08-24 11:10:42'),(27,'Dedicated Layer 2','Signal Test',1,0,'2026-08-24 11:10:42'),(28,'Dedicated Layer 2','Speed Test',1,1,'2026-08-24 11:10:42'),(29,'Dedicated Layer 2','Ping Test',1,1,'2026-08-24 11:10:42'),(30,'Dedicated Layer 2','Latency Test',1,0,'2026-08-24 11:10:42'),(31,'Dedicated Layer 2','UAT Sign-off',1,0,'2026-08-24 11:10:42'),(32,'Dedicated Layer 2','Installation Remarks',1,0,'2026-08-24 11:10:42'),(33,'Layer 2 ( last mile)','Site Photo',1,0,'2026-08-24 11:10:42'),(34,'Layer 2 ( last mile)','ONT/ONU Serial',1,0,'2026-08-24 11:10:42'),(35,'Layer 2 ( last mile)','Signal Test',1,0,'2026-08-24 11:10:42'),(36,'Layer 2 ( last mile)','Speed Test',1,1,'2026-08-24 11:10:42'),(37,'Layer 2 ( last mile)','Ping Test',1,1,'2026-08-24 11:10:42'),(38,'Layer 2 ( last mile)','Latency Test',1,0,'2026-08-24 11:10:42'),(39,'Layer 2 ( last mile)','UAT Sign-off',1,0,'2026-08-24 11:10:42'),(40,'Layer 2 ( last mile)','Installation Remarks',1,0,'2026-08-24 11:10:42'),(41,'BIA (Broadband Internet Access)','Site Photo',1,0,'2026-08-24 11:10:42'),(42,'BIA (Broadband Internet Access)','ONT/ONU Serial',1,0,'2026-08-24 11:10:42'),(43,'BIA (Broadband Internet Access)','Signal Test',1,0,'2026-08-24 11:10:42'),(44,'BIA (Broadband Internet Access)','Speed Test',1,1,'2026-08-24 11:10:42'),(45,'BIA (Broadband Internet Access)','Ping Test',1,1,'2026-08-24 11:10:42'),(46,'BIA (Broadband Internet Access)','Latency Test',1,0,'2026-08-24 11:10:42'),(47,'BIA (Broadband Internet Access)','UAT Sign-off',1,0,'2026-08-24 11:10:42'),(48,'BIA (Broadband Internet Access)','Installation Remarks',1,0,'2026-08-24 11:10:42'),(49,'Remote Hands Only','Site Photo',1,0,'2026-08-24 11:10:42'),(50,'Remote Hands Only','ONT/ONU Serial',1,0,'2026-08-24 11:10:42'),(51,'Remote Hands Only','Installation Remarks',1,0,'2026-08-24 11:10:42'),(52,'FTTE','Site Photo',1,0,'2026-08-24 11:26:09'),(53,'FTTE','ONT/ONU Serial',1,0,'2026-08-24 11:26:09'),(54,'FTTE','Signal Test',1,0,'2026-08-24 11:26:09'),(55,'FTTE','Speed Test',1,0,'2026-08-24 11:26:09'),(56,'FTTE','Latency Test',1,0,'2026-08-24 11:26:09'),(57,'FTTE','UAT Sign-off',1,0,'2026-08-24 11:26:09'),(58,'FTTE','Installation Remarks',1,0,'2026-08-24 11:26:09'),(59,'BIA','Site Photo',1,0,'2026-08-24 11:26:09'),(60,'BIA','ONT/ONU Serial',1,0,'2026-08-24 11:26:09'),(61,'BIA','Signal Test',1,0,'2026-08-24 11:26:09'),(62,'BIA','Speed Test',1,0,'2026-08-24 11:26:09'),(63,'BIA','Latency Test',1,0,'2026-08-24 11:26:09'),(64,'BIA','UAT Sign-off',1,0,'2026-08-24 11:26:09'),(65,'BIA','Installation Remarks',1,0,'2026-08-24 11:26:09');
/*!40000 ALTER TABLE `evidence_checklist_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftth_bulk_uploads`
--

DROP TABLE IF EXISTS `ftth_bulk_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftth_bulk_uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uploaded_by` int(10) unsigned NOT NULL,
  `original_file` varchar(255) NOT NULL,
  `total_rows` int(11) NOT NULL DEFAULT 0,
  `success_rows` int(11) NOT NULL DEFAULT 0,
  `error_rows` int(11) NOT NULL DEFAULT 0,
  `errors_json` longtext DEFAULT NULL,
  `created_orders` longtext DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `idx_uploaded_at` (`uploaded_at`),
  CONSTRAINT `ftth_bulk_uploads_ibfk_1` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftth_bulk_uploads`
--

LOCK TABLES `ftth_bulk_uploads` WRITE;
/*!40000 ALTER TABLE `ftth_bulk_uploads` DISABLE KEYS */;
INSERT INTO `ftth_bulk_uploads` VALUES (1,7,'ftth_bulk_upload_template (2).csv',1,1,0,'[]','2','2026-08-24 22:08:49'),(2,7,'ftth_bulk_upload_template (4).csv',1,1,0,'[]','6','2026-09-03 19:37:04');
/*!40000 ALTER TABLE `ftth_bulk_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `partner_id` int(10) unsigned NOT NULL,
  `invoice_type` enum('NRC','MRC','NRC_MRC','Usage') NOT NULL DEFAULT 'NRC_MRC',
  `amount_usd` decimal(12,2) NOT NULL,
  `vat_usd` decimal(12,2) NOT NULL,
  `total_usd` decimal(12,2) NOT NULL,
  `amount_tzs` decimal(14,2) NOT NULL,
  `vat_tzs` decimal(14,2) NOT NULL,
  `total_tzs` decimal(14,2) NOT NULL,
  `exchange_rate` decimal(10,4) NOT NULL DEFAULT 2550.0000,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `due_date` date NOT NULL,
  `status` enum('Draft','Issued','Paid','Partially Paid','Overdue','Cancelled') NOT NULL DEFAULT 'Draft',
  `pdf_path` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `order_id` (`order_id`),
  KEY `partner_id` (`partner_id`),
  KEY `idx_invoice_number` (`invoice_number`),
  KEY `idx_status` (`status`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kyc_documents`
--

DROP TABLE IF EXISTS `kyc_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kyc_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `application_id` int(10) unsigned NOT NULL,
  `doc_type` enum('certificate_of_incorporation','tin_certificate','vrn_certificate','business_license','tax_clearance','bank_proof','id_copy','other') NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `application_id` (`application_id`),
  CONSTRAINT `kyc_documents_ibfk_1` FOREIGN KEY (`application_id`) REFERENCES `partner_kyc_applications` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kyc_documents`
--

LOCK TABLES `kyc_documents` WRITE;
/*!40000 ALTER TABLE `kyc_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `kyc_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kyc_history`
--

DROP TABLE IF EXISTS `kyc_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kyc_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kyc_id` int(10) unsigned NOT NULL,
  `action_by` int(10) unsigned DEFAULT NULL,
  `action_role` varchar(50) NOT NULL,
  `from_status` varchar(50) DEFAULT NULL,
  `to_status` varchar(50) NOT NULL,
  `action_title` varchar(200) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_kyc` (`kyc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kyc_history`
--

LOCK TABLES `kyc_history` WRITE;
/*!40000 ALTER TABLE `kyc_history` DISABLE KEYS */;
INSERT INTO `kyc_history` VALUES (2,2,1,'System Admin',NULL,'Draft','KYC Created by Admin/Management',NULL,'2026-08-24 15:56:41'),(3,3,1,'System Admin',NULL,'Draft','KYC Created by Admin/Management',NULL,'2026-08-24 20:29:49'),(4,3,1,'System Admin','Draft','Submitted for Approval','KYC Submitted for Approval',NULL,'2026-08-24 20:29:49'),(5,2,1,'System Admin','Draft','Submitted for Approval','KYC Submitted for Approval',NULL,'2026-08-24 20:31:18'),(6,3,7,'Partner','Submitted for Approval','Rejected','KYC Rejected by Partner','Reason: imekosewa','2026-08-24 20:42:44'),(7,3,1,'System Admin','Rejected','Submitted for Approval','KYC Resubmitted for Approval',NULL,'2026-08-24 20:44:08'),(8,3,7,'Partner','Submitted for Approval','Approved','KYC Approved by Partner','Approved by Partner Admin (Afrilink) (admin@afrilink.co.tz)','2026-08-24 20:48:34'),(9,4,1,'System Admin',NULL,'Draft','KYC Created by Admin/Management',NULL,'2026-09-03 13:10:22'),(10,4,1,'System Admin','Draft','Draft','KYC Saved as Draft',NULL,'2026-09-03 13:10:22'),(11,4,1,'System Admin','Draft','Draft','KYC Saved as Draft',NULL,'2026-09-03 13:10:31'),(12,4,1,'System Admin','Draft','Draft','KYC Saved as Draft',NULL,'2026-09-03 13:10:32'),(13,2,13,'Contractor','Submitted for Approval','Approved','KYC Approved by Contractor','Approved by Contractor Admin (admin@fiberworks.co.tz)','2026-09-03 20:15:46'),(14,4,1,'System Admin','Draft','Draft','KYC Saved as Draft',NULL,'2026-09-07 12:00:43'),(15,4,1,'System Admin','Draft','Draft','KYC Saved as Draft',NULL,'2026-09-07 12:01:20'),(16,4,1,'System Admin','Draft','Submitted for Approval','KYC Submitted for Approval',NULL,'2026-09-07 12:12:36'),(17,5,1,'System Admin',NULL,'Draft','KYC Created by Admin/Management',NULL,'2026-09-07 13:08:44'),(18,5,1,'System Admin','Draft','Draft','KYC Saved as Draft',NULL,'2026-09-07 13:08:45'),(19,5,1,'System Admin','Draft','Draft','KYC Saved as Draft',NULL,'2026-09-07 14:09:02'),(20,6,1,'System Admin',NULL,'Draft','KYC Created by Admin/Management',NULL,'2026-09-07 14:42:59'),(21,7,1,'System Admin',NULL,'Draft','KYC Created by Admin/Management',NULL,'2026-09-10 08:20:41'),(22,7,1,'System Admin','Draft','Submitted for Approval','KYC Submitted for Approval',NULL,'2026-09-10 08:20:41');
/*!40000 ALTER TABLE `kyc_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neilos_company_info`
--

DROP TABLE IF EXISTS `neilos_company_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neilos_company_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) NOT NULL DEFAULT 'Neilos Network Ltd',
  `trading_name` varchar(200) DEFAULT NULL,
  `registration_number` varchar(100) DEFAULT NULL,
  `tin` varchar(100) DEFAULT NULL,
  `vat_vrn` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city_region` varchar(100) DEFAULT 'Dar es Salaam',
  `country` varchar(100) DEFAULT 'Tanzania',
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `website` varchar(200) DEFAULT NULL,
  `authorized_signatory` varchar(200) DEFAULT NULL,
  `signatory_title` varchar(100) DEFAULT NULL,
  `finance_contact` varchar(200) DEFAULT NULL,
  `finance_email` varchar(200) DEFAULT NULL,
  `tech_contact` varchar(200) DEFAULT NULL,
  `tech_email` varchar(200) DEFAULT NULL,
  `logo_path` varchar(500) DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `neilos_company_info_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neilos_company_info`
--

LOCK TABLES `neilos_company_info` WRITE;
/*!40000 ALTER TABLE `neilos_company_info` DISABLE KEYS */;
INSERT INTO `neilos_company_info` VALUES (1,'Neilos Network Ltd','Neilos','REG-100890','TIN-001234567','4551','ILALA','Dar es Salaam','Tanzania','+255623700877','manager@neilosnetwork.co.tz','https://neilosnetwork.co.tz','Mr Moses Palela','Managing Director','Irene','irene@neilosnetwork.co.tz','Noc','noc@neilosnetwork.co.tz',NULL,1,'2026-08-24 11:10:42','2026-09-10 12:36:27');
/*!40000 ALTER TABLE `neilos_company_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_queue`
--

DROP TABLE IF EXISTS `notification_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `channel` enum('Email','SMS','WhatsApp') NOT NULL DEFAULT 'Email',
  `recipient` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `context_type` varchar(50) DEFAULT NULL,
  `context_id` int(10) unsigned DEFAULT NULL,
  `status` enum('Queued','Sent','Failed') NOT NULL DEFAULT 'Queued',
  `attempts` int(11) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_queue`
--

LOCK TABLES `notification_queue` WRITE;
/*!40000 ALTER TABLE `notification_queue` DISABLE KEYS */;
INSERT INTO `notification_queue` VALUES (1,'Email','admin@afrilink.co.tz','KYC Application Submitted for Review — Afrilink Solutions Ltd','Your KYC application has been submitted for approval. Please log into the portal to review and approve/reject.','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:29:49'),(2,'Email','admin@neilos.co.tz','KYC Application Submitted — Afrilink Solutions Ltd','KYC Application #3 for Afrilink Solutions Ltd has been submitted for approval.','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:29:49'),(3,'Email','management@neilos.co.tz','KYC Application Submitted — Afrilink Solutions Ltd','KYC Application #3 for Afrilink Solutions Ltd has been submitted for approval.','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:29:49'),(4,'Email','admin@fiberworks.co.tz','KYC Application Submitted for Review — Fiber Works Ltd','Your KYC application has been submitted for approval. Please log into the portal to review and approve/reject.','kyc',2,'Queued',0,NULL,NULL,'2026-08-24 20:31:18'),(5,'Email','admin@neilos.co.tz','KYC Application Submitted — Fiber Works Ltd','KYC Application #2 for Fiber Works Ltd has been submitted for approval.','kyc',2,'Queued',0,NULL,NULL,'2026-08-24 20:31:18'),(6,'Email','management@neilos.co.tz','KYC Application Submitted — Fiber Works Ltd','KYC Application #2 for Fiber Works Ltd has been submitted for approval.','kyc',2,'Queued',0,NULL,NULL,'2026-08-24 20:31:18'),(7,'Email','admin@neilos.co.tz','KYC Application Rejected — Afrilink Solutions Ltd','KYC Application #3 for Afrilink Solutions Ltd was REJECTED.\nRejection Reason: imekosewa','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:42:44'),(8,'Email','management@neilos.co.tz','KYC Application Rejected — Afrilink Solutions Ltd','KYC Application #3 for Afrilink Solutions Ltd was REJECTED.\nRejection Reason: imekosewa','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:42:44'),(9,'Email','admin@afrilink.co.tz','KYC Application Submitted for Review — Afrilink Solutions Ltd','Your KYC application has been submitted for approval. Please log into the portal to review and approve/reject.','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:44:08'),(10,'Email','admin@neilos.co.tz','KYC Application Submitted — Afrilink Solutions Ltd','KYC Application #3 for Afrilink Solutions Ltd has been submitted for approval.','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:44:08'),(11,'Email','management@neilos.co.tz','KYC Application Submitted — Afrilink Solutions Ltd','KYC Application #3 for Afrilink Solutions Ltd has been submitted for approval.','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:44:08'),(12,'Email','admin@afrilink.co.tz','KYC Application Approved — Afrilink Solutions Ltd','Your KYC application #3 has been successfully approved.','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:48:34'),(13,'Email','admin@neilos.co.tz','KYC Approved — Afrilink Solutions Ltd','KYC Application #3 for Afrilink Solutions Ltd was approved by the partner/contractor.','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:48:34'),(14,'Email','management@neilos.co.tz','KYC Approved — Afrilink Solutions Ltd','KYC Application #3 for Afrilink Solutions Ltd was approved by the partner/contractor.','kyc',3,'Queued',0,NULL,NULL,'2026-08-24 20:48:34'),(15,'Email','comfortmnyinga@gmail.com','New Feasibility Request: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) submitted by partner. Please review technical feasibility.','order',1,'Queued',0,NULL,NULL,'2026-08-24 20:54:41'),(16,'Email','manager@neilosnetwork.co.tz','Exception Approval Required: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) requires your exception approval for non-standard commercial terms. KAM: John KAM. Please log in to review and approve.','order',1,'Queued',0,NULL,NULL,'2026-08-24 20:58:27'),(17,'Email','comfortmnyinga@gmail.com','Partner Returned: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) — Partner has returned the order from Pending SOF for review. Please check remarks and re-assess.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:09:32'),(18,'Email','john.kam@neilosnetwork.co.tz','Partner Returned: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) — Partner has returned the order from Pending SOF. Please review.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:09:32'),(19,'Email','admin@afrilink.co.tz','Your Service Request Has Been Approved: FR-260824-001','Great news! Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) has been reviewed and approved. Please log in to the Partner Portal to generate and upload your signed Service Order Form (SOF) to proceed.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:11:29'),(20,'Email','john.kam@neilosnetwork.co.tz','Signed SOF Received: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) — Partner has uploaded the signed SOF. Please review, countersign, and upload the Neilos copy to proceed to project.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:12:40'),(21,'Email','admin@afrilink.co.tz','SOF Executed — Installation Will Begin: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) — The Service Order Form has been executed by both parties. Our installation team will contact you to schedule site access.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:14:57'),(22,'Email','pm@neilosnetwork.co.tz','New Installation Order: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) is ready for project assignment. SOF is countersigned. Please assign a contractor and begin installation.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:14:57'),(23,'Email','pm@neilosnetwork.co.tz','Order Released to Installation: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) has been released to installation. Please assign a contractor as soon as possible.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:15:21'),(24,'Email','pm@neilosnetwork.co.tz','Installation Completed — Review Required: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) — Contractor has submitted the installation as complete. Please review evidence and approve for UAT.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:24:19'),(25,'Email','comfortmnyinga@gmail.com','Testing Required: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) is ready for testing review. Contractor has submitted completion.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:24:19'),(26,'Email','pm@neilosnetwork.co.tz','Installation Completed — Review Required: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) — Contractor has submitted the installation as complete. Please review evidence and approve for UAT.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:26:12'),(27,'Email','comfortmnyinga@gmail.com','Testing Required: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) is ready for testing review. Contractor has submitted completion.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:26:12'),(28,'Email','admin@afrilink.co.tz','Your Service Is Ready for Acceptance: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) — Installation is complete and has passed our internal testing. Please log in to the Partner Portal within 48 hours to accept the service or return it for correction. If no response is received within 48 hours, the service will be automatically accepted.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:27:18'),(29,'Email','pm@neilosnetwork.co.tz','UAT Rejected — Returned to Installation: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) — Partner has returned the service from UAT to installation for corrections. Please review their remarks and reassign.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:28:13'),(30,'Email','comfortmnyinga@gmail.com','UAT Returned: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) has been returned from UAT by the partner. Installation corrections required.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:28:13'),(31,'Email','admin@afrilink.co.tz','Your Service Is Ready for Acceptance: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) — Installation is complete and has passed our internal testing. Please log in to the Partner Portal within 48 hours to accept the service or return it for correction. If no response is received within 48 hours, the service will be automatically accepted.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:29:42'),(32,'Email','john.kam@neilosnetwork.co.tz','Order Closed — Service Accepted: FR-260824-001','Order FR-260824-001 — Magari Mtaaani (Layer 2 ( last mile)) has been accepted by the partner. Order is now CLOSED. Billing start date: 24 Aug 2026.','order',1,'Queued',0,NULL,NULL,'2026-08-24 21:30:20'),(33,'Email','comfortmnyinga@gmail.com','New Feasibility Request: FR-260902-001','Order FR-260902-001 — John Timonth  (Layer 2 ( last mile)) submitted by partner. Please review technical feasibility.','order',3,'Queued',0,NULL,NULL,'2026-09-02 20:10:57'),(34,'Email','comfortmnyinga@gmail.com','New Feasibility Request: FR-260903-001','Order FR-260903-001 — patner A (Layer 2 ( last mile)) submitted by partner. Please review technical feasibility.','order',4,'Queued',0,NULL,NULL,'2026-09-03 10:22:59'),(35,'Email','comfortmnyinga@gmail.com','New Feasibility Request: FR-260903-002','Order FR-260903-002 — patner A (Layer 2 ( last mile)) submitted by partner. Please review technical feasibility.','order',5,'Queued',0,NULL,NULL,'2026-09-03 10:23:01'),(36,'Email','chamuedwin@gmail.com','Your Service Request Has Been Approved: FR-260903-001','Great news! Order FR-260903-001 — patner A (Layer 2 ( last mile)) has been reviewed and approved. Please log in to the Partner Portal to generate and upload your signed Service Order Form (SOF) to proceed.','order',4,'Queued',0,NULL,NULL,'2026-09-03 10:37:07'),(37,'Email','john.kam@neilosnetwork.co.tz','Signed SOF Received: FR-260903-001','Order FR-260903-001 — patner A (Layer 2 ( last mile)) — Partner has uploaded the signed SOF. Please review, countersign, and upload the Neilos copy to proceed to project.','order',4,'Queued',0,NULL,NULL,'2026-09-03 10:48:43'),(38,'Email','chamuedwin@gmail.com','SOF Executed — Installation Will Begin: FR-260903-001','Order FR-260903-001 — patner A (Layer 2 ( last mile)) — The Service Order Form has been executed by both parties. Our installation team will contact you to schedule site access.','order',4,'Queued',0,NULL,NULL,'2026-09-03 10:51:48'),(39,'Email','pm@neilosnetwork.co.tz','New Installation Order: FR-260903-001','Order FR-260903-001 — patner A (Layer 2 ( last mile)) is ready for project assignment. SOF is countersigned. Please assign a contractor and begin installation.','order',4,'Queued',0,NULL,NULL,'2026-09-03 10:51:48'),(40,'Email','pm@neilosnetwork.co.tz','Order Released to Installation: FR-260903-001','Order FR-260903-001 — patner A (Layer 2 ( last mile)) has been released to installation. Please assign a contractor as soon as possible.','order',4,'Queued',0,NULL,NULL,'2026-09-03 10:52:39'),(41,'Email','chamuedwin@gmail.com','Your Service Is Ready for Acceptance: FR-260903-001','Order FR-260903-001 — patner A (Layer 2 ( last mile)) — Installation is complete and has passed our internal testing. Please log in to the Partner Portal within 48 hours to accept the service or return it for correction. If no response is received within 48 hours, the service will be automatically accepted.','order',4,'Queued',0,NULL,NULL,'2026-09-03 11:09:58'),(42,'Email','john.kam@neilosnetwork.co.tz','Order Closed — Service Accepted: FR-260903-001','Order FR-260903-001 — patner A (Layer 2 ( last mile)) has been accepted by the partner. Order is now CLOSED. Billing start date: 03 Sep 2026.','order',4,'Queued',0,NULL,NULL,'2026-09-03 11:11:33'),(43,'Email','admin@afrilink.co.tz','Your Service Request Has Been Approved: FR-260903-003','Great news! Order FR-260903-003 — Acme Telecom Ltd (FTTH) has been reviewed and approved. Please log in to the Partner Portal to generate and upload your signed Service Order Form (SOF) to proceed.','order',6,'Queued',0,NULL,NULL,'2026-09-03 19:40:03'),(44,'Email','john.kam@neilosnetwork.co.tz','Signed SOF Received: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) — Partner has uploaded the signed SOF. Please review, countersign, and upload the Neilos copy to proceed to project.','order',6,'Queued',0,NULL,NULL,'2026-09-03 19:44:55'),(45,'Email','john.kam@neilosnetwork.co.tz','Signed SOF Received: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) — Partner has uploaded the signed SOF. Please review, countersign, and upload the Neilos copy to proceed to project.','order',6,'Queued',0,NULL,NULL,'2026-09-03 19:45:47'),(46,'Email','admin@afrilink.co.tz','SOF Executed — Installation Will Begin: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) — The Service Order Form has been executed by both parties. Our installation team will contact you to schedule site access.','order',6,'Queued',0,NULL,NULL,'2026-09-03 19:46:14'),(47,'Email','pm@neilosnetwork.co.tz','New Installation Order: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) is ready for project assignment. SOF is countersigned. Please assign a contractor and begin installation.','order',6,'Queued',0,NULL,NULL,'2026-09-03 19:46:14'),(48,'Email','pm@neilosnetwork.co.tz','Order Released to Installation: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) has been released to installation. Please assign a contractor as soon as possible.','order',6,'Queued',0,NULL,NULL,'2026-09-03 19:46:22'),(49,'Email','pm@neilosnetwork.co.tz','Installation Completed — Review Required: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) — Contractor has submitted the installation as complete. Please review evidence and approve for UAT.','order',6,'Queued',0,NULL,NULL,'2026-09-03 19:53:53'),(50,'Email','comfortmnyinga@gmail.com','Testing Required: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) is ready for testing review. Contractor has submitted completion.','order',6,'Queued',0,NULL,NULL,'2026-09-03 19:53:53'),(51,'Email','admin@afrilink.co.tz','Your Service Is Ready for Acceptance: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) — Installation is complete and has passed our internal testing. Please log in to the Partner Portal within 48 hours to accept the service or return it for correction. If no response is received within 48 hours, the service will be automatically accepted.','order',6,'Queued',0,NULL,NULL,'2026-09-03 19:55:43'),(52,'Email','admin@fastnet.co.tz','Your Service Request Has Been Approved: FR-260902-001','Great news! Order FR-260902-001 — John Timonth  (Layer 2 ( last mile)) has been reviewed and approved. Please log in to the Partner Portal to generate and upload your signed Service Order Form (SOF) to proceed.','order',3,'Queued',0,NULL,NULL,'2026-09-03 20:04:22'),(53,'Email','pm@neilosnetwork.co.tz','UAT Rejected — Returned to Installation: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) — Partner has returned the service from UAT to installation for corrections. Please review their remarks and reassign.','order',6,'Queued',0,NULL,NULL,'2026-09-03 20:10:51'),(54,'Email','comfortmnyinga@gmail.com','UAT Returned: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) has been returned from UAT by the partner. Installation corrections required.','order',6,'Queued',0,NULL,NULL,'2026-09-03 20:10:51'),(55,'Email','pm@neilosnetwork.co.tz','Installation Completed — Review Required: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) — Contractor has submitted the installation as complete. Please review evidence and approve for UAT.','order',6,'Queued',0,NULL,NULL,'2026-09-03 20:12:12'),(56,'Email','comfortmnyinga@gmail.com','Testing Required: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) is ready for testing review. Contractor has submitted completion.','order',6,'Queued',0,NULL,NULL,'2026-09-03 20:12:12'),(57,'Email','admin@afrilink.co.tz','Your Service Is Ready for Acceptance: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) — Installation is complete and has passed our internal testing. Please log in to the Partner Portal within 48 hours to accept the service or return it for correction. If no response is received within 48 hours, the service will be automatically accepted.','order',6,'Queued',0,NULL,NULL,'2026-09-03 20:13:06'),(58,'Email','admin@fiberworks.co.tz','KYC Application Approved — Fiber Works Ltd','Your KYC application #2 has been successfully approved.','kyc',2,'Queued',0,NULL,NULL,'2026-09-03 20:15:46'),(59,'Email','admin@neilos.co.tz','KYC Approved — Fiber Works Ltd','KYC Application #2 for Fiber Works Ltd was approved by the partner/contractor.','kyc',2,'Queued',0,NULL,NULL,'2026-09-03 20:15:46'),(60,'Email','management@neilos.co.tz','KYC Approved — Fiber Works Ltd','KYC Application #2 for Fiber Works Ltd was approved by the partner/contractor.','kyc',2,'Queued',0,NULL,NULL,'2026-09-03 20:15:46'),(61,'Email','john.kam@neilosnetwork.co.tz','Order Closed — Service Accepted: FR-260903-003','Order FR-260903-003 — Acme Telecom Ltd (FTTH) has been accepted by the partner. Order is now CLOSED. Billing start date: 07 Sep 2026.','order',6,'Queued',0,NULL,NULL,'2026-09-07 08:51:30'),(62,'Email','comfortmnyinga@gmail.com','New Feasibility Request: FR-260907-001','Order FR-260907-001 — AIDA ROBERT (Layer 2 ( last mile)) submitted by partner. Please review technical feasibility.','order',7,'Queued',0,NULL,NULL,'2026-09-07 09:20:02'),(63,'Email','manager@neilosnetwork.co.tz','Exception Approval Required: FR-260907-001','Order FR-260907-001 — AIDA ROBERT (Layer 2 ( last mile)) requires your exception approval for non-standard commercial terms. KAM: . Please log in to review and approve.','order',7,'Queued',0,NULL,NULL,'2026-09-07 09:22:44'),(64,'Email','comfortmnyinga@gmail.com','New Feasibility Request: FR-260907-002','Order FR-260907-002 — New Customer (FTTH) submitted by partner. Please review technical feasibility.','order',8,'Queued',0,NULL,NULL,'2026-09-07 11:07:25'),(65,'Email','manager@neilosnetwork.co.tz','Exception Approval Required: FR-260907-002','Order FR-260907-002 — New Customer (FTTH) requires your exception approval for non-standard commercial terms. KAM: . Please log in to review and approve.','order',8,'Queued',0,NULL,NULL,'2026-09-07 11:16:59'),(66,'Email','sahu@flashnet.co.tz','KYC Application Submitted for Review — FLASHNET TECHNOLOGIES LIMITED','Your KYC application has been submitted for approval. Please log into the portal to review and approve/reject.','kyc',4,'Queued',0,NULL,NULL,'2026-09-07 12:12:36'),(67,'Email','admin@neilos.co.tz','KYC Application Submitted — FLASHNET TECHNOLOGIES LIMITED','KYC Application #4 for FLASHNET TECHNOLOGIES LIMITED has been submitted for approval.','kyc',4,'Queued',0,NULL,NULL,'2026-09-07 12:12:36'),(68,'Email','management@neilos.co.tz','KYC Application Submitted — FLASHNET TECHNOLOGIES LIMITED','KYC Application #4 for FLASHNET TECHNOLOGIES LIMITED has been submitted for approval.','kyc',4,'Queued',0,NULL,NULL,'2026-09-07 12:12:36'),(69,'Email','comfortmnyinga@gmail.com','New Feasibility Request: FR-260909-001','Order FR-260909-001 — BEN (Layer 2 ( last mile)) submitted by partner. Please review technical feasibility.','order',9,'Queued',0,NULL,NULL,'2026-09-09 10:21:43'),(70,'Email','sahu@flashnet.co.tz','Your Service Request Has Been Approved: FR-260909-001','Great news! Order FR-260909-001 — BEN (Layer 2 ( last mile)) has been reviewed and approved. Please log in to the Partner Portal to generate and upload your signed Service Order Form (SOF) to proceed.','order',9,'Queued',0,NULL,NULL,'2026-09-09 10:26:29'),(71,'Email','john.kam@neilosnetwork.co.tz','Signed SOF Received: FR-260909-001','Order FR-260909-001 — BEN (Layer 2 ( last mile)) — Partner has uploaded the signed SOF. Please review, countersign, and upload the Neilos copy to proceed to project.','order',9,'Queued',0,NULL,NULL,'2026-09-09 10:33:23'),(72,'Email','sahu@flashnet.co.tz','SOF Executed — Installation Will Begin: FR-260909-001','Order FR-260909-001 — BEN (Layer 2 ( last mile)) — The Service Order Form has been executed by both parties. Our installation team will contact you to schedule site access.','order',9,'Queued',0,NULL,NULL,'2026-09-09 10:34:38'),(73,'Email','pm@neilosnetwork.co.tz','New Installation Order: FR-260909-001','Order FR-260909-001 — BEN (Layer 2 ( last mile)) is ready for project assignment. SOF is countersigned. Please assign a contractor and begin installation.','order',9,'Queued',0,NULL,NULL,'2026-09-09 10:34:38'),(74,'Email','pm@neilosnetwork.co.tz','Order Released to Installation: FR-260909-001','Order FR-260909-001 — BEN (Layer 2 ( last mile)) has been released to installation. Please assign a contractor as soon as possible.','order',9,'Queued',0,NULL,NULL,'2026-09-09 10:35:10'),(75,'Email','pm@neilosnetwork.co.tz','Installation Completed — Review Required: FR-260909-001','Order FR-260909-001 — BEN (Layer 2 ( last mile)) — Contractor has submitted the installation as complete. Please review evidence and approve for UAT.','order',9,'Queued',0,NULL,NULL,'2026-09-09 10:39:44'),(76,'Email','comfortmnyinga@gmail.com','Testing Required: FR-260909-001','Order FR-260909-001 — BEN (Layer 2 ( last mile)) is ready for testing review. Contractor has submitted completion.','order',9,'Queued',0,NULL,NULL,'2026-09-09 10:39:44'),(77,'Email','sahu@flashnet.co.tz','Your Service Is Ready for Acceptance: FR-260909-001','Order FR-260909-001 — BEN (Layer 2 ( last mile)) — Installation is complete and has passed our internal testing. Please log in to the Partner Portal within 48 hours to accept the service or return it for correction. If no response is received within 48 hours, the service will be automatically accepted.','order',9,'Queued',0,NULL,NULL,'2026-09-09 10:40:18'),(78,'Email','john.kam@neilosnetwork.co.tz','Order Closed — Service Accepted: FR-260909-001','Order FR-260909-001 — BEN (Layer 2 ( last mile)) has been accepted by the partner. Order is now CLOSED. Billing start date: 09 Sep 2026.','order',9,'Queued',0,NULL,NULL,'2026-09-09 10:42:06'),(79,'Email','hellen@gmail.com','KYC Application Submitted for Review — Hellen','Your KYC application has been submitted for approval. Please log into the portal to review and approve/reject.','kyc',7,'Queued',0,NULL,NULL,'2026-09-10 08:20:41'),(80,'Email','admin@neilos.co.tz','KYC Application Submitted — Hellen','KYC Application #7 for Hellen has been submitted for approval.','kyc',7,'Queued',0,NULL,NULL,'2026-09-10 08:20:41'),(81,'Email','management@neilos.co.tz','KYC Application Submitted — Hellen','KYC Application #7 for Hellen has been submitted for approval.','kyc',7,'Queued',0,NULL,NULL,'2026-09-10 08:20:41');
/*!40000 ALTER TABLE `notification_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(500) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_read` (`user_id`,`is_read`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_documents`
--

DROP TABLE IF EXISTS `order_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `doc_type` enum('sof','feasibility_report','diagram','uat_signoff','completion_certificate','invoice','evidence','countersigned_sof','other') NOT NULL DEFAULT 'other',
  `evidence_category` varchar(100) DEFAULT NULL COMMENT 'Links to evidence checklist type for multi-file support',
  `is_partner_visible` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'If 1, partner can see this doc',
  `document_type` varchar(100) DEFAULT NULL COMMENT 'Legacy friendly name',
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `uploaded_by` int(10) unsigned NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `idx_order_doc` (`order_id`,`doc_type`),
  CONSTRAINT `order_documents_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_documents_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_documents`
--

LOCK TABLES `order_documents` WRITE;
/*!40000 ALTER TABLE `order_documents` DISABLE KEYS */;
INSERT INTO `order_documents` VALUES (1,1,'other',NULL,0,'Supporting Document','SOD.pdf','uploads/orders/1/a5ca6ee192db8acd1432626624a72585.pdf',284124,7,'2026-08-24 20:54:41'),(2,1,'sof',NULL,0,'Signed SOF','SAF.pdf','uploads/orders/1/sof/f886204c2b1bbad4214aed58ce8173cc.pdf',286809,7,'2026-08-24 21:12:40'),(3,1,'countersigned_sof',NULL,0,'Countersigned SOF','SAF.pdf','uploads/orders/1/sof/a0f3c1a515a36c7d37b4ae263e671f80.pdf',286809,2,'2026-08-24 21:14:56'),(4,4,'sof',NULL,0,'Signed SOF','Test.pdf','uploads/orders/4/sof/f4b26cf5aa627da1d1a7d18df44800f9.pdf',14865,1,'2026-09-03 10:48:43'),(5,4,'countersigned_sof',NULL,0,'Countersigned SOF','Test.pdf','uploads/orders/4/sof/aa68cfe981266113f1c81aa295e65613.pdf',14865,1,'2026-09-03 10:51:48'),(7,6,'sof',NULL,0,'Signed SOF','yes.pdf','uploads/orders/6/sof/01f020eef3050dd72cc39202ac079784.pdf',282756,1,'2026-09-03 19:45:47'),(8,6,'countersigned_sof',NULL,0,'Countersigned SOF','yes.pdf','uploads/orders/6/sof/9b6e44727575f52cb32c648b02ef3a78.pdf',282756,1,'2026-09-03 19:46:14'),(9,9,'sof',NULL,0,'Signed SOF','SOF TEST.pdf','uploads/orders/9/sof/d635c73333750eb8e562f9e7e6a0bab3.pdf',285721,1,'2026-09-09 10:33:23'),(10,9,'countersigned_sof',NULL,0,'Countersigned SOF','SOF TEST.pdf','uploads/orders/9/sof/ca8fe6fd9bcf4872bd505de5d60a2616.pdf',285721,1,'2026-09-09 10:34:38');
/*!40000 ALTER TABLE `order_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_returns`
--

DROP TABLE IF EXISTS `order_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_returns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `returned_by` int(10) unsigned NOT NULL,
  `returned_at` datetime DEFAULT current_timestamp(),
  `from_status` varchar(100) NOT NULL,
  `to_status` varchar(100) NOT NULL,
  `return_reason` varchar(200) NOT NULL,
  `return_remarks` text DEFAULT NULL,
  `routed_to` enum('BSA','KAM','Project Manager','Contractor','Partner') NOT NULL,
  `old_nrc` decimal(12,2) DEFAULT NULL,
  `new_nrc` decimal(12,2) DEFAULT NULL,
  `old_mrc` decimal(12,2) DEFAULT NULL,
  `new_mrc` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `returned_by` (`returned_by`),
  KEY `idx_order` (`order_id`),
  CONSTRAINT `order_returns_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_returns_ibfk_2` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_returns`
--

LOCK TABLES `order_returns` WRITE;
/*!40000 ALTER TABLE `order_returns` DISABLE KEYS */;
INSERT INTO `order_returns` VALUES (1,1,7,'2026-08-24 21:09:32','Pending SOF','Await Commercial Approval','Partner not satisfied with pricing','sijapenda hela','KAM',220000.00,NULL,220000.00,NULL),(2,1,7,'2026-08-24 21:28:13','UAT','Installation','Quality concern','do it','Project Manager',NULL,NULL,NULL,NULL),(3,6,7,'2026-09-03 20:10:51','UAT','Installation','Quality concern','bado','Project Manager',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `order_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_timeline`
--

DROP TABLE IF EXISTS `order_timeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_timeline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `status` varchar(100) NOT NULL,
  `note` text DEFAULT NULL,
  `changed_by` int(10) unsigned DEFAULT NULL,
  `changed_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `changed_by` (`changed_by`),
  KEY `idx_order_status` (`order_id`,`status`),
  KEY `idx_changed_at` (`changed_at`),
  CONSTRAINT `order_timeline_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_timeline_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_timeline`
--

LOCK TABLES `order_timeline` WRITE;
/*!40000 ALTER TABLE `order_timeline` DISABLE KEYS */;
INSERT INTO `order_timeline` VALUES (1,1,'Feasibility Review','Feasibility request submitted by partner.',7,'2026-08-24 20:54:41'),(2,1,'Management Approval','BSA provided NRC discount (220000 vs standard 250000) — routed to Management Approval.',3,'2026-08-24 20:58:27'),(3,1,'Pending SOF','Management approved with revised pricing: NRC TZS 220,000, MRC TZS 200,000.',10,'2026-08-24 21:05:41'),(4,1,'Await Commercial Approval','Partner not satisfied — returned to Account Manager: sijapenda hela',7,'2026-08-24 21:09:32'),(5,1,'Pending SOF','KAM: Commercial approved at standard pricing. Partner notified for SOF signature.',2,'2026-08-24 21:11:29'),(6,1,'SOF Review','Partner uploaded signed SOF. Awaiting Neilos countersignature.',7,'2026-08-24 21:12:40'),(7,1,'SOF Review','Countersigned SOF uploaded by KAM. Ready to proceed to project.',2,'2026-08-24 21:14:56'),(8,1,'Installation','Countersigned SOF verified — order released to Project Installation.',2,'2026-08-24 21:15:21'),(9,1,'Installation','Contractor assigned (partner #4).',11,'2026-08-24 21:16:22'),(10,1,'Installation','Job assignment accepted.',13,'2026-08-24 21:17:40'),(11,1,'Installation','SLA paused — installation blocker posted.',13,'2026-08-24 21:22:39'),(12,1,'Installation','Contractor blocker: Mvua [Reason: Weather]',13,'2026-08-24 21:22:39'),(13,1,'Installation','SLA resumed — paused for 0.02 hours. Total paused: 0.02 hrs.',13,'2026-08-24 21:23:51'),(14,1,'Testing','Job completion submitted. Awaiting PM/BSA testing review.',13,'2026-08-24 21:24:19'),(15,1,'Installation','Returned to contractor: redo',11,'2026-08-24 21:25:30'),(16,1,'Testing','Job completion submitted. Awaiting PM/BSA testing review.',13,'2026-08-24 21:26:12'),(17,1,'Testing','NOC IP configuration marked as COMPLETE — Speed Test and Ping Test evidence are now required.',11,'2026-08-24 21:26:57'),(18,1,'UAT','Testing approved (NOC IP configured). Partner notified for UAT acceptance (72hr window).',11,'2026-08-24 21:27:17'),(19,1,'Installation','Partner returned the service to Installation during the UAT acceptance window.',7,'2026-08-24 21:28:13'),(20,1,'Testing','Job completion submitted by Project Manager. Awaiting Testing — Internal Review.',11,'2026-08-24 21:29:15'),(21,1,'UAT','Testing approved (NOC IP configured). Partner notified for UAT acceptance (72hr window).',11,'2026-08-24 21:29:42'),(22,1,'Closed','Partner accepted service. Order closed. Closed Date: 2026-08-24. Billing Start Date: 2026-08-24.',7,'2026-08-24 21:30:19'),(24,1,'Closed','Closed order modified by System Administrator (Admin).\nAudit Reason: Yes\nModifications: Active Status: Inactive → Active',1,'2026-08-29 23:16:48'),(25,3,'Feasibility Review','Feasibility request submitted by partner.',6,'2026-09-02 20:10:57'),(26,3,'Await Commercial Approval','BSA marked technically feasible — pending KAM commercial approval.',3,'2026-09-02 20:17:05'),(27,4,'Feasibility Review','Feasibility request submitted by partner.',19,'2026-09-03 10:22:59'),(28,5,'Feasibility Review','Feasibility request submitted by partner.',19,'2026-09-03 10:23:01'),(29,4,'Await Commercial Approval','BSA marked technically feasible — pending KAM commercial approval.',20,'2026-09-03 10:32:14'),(30,4,'Pending SOF','KAM: Commercial approved at standard pricing. Partner notified for SOF signature.',16,'2026-09-03 10:37:07'),(31,4,'SOF Review','Partner uploaded signed SOF. Awaiting Neilos countersignature.',1,'2026-09-03 10:48:43'),(32,4,'SOF Review','Countersigned SOF uploaded by System Admin. Ready to proceed to project.',1,'2026-09-03 10:51:48'),(33,4,'Installation','Countersigned SOF verified — order released to Project Installation.',1,'2026-09-03 10:52:39'),(34,4,'Installation','Contractor assigned (partner #4).',15,'2026-09-03 11:01:14'),(35,4,'Testing','Job completion submitted by Project Manager. Awaiting Testing — Internal Review.',1,'2026-09-03 11:07:10'),(36,4,'UAT','Testing approved (NOC IP configured). Partner notified for UAT acceptance (72hr window).',15,'2026-09-03 11:09:57'),(37,4,'Closed','Partner accepted service. Order closed. Closed Date: 2026-09-03. Billing Start Date: 2026-09-03.',19,'2026-09-03 11:11:33'),(38,6,'Feasibility Review','Order created via FTTH bulk upload by Partner Admin (Afrilink).',7,'2026-09-03 19:37:04'),(39,6,'Await Commercial Approval','BSA marked technically feasible — pending KAM commercial approval.',1,'2026-09-03 19:39:34'),(40,6,'Pending SOF','KAM: Commercial approved at standard pricing. Partner notified for SOF signature.',1,'2026-09-03 19:40:03'),(41,6,'SOF Review','Partner uploaded signed SOF. Awaiting Neilos countersignature.',1,'2026-09-03 19:44:55'),(42,6,'SOF Review','Partner uploaded signed SOF. Awaiting Neilos countersignature.',1,'2026-09-03 19:45:47'),(43,6,'SOF Review','Countersigned SOF uploaded by System Admin. Ready to proceed to project.',1,'2026-09-03 19:46:14'),(44,6,'Installation','Countersigned SOF verified — order released to Project Installation.',1,'2026-09-03 19:46:22'),(45,6,'Installation','Contractor assigned (partner #4).',11,'2026-09-03 19:49:06'),(46,6,'Installation','Job assignment accepted.',13,'2026-09-03 19:50:13'),(47,6,'Testing','Job completion submitted. Awaiting PM/BSA testing review.',13,'2026-09-03 19:53:53'),(48,6,'UAT','Testing approved (NOC IP configured). Partner notified for UAT acceptance (72hr window).',11,'2026-09-03 19:55:43'),(49,3,'Pending SOF','KAM: Commercial approved at standard pricing. Partner notified for SOF signature.',1,'2026-09-03 20:04:22'),(50,6,'Installation','Partner returned the service to Installation during the UAT acceptance window.',7,'2026-09-03 20:10:51'),(51,6,'Testing','Job completion submitted. Awaiting PM/BSA testing review.',11,'2026-09-03 20:12:12'),(52,6,'UAT','Testing approved (NOC IP configured). Partner notified for UAT acceptance (72hr window).',11,'2026-09-03 20:13:06'),(53,6,'Closed','Service automatically accepted after the 72-hour UAT acceptance window expired. Order closed. Closed Date: 2026-09-07. Billing Start Date: 2026-09-07.',NULL,'2026-09-07 08:51:30'),(54,7,'Feasibility Review','Feasibility request submitted by partner.',19,'2026-09-07 09:20:02'),(55,7,'Management Approval','BSA provided NRC discount (100000 vs standard 250000) — routed to Management Approval.',20,'2026-09-07 09:22:44'),(56,8,'Feasibility Review','Feasibility request submitted by partner.',19,'2026-09-07 11:07:25'),(57,8,'Await Commercial Approval','BSA marked technically feasible — pending KAM commercial approval.',20,'2026-09-07 11:10:00'),(58,8,'Management Approval','KAM submitted pricing exception (NRC: TZS 200,000, MRC: TZS 30,000) — routed to Management Approval.',16,'2026-09-07 11:16:59'),(59,8,'Pending SOF','Management approved pricing as requested by KAM.',1,'2026-09-07 11:20:42'),(60,8,'Pending SOF','Management approved pricing as requested by KAM.',1,'2026-09-07 11:20:55'),(61,9,'Feasibility Review','Feasibility request submitted by partner.',22,'2026-09-09 10:21:43'),(62,9,'Await Commercial Approval','BSA marked technically feasible — pending KAM commercial approval.',20,'2026-09-09 10:24:45'),(63,9,'Pending SOF','KAM: Commercial approved at standard pricing. Partner notified for SOF signature.',16,'2026-09-09 10:26:29'),(64,9,'SOF Review','Partner uploaded signed SOF. Awaiting Neilos countersignature.',1,'2026-09-09 10:33:23'),(65,9,'SOF Review','Countersigned SOF uploaded by System Admin. Ready to proceed to project.',1,'2026-09-09 10:34:38'),(66,9,'Installation','Countersigned SOF verified — order released to Project Installation.',1,'2026-09-09 10:35:10'),(67,9,'Installation','Contractor assigned (partner #4).',1,'2026-09-09 10:36:16'),(68,9,'Testing','Job completion submitted. Awaiting PM/BSA testing review.',1,'2026-09-09 10:39:44'),(69,9,'UAT','Testing approved (NOC IP configured). Partner notified for UAT acceptance (72hr window).',1,'2026-09-09 10:40:18'),(70,9,'Closed','Partner accepted service. Order closed. Closed Date: 2026-09-09. Billing Start Date: 2026-09-09.',22,'2026-09-09 10:42:06');
/*!40000 ALTER TABLE `order_timeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `sof_number` varchar(50) DEFAULT NULL COMMENT 'SO-prefixed reference generated at SOF print',
  `partner_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `service_id` varchar(100) DEFAULT NULL,
  `capacity` int(10) unsigned DEFAULT 0,
  `capacity_unit` varchar(20) DEFAULT 'Mbps',
  `pop_location` varchar(200) DEFAULT NULL,
  `customer_name` varchar(200) NOT NULL,
  `customer_contact_name` varchar(200) DEFAULT NULL,
  `customer_contact_phone` varchar(50) DEFAULT NULL,
  `customer_contact_email` varchar(200) DEFAULT NULL,
  `customer_location` varchar(255) DEFAULT NULL,
  `building_name` varchar(200) DEFAULT NULL,
  `floor_number` varchar(50) DEFAULT NULL,
  `apartment_number` varchar(50) DEFAULT NULL,
  `end_user_address` text DEFAULT NULL,
  `city_region` varchar(100) DEFAULT NULL,
  `gps_coordinates` varchar(100) DEFAULT NULL,
  `site_category` varchar(100) DEFAULT NULL,
  `interface_type` varchar(50) DEFAULT 'SFP',
  `connector_type` varchar(50) DEFAULT 'LC',
  `media_type` varchar(50) DEFAULT 'Single-mode Fiber',
  `power_type` varchar(50) DEFAULT 'AC 220V',
  `rack_space` varchar(50) DEFAULT NULL,
  `nrc_usd` decimal(12,2) NOT NULL DEFAULT 0.00,
  `mrc_usd` decimal(12,2) NOT NULL DEFAULT 0.00,
  `vat_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_mrc_incl_vat` decimal(12,2) NOT NULL DEFAULT 0.00,
  `standard_mrc` decimal(12,2) DEFAULT NULL,
  `revised_mrc` decimal(12,2) DEFAULT NULL,
  `mrc_justification` text DEFAULT NULL,
  `kam_approved_at` datetime DEFAULT NULL,
  `kam_approved_by` int(10) unsigned DEFAULT NULL,
  `kam_proposed_nrc` decimal(14,2) DEFAULT NULL COMMENT 'KAM exception NRC proposal',
  `kam_proposed_mrc` decimal(14,2) DEFAULT NULL COMMENT 'KAM exception MRC proposal',
  `kam_commercial_justification` text DEFAULT NULL COMMENT 'Mandatory when KAM proposes exception',
  `kam_remarks` text DEFAULT NULL COMMENT 'Optional remarks from KAM',
  `management_approved_at` datetime DEFAULT NULL,
  `management_approved_by` int(10) unsigned DEFAULT NULL,
  `management_approved_price` decimal(12,2) DEFAULT NULL,
  `management_final_nrc` decimal(14,2) DEFAULT NULL COMMENT 'Management final NRC when using Approve with Revised Price',
  `management_final_mrc` decimal(14,2) DEFAULT NULL COMMENT 'Management final MRC when using Approve with Revised Price',
  `management_decision` enum('Approve as Requested','Approve with Revised Price','Keep Standard Price','Return to KAM') DEFAULT NULL,
  `management_remarks` text DEFAULT NULL,
  `management_return_remarks` text DEFAULT NULL COMMENT 'Remarks when Management returns to KAM',
  `management_remarks_visible` tinyint(1) DEFAULT 0,
  `sof_generated_at` datetime DEFAULT NULL,
  `sof_uploaded_at` datetime DEFAULT NULL,
  `sof_signed_file` varchar(500) DEFAULT NULL,
  `sof_signed_filename` varchar(255) DEFAULT NULL,
  `countersigned_sof_at` datetime DEFAULT NULL,
  `countersigned_sof_file` varchar(500) DEFAULT NULL,
  `countersigned_sof_filename` varchar(255) DEFAULT NULL,
  `countersigned_sof_by` int(10) unsigned DEFAULT NULL,
  `sof_return_comments` text DEFAULT NULL,
  `return_reason` varchar(100) DEFAULT NULL,
  `return_remarks` text DEFAULT NULL,
  `return_route` enum('BSA','KAM') DEFAULT NULL,
  `returned_by` int(10) unsigned DEFAULT NULL,
  `returned_at` datetime DEFAULT NULL,
  `service_type` varchar(100) NOT NULL DEFAULT 'FTTH',
  `fttx_package` varchar(100) DEFAULT NULL,
  `bandwidth` varchar(100) DEFAULT NULL,
  `nni_location` varchar(200) DEFAULT NULL,
  `aggregate_capacity` varchar(100) DEFAULT NULL,
  `contract_term` varchar(50) DEFAULT NULL,
  `special_requirements` text DEFAULT NULL,
  `usd_tzs_rate` decimal(12,4) DEFAULT 2600.0000,
  `base_nrc_usd` decimal(14,2) DEFAULT 0.00,
  `remote_hands_nrc_usd` decimal(14,2) DEFAULT 0.00,
  `nrc_subtotal_usd` decimal(14,2) DEFAULT 0.00,
  `vat_on_nrc` decimal(14,2) DEFAULT 0.00,
  `total_nrc_incl_vat` decimal(14,2) DEFAULT 0.00,
  `base_mrc` decimal(14,2) DEFAULT 0.00,
  `mrc_currency` varchar(10) DEFAULT 'TZS',
  `discount_pct` decimal(5,2) DEFAULT 0.00,
  `discount_amount` decimal(14,2) DEFAULT 0.00,
  `vat_on_mrc` decimal(14,2) DEFAULT 0.00,
  `created_by` int(10) unsigned DEFAULT NULL,
  `assigned_kam_name` varchar(100) DEFAULT NULL,
  `kam_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Feasibility Review',
  `bsa_reviewed_by` int(10) unsigned DEFAULT NULL,
  `bsa_reviewed_at` datetime DEFAULT NULL,
  `bsa_feasi_approved` tinyint(1) DEFAULT NULL,
  `bsa_remarks` text DEFAULT NULL,
  `bsa_assigned_engineer` varchar(150) DEFAULT NULL,
  `bsa_target_completion_date` date DEFAULT NULL,
  `bsa_special_conditions` text DEFAULT NULL,
  `bsa_technical_result` enum('Technically Feasible','Technically Not Feasible') DEFAULT NULL,
  `bsa_not_feasible_reason` text DEFAULT NULL,
  `standard_nrc` decimal(12,2) DEFAULT 60.00,
  `revised_nrc` decimal(12,2) DEFAULT NULL,
  `nrc_justification` text DEFAULT NULL,
  `bsa_approved_at` datetime DEFAULT NULL,
  `bsa_approved_by` int(10) unsigned DEFAULT NULL,
  `bsa_revision_note` text DEFAULT NULL,
  `kam_reviewed_by` int(10) unsigned DEFAULT NULL,
  `kam_reviewed_at` datetime DEFAULT NULL,
  `commercial_discount_pct` decimal(5,2) DEFAULT 0.00,
  `closed_date` date DEFAULT NULL,
  `billing_start_date` date DEFAULT NULL,
  `billing_start_adjusted_by` int(10) unsigned DEFAULT NULL,
  `billing_start_adjusted_at` datetime DEFAULT NULL,
  `uat_submitted_at` datetime DEFAULT NULL,
  `uat_accepted_at` datetime DEFAULT NULL,
  `uat_accepted_by` int(10) unsigned DEFAULT NULL,
  `uat_rejected_at` datetime DEFAULT NULL,
  `uat_rejection_reason` text DEFAULT NULL,
  `uat_return_reason` text DEFAULT NULL,
  `uat_signoff_file` varchar(500) DEFAULT NULL,
  `billing_trigger_date` date DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `sla_paused` tinyint(1) NOT NULL DEFAULT 0,
  `sla_paused_at` datetime DEFAULT NULL,
  `sla_paused_hours` decimal(8,2) NOT NULL DEFAULT 0.00 COMMENT 'Accumulated paused hours',
  `noc_ip_configured` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'PM flag: NOC has completed IP configuration',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `sla_pause_reason` text DEFAULT NULL,
  `circuit_id` varchar(100) DEFAULT NULL,
  `uat_notified_at` datetime DEFAULT NULL,
  `uat_deadline` datetime DEFAULT NULL,
  `activation_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `user_id` (`user_id`),
  KEY `service_id` (`service_id`),
  KEY `bsa_reviewed_by` (`bsa_reviewed_by`),
  KEY `bsa_approved_by` (`bsa_approved_by`),
  KEY `kam_reviewed_by` (`kam_reviewed_by`),
  KEY `kam_approved_by` (`kam_approved_by`),
  KEY `management_approved_by` (`management_approved_by`),
  KEY `countersigned_sof_by` (`countersigned_sof_by`),
  KEY `returned_by` (`returned_by`),
  KEY `uat_accepted_by` (`uat_accepted_by`),
  KEY `billing_start_adjusted_by` (`billing_start_adjusted_by`),
  KEY `idx_order_number` (`order_number`),
  KEY `idx_status` (`status`),
  KEY `idx_partner` (`partner_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`),
  CONSTRAINT `orders_ibfk_10` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_11` FOREIGN KEY (`uat_accepted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_12` FOREIGN KEY (`billing_start_adjusted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `orders_ibfk_4` FOREIGN KEY (`bsa_reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_5` FOREIGN KEY (`bsa_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_6` FOREIGN KEY (`kam_reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_7` FOREIGN KEY (`kam_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_8` FOREIGN KEY (`management_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_9` FOREIGN KEY (`countersigned_sof_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'FR-260824-001','SO-260824-001',2,7,'SVC-260824-001',0,'Mbps',NULL,'Magari Mtaaani','Hellen','0623700877','erickmsolla0@gmail.com','Mwenge','Mwanga tower','3rd floor','15',NULL,NULL,'-6.7835, 39.2685','Commercial Building','SFP','LC','Single-mode Fiber','AC 220V',NULL,0.00,0.00,0.00,236000.00,220000.00,NULL,NULL,'2026-08-24 21:11:29',2,NULL,NULL,NULL,'','2026-08-24 21:05:41',10,200000.00,220000.00,200000.00,'Approve with Revised Price','',NULL,0,'2026-08-24 21:07:02','2026-08-24 21:12:40','uploads/orders/1/sof/f886204c2b1bbad4214aed58ce8173cc.pdf','SAF.pdf','2026-08-24 21:14:56','uploads/orders/1/sof/a0f3c1a515a36c7d37b4ae263e671f80.pdf','SAF.pdf',2,'sijapenda hela',NULL,NULL,'KAM',7,'2026-08-24 21:09:32','Layer 2 ( last mile)','','','Wingu','150','12 Months','',2585.0000,250000.00,80000.00,300000.00,54000.00,354000.00,220000.00,'TZS',0.00,0.00,36000.00,7,'John KAM',2,'Closed',3,'2026-08-24 20:58:27',NULL,NULL,NULL,NULL,'Distance','Technically Feasible',NULL,250000.00,220000.00,'Fibre 300m',NULL,NULL,NULL,NULL,NULL,0.00,'2026-08-24','2026-08-24',1,'2026-08-29 23:16:48','2026-08-24 21:29:42','2026-08-24 21:30:19',7,NULL,NULL,'do it',NULL,NULL,NULL,0,NULL,0.02,1,'2026-08-24 20:54:41','2026-08-29 23:16:48',NULL,'CKT-FR-260824-001','2026-08-24 21:29:42','2026-08-27 21:29:42','2026-08-24',1),(3,'FR-260902-001','SO-260908-002',1,6,NULL,0,'Mbps',NULL,'John Timonth ','john','098777787654','john@example123.co.tz','Boko','KFK Building ','16','',NULL,NULL,'-67776565.3867676','Multi Dwelling Unit (MDU)','SFP','LC','Single-mode Fiber','AC 220V',NULL,0.00,0.00,0.00,129800.00,110000.00,150000.00,NULL,'2026-09-03 20:04:22',1,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-09-08 15:50:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Layer 2 ( last mile)','','','Wingu DC','50','12 Months','',2585.0000,250000.00,0.00,300000.00,54000.00,354000.00,110000.00,'TZS',0.00,0.00,19800.00,6,'',NULL,'Pending SOF',3,'2026-09-02 20:17:05',NULL,NULL,NULL,NULL,'at this locaiton FAT ia more thn 150m','Technically Feasible',NULL,250000.00,300000.00,'extra cable pulling',NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.00,0,'2026-09-02 20:10:57','2026-09-08 15:50:14',NULL,'CKT-FR-260902-001',NULL,NULL,NULL,0),(4,'FR-260903-001','SO-260908-003',6,19,'SVC-260903-001',0,'Mbps',NULL,'patner A','dd','dd','chamuedwin@gmail.com','sss','sss','ddd','dd',NULL,NULL,'sss','Multi Dwelling Unit (MDU)','SFP','LC','Single-mode Fiber','AC 220V',NULL,0.00,0.00,0.00,129800.00,110000.00,NULL,NULL,'2026-09-03 10:37:07',16,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-09-08 15:50:14','2026-09-03 10:48:43','uploads/orders/4/sof/f4b26cf5aa627da1d1a7d18df44800f9.pdf','Test.pdf','2026-09-03 10:51:48','uploads/orders/4/sof/aa68cfe981266113f1c81aa295e65613.pdf','Test.pdf',1,NULL,NULL,NULL,NULL,NULL,NULL,'Layer 2 ( last mile)','','','Wingu','50','12 Months','no ',2585.0000,250000.00,0.00,250000.00,45000.00,295000.00,110000.00,'TZS',0.00,0.00,19800.00,19,'',NULL,'Closed',20,'2026-09-03 10:32:14',NULL,NULL,NULL,NULL,'It is Technically feasible, we can proceed with the next step','Technically Feasible',NULL,250000.00,NULL,'',NULL,NULL,NULL,NULL,NULL,0.00,'2026-09-03','2026-09-03',NULL,NULL,'2026-09-03 11:09:57','2026-09-03 11:11:33',19,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.00,0,'2026-09-03 10:22:59','2026-09-08 15:50:14',NULL,'CKT-FR-260903-001','2026-09-03 11:09:57','2026-09-06 11:09:57','2026-09-03',1),(5,'FR-260903-002','SO-260908-004',6,19,NULL,0,'Mbps',NULL,'patner A','dd','dd','chamuedwin@gmail.com','sss','sss','ddd','dd',NULL,NULL,'sss','Multi Dwelling Unit (MDU)','SFP','LC','Single-mode Fiber','AC 220V',NULL,0.00,0.00,0.00,129800.00,110000.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-09-08 15:50:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Layer 2 ( last mile)','','','Wingu','50','12 Months','no ',2585.0000,250000.00,0.00,250000.00,45000.00,295000.00,110000.00,'TZS',0.00,0.00,19800.00,19,'',NULL,'Feasibility Review',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,250000.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.00,0,'2026-09-03 10:23:01','2026-09-08 15:50:14',NULL,NULL,NULL,NULL,NULL,0),(6,'FR-260903-003','SO-260903-001',2,7,'SVC-260903-003',0,'Mbps',NULL,'Acme Telecom Ltd','John Doe','+255 712 345 678','john.doe@acme.co.tz','Msasani, Dar es Salaam',NULL,NULL,NULL,NULL,NULL,'−6.7835, 39.2685','Residential','SFP','LC','Single-mode Fiber','AC 220V',NULL,0.00,0.00,0.00,0.00,0.00,150000.00,NULL,'2026-09-03 19:40:03',1,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-09-03 19:40:20','2026-09-03 19:45:47','uploads/orders/6/sof/01f020eef3050dd72cc39202ac079784.pdf','yes.pdf','2026-09-03 19:46:14','uploads/orders/6/sof/9b6e44727575f52cb32c648b02ef3a78.pdf','yes.pdf',1,NULL,NULL,NULL,NULL,NULL,NULL,'FTTH',NULL,'10',NULL,NULL,'12 Months',NULL,1.0000,0.00,0.00,300000.00,54000.00,354000.00,0.00,'TZS',0.00,0.00,0.00,7,'John KAM',2,'Closed',1,'2026-09-03 19:39:34',NULL,NULL,NULL,NULL,'yes','Technically Feasible',NULL,0.00,300000.00,'extended fiber',NULL,NULL,NULL,NULL,NULL,0.00,'2026-09-07','2026-09-07',NULL,NULL,'2026-09-03 20:13:06','2026-09-07 08:51:30',NULL,NULL,NULL,'bado',NULL,NULL,NULL,0,NULL,0.00,0,'2026-09-03 19:37:04','2026-09-07 08:51:30',NULL,'CKT-FR-260903-003','2026-09-03 20:13:06','2026-09-06 20:13:06','2026-09-07',1),(7,'FR-260907-001','SO-260908-005',6,19,NULL,0,'Mbps',NULL,'AIDA ROBERT','Aida','078567000','ar@gmail.com','Mbweni','Derm','15','10',NULL,NULL,'sss','Multi Dwelling Unit (MDU)','SFP','LC','Single-mode Fiber','AC 220V',NULL,0.00,0.00,0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-09-08 15:50:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Layer 2 ( last mile)','','','','','','No',2585.0000,250000.00,0.00,100000.00,18000.00,118000.00,0.00,'TZS',0.00,0.00,0.00,19,'',NULL,'Management Approval',20,'2026-09-07 09:22:44',NULL,NULL,NULL,NULL,'Need 500m fibre drop','Technically Feasible',NULL,250000.00,100000.00,'Extended fibre 50m',NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.00,0,'2026-09-07 09:20:02','2026-09-08 15:50:14',NULL,'CKT-FR-260907-001',NULL,NULL,NULL,0),(8,'FR-260907-002','SO-260908-001',6,19,NULL,0,'Mbps',NULL,'New Customer','Aida','+255783402416','ar@gmail.com','Mbweni','Derm','15','10',NULL,NULL,'sss','Multi Dwelling Unit (MDU)','SFP','LC','Single-mode Fiber','AC 220V',NULL,0.00,0.00,0.00,35400.00,27500.00,NULL,NULL,'2026-09-07 11:16:59',16,200000.00,30000.00,'Extra cables to be used for installations','Kindly assist to fast track the installation as customer requested to be ready by 10th.','2026-09-07 11:20:55',1,30000.00,200000.00,30000.00,'Approve as Requested','',NULL,0,'2026-09-08 15:50:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'FTTH','FTTx-40','','','','12 Months','',2585.0000,140000.00,0.00,140000.00,25200.00,165200.00,27500.00,'TZS',0.00,0.00,5400.00,19,'',NULL,'Pending SOF',20,'2026-09-07 11:10:00',NULL,NULL,NULL,NULL,'ok','Technically Feasible',NULL,140000.00,200000.00,'',NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.00,0,'2026-09-07 11:07:25','2026-09-08 15:50:14',NULL,'CKT-FR-260907-002',NULL,NULL,NULL,0),(9,'FR-260909-001','SO-260909-001',7,22,'SVC-260909-001',0,'Mbps',NULL,'BEN','SAHU','0786670680','chamuedwin@gmail.com','LIBYA STREET','','','',NULL,NULL,'-6.8173, 39.2810','Multi Dwelling Unit (MDU)','SFP','LC','Single-mode Fiber','AC 220V',NULL,0.00,0.00,0.00,259600.00,220000.00,NULL,NULL,'2026-09-09 10:26:29',16,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-09-09 10:28:43','2026-09-09 10:33:23','uploads/orders/9/sof/d635c73333750eb8e562f9e7e6a0bab3.pdf','SOF TEST.pdf','2026-09-09 10:34:38','uploads/orders/9/sof/ca8fe6fd9bcf4872bd505de5d60a2616.pdf','SOF TEST.pdf',1,NULL,NULL,NULL,NULL,NULL,NULL,'Layer 2 ( last mile)','','','TIX','1000','24 Months','',2500.0000,250000.00,0.00,250000.00,45000.00,295000.00,220000.00,'TZS',0.00,0.00,39600.00,22,'',NULL,'Closed',20,'2026-09-09 10:24:45',NULL,NULL,NULL,NULL,'Feasible','Technically Feasible',NULL,250000.00,NULL,'',NULL,NULL,NULL,NULL,NULL,0.00,'2026-09-09','2026-09-09',NULL,NULL,'2026-09-09 10:40:18','2026-09-09 10:42:06',22,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.00,0,'2026-09-09 10:21:43','2026-09-09 10:42:06',NULL,'CKT-FR-260909-001','2026-09-09 10:40:18','2026-09-12 10:40:18','2026-09-09',1);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partner_kyc_applications`
--

DROP TABLE IF EXISTS `partner_kyc_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_kyc_applications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `partner_id` int(10) unsigned NOT NULL,
  `kyc_type` enum('Partner','Contractor') NOT NULL DEFAULT 'Partner',
  `registered_name` varchar(200) NOT NULL,
  `trading_name` varchar(200) DEFAULT NULL,
  `registration_number` varchar(100) NOT NULL,
  `tin` varchar(100) NOT NULL,
  `vat_vrn` varchar(100) DEFAULT NULL,
  `customer_category` varchar(100) DEFAULT NULL,
  `industry_sector` varchar(100) DEFAULT NULL,
  `nature_of_business` text DEFAULT NULL,
  `office_address` text DEFAULT NULL,
  `city_region` varchar(100) NOT NULL,
  `country` varchar(100) DEFAULT 'Tanzania',
  `website` varchar(200) DEFAULT NULL,
  `main_contact_name` varchar(200) DEFAULT NULL,
  `main_contact_phone` varchar(50) DEFAULT NULL,
  `main_contact_email` varchar(200) DEFAULT NULL,
  `ops_contact_name` varchar(200) DEFAULT NULL,
  `ops_contact_phone` varchar(50) DEFAULT NULL,
  `ops_contact_email` varchar(200) DEFAULT NULL,
  `tech_supervisor_name` varchar(200) DEFAULT NULL,
  `tech_supervisor_phone` varchar(50) DEFAULT NULL,
  `tech_supervisor_email` varchar(200) DEFAULT NULL,
  `escalation_contact_name` varchar(200) DEFAULT NULL,
  `escalation_contact_phone` varchar(50) DEFAULT NULL,
  `escalation_contact_email` varchar(200) DEFAULT NULL,
  `bank_name` varchar(200) DEFAULT NULL,
  `bank_branch` varchar(200) DEFAULT NULL,
  `bank_account_name` varchar(200) DEFAULT NULL,
  `bank_account_number` varchar(100) DEFAULT NULL,
  `bank_payment_terms` varchar(200) DEFAULT NULL,
  `cap_ftth_install` tinyint(1) DEFAULT 0,
  `cap_sme_install` tinyint(1) DEFAULT 0,
  `cap_enterprise_install` tinyint(1) DEFAULT 0,
  `cap_site_survey` tinyint(1) DEFAULT 0,
  `cap_maintenance` tinyint(1) DEFAULT 0,
  `cap_remote_support` tinyint(1) DEFAULT 0,
  `service_regions` text DEFAULT NULL,
  `business_license` varchar(500) DEFAULT NULL,
  `hse_certificate` varchar(500) DEFAULT NULL,
  `trca_certificate` varchar(500) DEFAULT NULL,
  `custom_fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'IT-added custom fields' CHECK (json_valid(`custom_fields`)),
  `status` varchar(50) NOT NULL DEFAULT 'Draft',
  `rejection_reason` text DEFAULT NULL,
  `changes_requested_note` text DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `address` text DEFAULT NULL,
  `signatory2_name` varchar(200) DEFAULT NULL,
  `signatory2_email` varchar(200) DEFAULT NULL,
  `signatory2_phone` varchar(50) DEFAULT NULL,
  `billing_contact_name` varchar(200) DEFAULT NULL,
  `billing_contact_email` varchar(200) DEFAULT NULL,
  `billing_contact_phone` varchar(50) DEFAULT NULL,
  `contractor_agreement` varchar(500) DEFAULT NULL,
  `signed_sla_file` varchar(500) DEFAULT NULL,
  `safety_esg_file` varchar(500) DEFAULT NULL,
  `confidentiality_nda_file` varchar(500) DEFAULT NULL,
  `service_regions_file` varchar(500) DEFAULT NULL,
  `sla_accepted` tinyint(1) DEFAULT 0,
  `sla_accepted_at` datetime DEFAULT NULL,
  `safety_esg_accepted` tinyint(1) DEFAULT 0,
  `safety_esg_accepted_at` datetime DEFAULT NULL,
  `confidentiality_accepted` tinyint(1) DEFAULT 0,
  `confidentiality_accepted_at` datetime DEFAULT NULL,
  `accepted_by` int(10) unsigned DEFAULT NULL,
  `auth_signatory_name` varchar(200) DEFAULT NULL,
  `auth_signatory_email` varchar(200) DEFAULT NULL,
  `auth_signatory_mobile` varchar(50) DEFAULT NULL,
  `review_notes` text DEFAULT NULL,
  `partner_tin_certificate` varchar(500) DEFAULT NULL,
  `partner_vrn_certificate` varchar(500) DEFAULT NULL,
  `partner_incorporation_cert` varchar(500) DEFAULT NULL,
  `partner_tcra_certificate` varchar(500) DEFAULT NULL,
  `partner_tax_clearance` varchar(500) DEFAULT NULL,
  `partner_business_licence` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `partner_id` (`partner_id`),
  KEY `reviewed_by` (`reviewed_by`),
  KEY `idx_status` (`status`),
  KEY `idx_kyc_type` (`kyc_type`),
  CONSTRAINT `partner_kyc_applications_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `partner_kyc_applications_ibfk_2` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner_kyc_applications`
--

LOCK TABLES `partner_kyc_applications` WRITE;
/*!40000 ALTER TABLE `partner_kyc_applications` DISABLE KEYS */;
INSERT INTO `partner_kyc_applications` VALUES (2,4,'Contractor','Fiber Works Ltd',NULL,'5325','668462854','4551',NULL,NULL,NULL,'Dae es salaam','Dar es Salaam','Tanzania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Hamis Hamis','0674928056','Kingistarr@gmail.com',NULL,NULL,NULL,'ASDFGY','branch','LUCAS MAFIKIRI KANDONGA ',' 0152599738300','30 Days',1,0,0,0,0,0,'DAR ES SALAAM','uploads/kyc/2/ff911f0e36b450254777449e71b286e2.docx','uploads/kyc/2/9897eb664f8b82897f89a8202b7d94a2.docx','uploads/kyc/2/63f7e9dfe0959ba293688382f5953e82.docx','[]','Approved',NULL,NULL,'2026-08-24 20:31:18','2026-09-03 20:15:46',13,'2026-08-24 15:56:41','2026-09-03 20:15:46',NULL,'Hamis Hamis','Kingistarr@gmail.com','0674928056','Hamis Hamis','Kingistarr@gmail.com','0674928056','uploads/kyc/2/4884b22343d578535efd653292f121c5.docx','uploads/kyc/2/ac8f5a25a0750a55320f750579079b1e.docx','uploads/kyc/2/a45ca572389d6b0f31badc119fc2425b.docx','uploads/kyc/2/3b9125cb0d7a9d83c8e2294b9931e242.docx','uploads/kyc/2/7ff6becd88e3669b81a8611821b4890a.pdf',1,'2026-08-24 20:31:18',1,'2026-08-24 20:31:18',1,'2026-08-24 20:31:18',NULL,'Hamis Hamis','Kingistarr@gmail.com','0674928056',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,2,'Partner','Afrilink Solutions Ltd',NULL,'REG-100890','TIN-001234567','1234567890',NULL,NULL,NULL,'Dar es Salaam','Dar es Salaam','Tanzania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UPENDO JUMA MBATE','0713887984','erickmsolla0@gmail.com',NULL,NULL,NULL,'CRDB','Kinondoni','Afrilink','213456876523456','30 Days',1,1,0,1,1,0,'DAR ES SALAAM, DODOMA','uploads/kyc/3/3e179b31fd4cc46b0c4be5a830b349d8.pdf','uploads/kyc/3/6d71cc7a62217c98b17ac03bd54c6810.pdf','uploads/kyc/3/20073b235ccdd3f5d6d436e386dfa07f.pdf','[]','Approved','imekosewa',NULL,'2026-08-24 20:44:08','2026-08-24 20:48:34',7,'2026-08-24 20:29:49','2026-08-24 20:48:34',NULL,'SIKUDHANI ALLAN MBWAMBO','erickmsolla0@gmail.com','0713887984','ESTER ABRAHAM MWANGWA','erickmsolla0@gmail.com','0755489475','uploads/kyc/3/c9fcba95fed623cffde76dc4264b71b7.pdf','uploads/kyc/3/a55ef70cf6b11b784833ee721ff75dba.pdf','uploads/kyc/3/386666c4d22607f5f4d03579a64005ad.pdf','uploads/kyc/3/bbf66019ff5345b1f901cfbcb031d39c.pdf','uploads/kyc/3/924acb742f54598ae351ff5e4034ef19.pdf',1,'2026-08-24 20:44:08',1,'2026-08-24 20:44:08',1,'2026-08-24 20:44:08',NULL,'Partner Admin (Afrilink)','admin@afrilink.co.tz','0712000007',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,7,'Partner','FLASHNET TECHNOLOGIES LIMITED',NULL,'80961','111-770-964','40-011692-G',NULL,NULL,NULL,'5th Floor, Garden Avenue Towers, Ohio Street','Dar es Salaam','Tanzania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Natabar Sahu','0786002344','sahu@flashnet.co.tz',NULL,NULL,NULL,'ABSA Bank Tanzania Limited','OHIO','Neilos Network Limited','001 4003851','30 Days',0,0,0,0,0,0,'DAR ES SALAAM','uploads/kyc/4/0a81ddfb2deafa5902bd429217bfe160.pdf',NULL,NULL,'[]','Submitted for Approval',NULL,NULL,'2026-09-07 12:12:36',NULL,NULL,'2026-09-03 13:10:22','2026-09-07 12:12:36',NULL,'Azaria Johnson Kisaka','kisaka@flashnet.co.tz','0715319311','Rajeev Radhakrishnan','payable@flashnet.co.tz','0783355100',NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,'Vinayan Benedict','ben@flashnet.co.tz','0688774233',NULL,'uploads/kyc/4/95f74f9d571e8b145714bc1a17ecc55d.pdf','uploads/kyc/4/821474144a96ae90197498cdee934d23.pdf','uploads/kyc/4/25ee7101439d8a983d1586c4e580ed02.pdf','uploads/kyc/4/0feeec6253b1e4956d8ceeab9b093938.pdf','uploads/kyc/4/c971b1ae8f9b95e35d10fae3ea436d12.pdf','uploads/kyc/4/2649a4ab3e3859e56759f5156f4ce1e8.pdf'),(5,10,'Partner','SPRINT TANZANIA LIMITED',NULL,'20000095819','174-844-178','N/A',NULL,NULL,NULL,'MAKUMBUSHO-DERM PLAZA ','Dar es Salaam','Tanzania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DAVID EMIRU EGWELL','0761607500 ','davide@sprintug.com',NULL,NULL,NULL,'ABSA Bank Tanzania Limited','OHIO','Neilos Network Limited','001 4003851','30 Days',0,0,0,0,0,0,NULL,NULL,NULL,NULL,'[]','Draft',NULL,NULL,NULL,NULL,NULL,'2026-09-07 13:08:44','2026-09-09 10:50:22',NULL,'JOHN BOSCO NTAATE','','06774493278 ','ISAAC WALUSIMBI','isaac@sprinttz.co.tz','0797699333',NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,'ISAAC WALUSIMBI','isaac@sprinttz.co.tz','0797699333',NULL,'uploads/kyc/5/7cb9e66a98800a91137504f509dd32f8.pdf',NULL,'uploads/kyc/5/6393ee93923b6ff592c7d367774f1331.pdf','uploads/kyc/5/7f7a4d03a5c1134657e2d87aa98ad09b.jpeg','uploads/kyc/5/228e39e204748f297fccc68f3c419b54.pdf','uploads/kyc/5/09e4c63cc109a1eeda50aa2570690dbf.pdf'),(6,11,'Partner','RADDY DIGITAL SOLUTION LIMITED',NULL,'20000204862','162-799-932','40-321394-L',NULL,NULL,NULL,'','Dar es Salaam','Tanzania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DAVID EMIRU EGWELL','0761607500 ','davide@sprintug.com',NULL,NULL,NULL,'ABSA Bank Tanzania Limited','OHIO','Neilos Network Limited','001 4003851','30 Days',0,0,0,0,0,0,NULL,NULL,NULL,NULL,'[]','Draft',NULL,NULL,NULL,NULL,NULL,'2026-09-07 14:42:59','2026-09-07 14:42:59',NULL,'JOHN BOSCO NTAATE','','06774493278 ','ISAAC WALUSIMBI','isaac@sprinttz.co.tz','0797699333',NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,'HERMAN LUHANGA','herman.luhanga@raddyfiber.co.tz','0784670652',NULL,'uploads/kyc/6/73e155e0b2d1bcf25df6e3614e91a49b.pdf','uploads/kyc/6/8fe9383f0ae9b69fc3f91446b0864240.pdf','uploads/kyc/6/1a64b764d195fa1852e6981006c2b360.pdf','uploads/kyc/6/9ccb804b674f50d31bfd09404902e116.pdf','uploads/kyc/6/847dc2c47cea71dbd6315d227f636588.pdf','uploads/kyc/6/d30ea087ab35933ee1103521240a8326.pdf'),(7,5,'Partner','Hellen',NULL,'3545','6846','9857',NULL,NULL,NULL,'sfsgiuy','Dar es Salaam','Tanzania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'dknvjbn','654+2984+98498','a@a.c',NULL,NULL,NULL,'here we go','testing','mr hamis','84564584687','30 Days',0,0,0,0,0,0,NULL,NULL,NULL,NULL,'[]','Submitted for Approval',NULL,NULL,'2026-09-10 08:20:41',NULL,NULL,'2026-09-10 08:20:41','2026-09-10 08:20:41',NULL,'oiunbj','a@a.c','2546565495156','sgrjkhrt','a@b.c','98465298424',NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,'Hellen','hellen@gmail.com','0713887984',NULL,'uploads/kyc/7/0c5075d9344e5adbb379479ff851fc2c.png','uploads/kyc/7/3bdc28c35147e39e03414ed9f3791914.png','uploads/kyc/7/692c78279bfb1a8d3085725e889f8d04.png','uploads/kyc/7/16c759c6ed8ce5dc60e905cadfeb76e2.png','uploads/kyc/7/e54e2a628222490a61751acfe6456e37.png','uploads/kyc/7/13a0f9d5cb9beb28e98e39f2505d2549.png');
/*!40000 ALTER TABLE `partner_kyc_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partners`
--

DROP TABLE IF EXISTS `partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `trading_name` varchar(200) DEFAULT NULL,
  `partner_type` enum('ISP','Reseller','VAR','Enterprise','Government','Other') NOT NULL DEFAULT 'ISP',
  `kyc_type` enum('Partner','Contractor') NOT NULL DEFAULT 'Partner',
  `customer_category` varchar(100) DEFAULT NULL,
  `industry_sector` varchar(100) DEFAULT NULL,
  `nature_of_business` text DEFAULT NULL,
  `registration_number` varchar(100) DEFAULT NULL,
  `tin` varchar(100) DEFAULT NULL,
  `vat_vrn` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city_region` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'Tanzania',
  `kam_id` int(10) unsigned DEFAULT NULL,
  `assigned_kam_name` varchar(100) DEFAULT NULL,
  `status` enum('Active','Inactive','Suspended') NOT NULL DEFAULT 'Active',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_kyc_type` (`kyc_type`),
  KEY `idx_kam` (`kam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partners`
--

LOCK TABLES `partners` WRITE;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
INSERT INTO `partners` VALUES (1,'FastNet Communications Ltd','FastNet','ISP','Partner',NULL,NULL,NULL,'REG-100234','100-234-567',NULL,'Plot 12, New Bagamoyo Rd, Kijitonyama','Dar es Salaam','Tanzania',NULL,NULL,'Active','2026-08-24 11:10:42','2026-08-24 11:10:42'),(2,'Afrilink Solutions Ltd','Afrilink','Reseller','Partner',NULL,NULL,NULL,'REG-100567','100-567-890',NULL,'Victoria House, 4th Floor, Victoria','Dar es Salaam','Tanzania',2,'John KAM','Active','2026-08-24 11:10:42','2026-08-24 20:39:49'),(4,'Fiber Works Ltd','FiberWorks','Other','Contractor',NULL,NULL,NULL,'REG-CONT-001','CONT-998877',NULL,'45 Industrial Area, Dar es Salaam','Dar es Salaam','Tanzania',NULL,NULL,'Active','2026-08-24 11:10:42','2026-08-24 11:10:42'),(5,'Hellen','Hellen','ISP','Partner',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tanzania',NULL,NULL,'Active','2026-09-01 16:43:16','2026-09-01 16:43:16'),(6,'patner test','patner test','ISP','Partner',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tanzania',NULL,NULL,'Active','2026-09-03 10:16:09','2026-09-03 10:16:09'),(7,'FLASHNET TECHNOLOGIES LIMITED','FLASHNET TECHNOLOGIES LIMITED','ISP','Partner',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tanzania',NULL,NULL,'Active','2026-09-03 12:13:25','2026-09-03 12:13:25'),(10,'SPRINT TANZANIA LIMITED','SPRINT TANZANIA LIMITED','ISP','Partner',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tanzania',NULL,NULL,'Active','2026-09-07 12:17:36','2026-09-07 12:17:36'),(11,'RADDY DIGITAL SOLUTION LIMITED','RADDY DIGITAL SOLUTION LIMITED','ISP','Partner',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tanzania',NULL,NULL,'Active','2026-09-07 14:28:50','2026-09-07 14:28:50');
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_change_audit`
--

DROP TABLE IF EXISTS `price_change_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price_change_audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `field_name` varchar(100) NOT NULL,
  `old_value` decimal(14,2) DEFAULT NULL,
  `new_value` decimal(14,2) DEFAULT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'TZS',
  `changed_by` int(10) unsigned NOT NULL,
  `stage` varchar(100) NOT NULL,
  `justification` text DEFAULT NULL,
  `changed_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `changed_by` (`changed_by`),
  KEY `idx_order` (`order_id`),
  KEY `idx_changed_at` (`changed_at`),
  CONSTRAINT `price_change_audit_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `price_change_audit_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_change_audit`
--

LOCK TABLES `price_change_audit` WRITE;
/*!40000 ALTER TABLE `price_change_audit` DISABLE KEYS */;
INSERT INTO `price_change_audit` VALUES (1,1,'management_final_nrc',220000.00,220000.00,'TZS',10,'Management Approval','','2026-08-24 21:05:41'),(2,1,'management_final_mrc',220000.00,200000.00,'TZS',10,'Management Approval','','2026-08-24 21:05:42'),(3,3,'revised_nrc',250000.00,300000.00,'TZS',3,'Feasibility Review','extra cable pulling','2026-09-02 20:17:05'),(4,6,'revised_nrc',0.00,300000.00,'TZS',1,'Feasibility Review','extended fiber','2026-09-03 19:39:34'),(5,8,'kam_proposed_nrc',140000.00,200000.00,'TZS',16,'Await Commercial Approval','Extra cables to be used for installations','2026-09-07 11:16:59'),(6,8,'management_final_nrc',200000.00,200000.00,'TZS',1,'Management Approval','','2026-09-07 11:20:42'),(7,8,'management_final_mrc',30000.00,30000.00,'TZS',1,'Management Approval','','2026-09-07 11:20:42'),(8,8,'management_final_nrc',200000.00,200000.00,'TZS',1,'Management Approval','','2026-09-07 11:20:55'),(9,8,'management_final_mrc',30000.00,30000.00,'TZS',1,'Management Approval','','2026-09-07 11:20:55');
/*!40000 ALTER TABLE `price_change_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `code` varchar(50) NOT NULL,
  `category` enum('Internet','Ethernet','IP Transit','Colocation','Cloud','Voice','Managed Services') NOT NULL,
  `description` text DEFAULT NULL,
  `unit` varchar(50) DEFAULT 'Mbps',
  `base_nrc` decimal(12,2) NOT NULL DEFAULT 0.00,
  `base_mrc` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,'Dedicated Internet Access (DIA)','DIA-STD','Internet','High-speed, symmetrical, uncontended DIA with guaranteed SLA.','Mbps',300.00,15.00,1,'2026-08-24 11:10:42'),(2,'Layer 2 Ethernet Point-to-Point','EPL-STD','Ethernet','Point-to-point Layer 2 Ethernet connection over optical fiber.','Mbps',250.00,12.00,1,'2026-08-24 11:10:42'),(3,'Colocation Rack Space (Full Rack)','COLO-FULL','Colocation','Full 42U rack space with dual A+B power feeds and precision cooling.','Rack',500.00,800.00,1,'2026-08-24 11:10:42'),(4,'IP Transit Service','IPT-STD','IP Transit','BGP IP Transit with multiple Tier-1 upstream paths.','Mbps',200.00,8.00,1,'2026-08-24 11:10:42'),(5,'FTTH Wholesale Fiber Connection','FTTH-WHOLESALE','Internet','Wholesale last-mile FTTH connection for ISPs and Resellers.','Mbps',60.00,8.00,1,'2026-08-24 11:10:42');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla_config`
--

DROP TABLE IF EXISTS `sla_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sla_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sla_name` varchar(200) NOT NULL,
  `sla_type` varchar(100) NOT NULL COMMENT 'stage, site_type, service_type',
  `target_hours` int(11) NOT NULL COMMENT 'Working hours',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla_config`
--

LOCK TABLES `sla_config` WRITE;
/*!40000 ALTER TABLE `sla_config` DISABLE KEYS */;
INSERT INTO `sla_config` VALUES (1,'Feasibility Acknowledgement','stage',8,'BSA must acknowledge within 1 working day',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(2,'In Coverage Installation','site_type',16,'Standard serviceable location - 2 working days',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(3,'Apartment without MDU','site_type',24,'MDU readiness required - 3 working days',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(4,'Extension above 200m','site_type',40,'Extension work required - 5 working days',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(5,'Pole + Extension','site_type',56,'Pole and extension required - 7 working days',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(6,'Testing Review after Completion','stage',8,'PM/BSA reviews same day or next working day',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(7,'Partner UAT Response','stage',48,'48 hours for partner UAT acceptance',1,'2026-08-24 11:10:42','2026-08-24 11:10:42');
/*!40000 ALTER TABLE `sla_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_events`
--

DROP TABLE IF EXISTS `system_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_type` varchar(100) NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `assignment_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `payload` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_created` (`created_at`),
  KEY `idx_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_events`
--

LOCK TABLES `system_events` WRITE;
/*!40000 ALTER TABLE `system_events` DISABLE KEYS */;
INSERT INTO `system_events` VALUES (1,'kyc_status_updated',NULL,NULL,1,'{\"event_type\":\"kyc_status_updated\",\"order_id\":null,\"timestamp\":\"2026-08-24 20:29:49\",\"data\":{\"kyc_id\":3,\"status\":\"Submitted for Approval\"}}','2026-08-24 20:29:49'),(2,'kyc_status_updated',NULL,NULL,1,'{\"event_type\":\"kyc_status_updated\",\"order_id\":null,\"timestamp\":\"2026-08-24 20:31:18\",\"data\":{\"kyc_id\":2,\"status\":\"Submitted for Approval\"}}','2026-08-24 20:31:18'),(3,'kyc_status_updated',NULL,NULL,7,'{\"event_type\":\"kyc_status_updated\",\"order_id\":null,\"timestamp\":\"2026-08-24 20:42:44\",\"data\":{\"kyc_id\":3,\"status\":\"Rejected\"}}','2026-08-24 20:42:44'),(4,'kyc_status_updated',NULL,NULL,1,'{\"event_type\":\"kyc_status_updated\",\"order_id\":null,\"timestamp\":\"2026-08-24 20:44:08\",\"data\":{\"kyc_id\":3,\"status\":\"Submitted for Approval\"}}','2026-08-24 20:44:08'),(5,'kyc_status_updated',NULL,NULL,7,'{\"event_type\":\"kyc_status_updated\",\"order_id\":null,\"timestamp\":\"2026-08-24 20:48:34\",\"data\":{\"kyc_id\":3,\"status\":\"Approved\"}}','2026-08-24 20:48:34'),(6,'order_status_sync',1,NULL,3,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 20:58:27\",\"data\":{\"trigger_action\":\"bsa_feasible\",\"old_status\":\"Management Approval\",\"new_status\":\"Management Approval\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260824-001\",\"status\":\"Management Approval\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":259600,\"total_revenue\":613600,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 20:58:27'),(7,'order_status_sync',1,NULL,2,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:15:21\",\"data\":{\"trigger_action\":\"proceed_to_project\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260824-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:15:21'),(8,'order_status_sync',1,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:18:20\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":1,\"total_mandatory\":6,\"completed_mandatory\":1,\"all_mandatory_complete\":false},\"order_number\":\"FR-260824-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:18:20'),(9,'order_status_sync',1,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:18:53\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":2,\"total_mandatory\":6,\"completed_mandatory\":2,\"all_mandatory_complete\":false},\"order_number\":\"FR-260824-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:18:53'),(10,'order_status_sync',1,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:19:18\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":3,\"total_mandatory\":6,\"completed_mandatory\":3,\"all_mandatory_complete\":false},\"order_number\":\"FR-260824-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:19:18'),(11,'order_status_sync',1,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:19:50\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":4,\"total_mandatory\":6,\"completed_mandatory\":3,\"all_mandatory_complete\":false},\"order_number\":\"FR-260824-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:19:50'),(12,'order_status_sync',1,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:20:20\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":5,\"total_mandatory\":6,\"completed_mandatory\":3,\"all_mandatory_complete\":false},\"order_number\":\"FR-260824-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:20:20'),(13,'order_status_sync',1,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:21:07\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":6,\"total_mandatory\":6,\"completed_mandatory\":4,\"all_mandatory_complete\":false},\"order_number\":\"FR-260824-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:21:07'),(14,'order_status_sync',1,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:21:43\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":7,\"total_mandatory\":6,\"completed_mandatory\":5,\"all_mandatory_complete\":false},\"order_number\":\"FR-260824-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:21:43'),(15,'order_status_sync',1,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:22:06\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":8,\"total_mandatory\":6,\"completed_mandatory\":6,\"all_mandatory_complete\":true},\"order_number\":\"FR-260824-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:22:06'),(16,'order_status_sync',1,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:24:19\",\"data\":{\"trigger_action\":\"submit_completion\",\"old_status\":\"Testing\",\"new_status\":\"Testing\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":8,\"total_mandatory\":6,\"completed_mandatory\":6,\"all_mandatory_complete\":true},\"order_number\":\"FR-260824-001\",\"status\":\"Testing\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:24:19'),(17,'order_status_sync',1,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:26:12\",\"data\":{\"trigger_action\":\"submit_completion\",\"old_status\":\"Testing\",\"new_status\":\"Testing\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":8,\"total_mandatory\":6,\"completed_mandatory\":6,\"all_mandatory_complete\":true},\"order_number\":\"FR-260824-001\",\"status\":\"Testing\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:26:12'),(18,'order_status_sync',1,NULL,11,'{\"event_type\":\"order_status_sync\",\"order_id\":1,\"timestamp\":\"2026-08-24 21:29:15\",\"data\":{\"trigger_action\":\"submit_completion\",\"old_status\":\"Testing\",\"new_status\":\"Testing\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":8,\"total_mandatory\":8,\"completed_mandatory\":8,\"all_mandatory_complete\":true},\"order_number\":\"FR-260824-001\",\"status\":\"Testing\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"Magari Mtaaani\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":236000,\"total_revenue\":590000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-08-24 21:29:15'),(19,'order_status_sync',3,NULL,3,'{\"event_type\":\"order_status_sync\",\"order_id\":3,\"timestamp\":\"2026-09-02 20:17:05\",\"data\":{\"trigger_action\":\"bsa_feasible\",\"old_status\":\"Await Commercial Approval\",\"new_status\":\"Await Commercial Approval\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260902-001\",\"status\":\"Await Commercial Approval\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"John Timonth \",\"partner_name\":\"FastNet Communications Ltd\",\"total_nrc\":354000,\"total_mrc\":129800,\"total_revenue\":483800,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-02 20:17:05'),(20,'order_status_sync',4,NULL,20,'{\"event_type\":\"order_status_sync\",\"order_id\":4,\"timestamp\":\"2026-09-03 10:32:14\",\"data\":{\"trigger_action\":\"bsa_feasible\",\"old_status\":\"Await Commercial Approval\",\"new_status\":\"Await Commercial Approval\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-001\",\"status\":\"Await Commercial Approval\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"patner A\",\"partner_name\":\"patner test\",\"total_nrc\":295000,\"total_mrc\":129800,\"total_revenue\":424800,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 10:32:15'),(21,'order_status_sync',4,NULL,1,'{\"event_type\":\"order_status_sync\",\"order_id\":4,\"timestamp\":\"2026-09-03 10:52:39\",\"data\":{\"trigger_action\":\"proceed_to_project\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"patner A\",\"partner_name\":\"patner test\",\"total_nrc\":295000,\"total_mrc\":129800,\"total_revenue\":424800,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 10:52:39'),(22,'order_status_sync',4,NULL,1,'{\"event_type\":\"order_status_sync\",\"order_id\":4,\"timestamp\":\"2026-09-03 11:07:10\",\"data\":{\"trigger_action\":\"submit_completion\",\"old_status\":\"Testing\",\"new_status\":\"Testing\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-001\",\"status\":\"Testing\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"patner A\",\"partner_name\":\"patner test\",\"total_nrc\":295000,\"total_mrc\":129800,\"total_revenue\":424800,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 11:07:10'),(23,'order_status_sync',6,NULL,1,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:39:34\",\"data\":{\"trigger_action\":\"bsa_feasible\",\"old_status\":\"Await Commercial Approval\",\"new_status\":\"Await Commercial Approval\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-003\",\"status\":\"Await Commercial Approval\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":0,\"total_revenue\":354000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:39:34'),(24,'order_status_sync',6,NULL,1,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:46:22\",\"data\":{\"trigger_action\":\"proceed_to_project\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-003\",\"status\":\"Installation\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:46:22'),(25,'order_status_sync',6,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:50:46\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":1,\"total_mandatory\":6,\"completed_mandatory\":1,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-003\",\"status\":\"Installation\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:50:46'),(26,'order_status_sync',6,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:51:11\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":2,\"total_mandatory\":6,\"completed_mandatory\":2,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-003\",\"status\":\"Installation\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:51:11'),(27,'order_status_sync',6,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:51:35\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":3,\"total_mandatory\":6,\"completed_mandatory\":3,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-003\",\"status\":\"Installation\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:51:35'),(28,'order_status_sync',6,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:52:04\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":4,\"total_mandatory\":6,\"completed_mandatory\":3,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-003\",\"status\":\"Installation\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:52:04'),(29,'order_status_sync',6,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:52:24\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":5,\"total_mandatory\":6,\"completed_mandatory\":3,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-003\",\"status\":\"Installation\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:52:24'),(30,'order_status_sync',6,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:52:44\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":6,\"total_mandatory\":6,\"completed_mandatory\":4,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-003\",\"status\":\"Installation\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:52:44'),(31,'order_status_sync',6,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:53:13\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":7,\"total_mandatory\":6,\"completed_mandatory\":5,\"all_mandatory_complete\":false},\"order_number\":\"FR-260903-003\",\"status\":\"Installation\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:53:13'),(32,'order_status_sync',6,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:53:30\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":8,\"total_mandatory\":6,\"completed_mandatory\":6,\"all_mandatory_complete\":true},\"order_number\":\"FR-260903-003\",\"status\":\"Installation\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:53:30'),(33,'order_status_sync',6,NULL,13,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 19:53:53\",\"data\":{\"trigger_action\":\"submit_completion\",\"old_status\":\"Testing\",\"new_status\":\"Testing\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":8,\"total_mandatory\":6,\"completed_mandatory\":6,\"all_mandatory_complete\":true},\"order_number\":\"FR-260903-003\",\"status\":\"Testing\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 19:53:53'),(34,'order_status_sync',6,NULL,11,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 20:11:47\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":8,\"total_mandatory\":6,\"completed_mandatory\":6,\"all_mandatory_complete\":true},\"order_number\":\"FR-260903-003\",\"status\":\"Installation\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 20:11:47'),(35,'order_status_sync',6,NULL,11,'{\"event_type\":\"order_status_sync\",\"order_id\":6,\"timestamp\":\"2026-09-03 20:12:12\",\"data\":{\"trigger_action\":\"submit_completion\",\"old_status\":\"Testing\",\"new_status\":\"Testing\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":8,\"total_mandatory\":6,\"completed_mandatory\":6,\"all_mandatory_complete\":true},\"order_number\":\"FR-260903-003\",\"status\":\"Testing\",\"service_type\":\"FTTH\",\"customer_name\":\"Acme Telecom Ltd\",\"partner_name\":\"Afrilink Solutions Ltd\",\"total_nrc\":354000,\"total_mrc\":177000,\"total_revenue\":531000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-03 20:12:12'),(36,'kyc_status_updated',NULL,NULL,13,'{\"event_type\":\"kyc_status_updated\",\"order_id\":null,\"timestamp\":\"2026-09-03 20:15:46\",\"data\":{\"kyc_id\":2,\"status\":\"Approved\"}}','2026-09-03 20:15:46'),(37,'order_status_sync',7,NULL,20,'{\"event_type\":\"order_status_sync\",\"order_id\":7,\"timestamp\":\"2026-09-07 09:22:44\",\"data\":{\"trigger_action\":\"bsa_feasible\",\"old_status\":\"Management Approval\",\"new_status\":\"Management Approval\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260907-001\",\"status\":\"Management Approval\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"AIDA ROBERT\",\"partner_name\":\"patner test\",\"total_nrc\":118000,\"total_mrc\":0,\"total_revenue\":118000,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-07 09:22:44'),(38,'order_status_sync',8,NULL,20,'{\"event_type\":\"order_status_sync\",\"order_id\":8,\"timestamp\":\"2026-09-07 11:10:00\",\"data\":{\"trigger_action\":\"bsa_feasible\",\"old_status\":\"Await Commercial Approval\",\"new_status\":\"Await Commercial Approval\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260907-002\",\"status\":\"Await Commercial Approval\",\"service_type\":\"FTTH\",\"customer_name\":\"New Customer\",\"partner_name\":\"patner test\",\"total_nrc\":165200,\"total_mrc\":32450,\"total_revenue\":197650,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-07 11:10:00'),(39,'kyc_status_updated',NULL,NULL,1,'{\"event_type\":\"kyc_status_updated\",\"order_id\":null,\"timestamp\":\"2026-09-07 12:12:36\",\"data\":{\"kyc_id\":4,\"status\":\"Submitted for Approval\"}}','2026-09-07 12:12:36'),(40,'order_status_sync',9,NULL,20,'{\"event_type\":\"order_status_sync\",\"order_id\":9,\"timestamp\":\"2026-09-09 10:24:45\",\"data\":{\"trigger_action\":\"bsa_feasible\",\"old_status\":\"Await Commercial Approval\",\"new_status\":\"Await Commercial Approval\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260909-001\",\"status\":\"Await Commercial Approval\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"BEN\",\"partner_name\":\"FLASHNET TECHNOLOGIES LIMITED\",\"total_nrc\":295000,\"total_mrc\":259600,\"total_revenue\":554600,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-09 10:24:45'),(41,'order_status_sync',9,NULL,1,'{\"event_type\":\"order_status_sync\",\"order_id\":9,\"timestamp\":\"2026-09-09 10:35:10\",\"data\":{\"trigger_action\":\"proceed_to_project\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":0,\"total_mandatory\":6,\"completed_mandatory\":0,\"all_mandatory_complete\":false},\"order_number\":\"FR-260909-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"BEN\",\"partner_name\":\"FLASHNET TECHNOLOGIES LIMITED\",\"total_nrc\":295000,\"total_mrc\":259600,\"total_revenue\":554600,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-09 10:35:10'),(42,'order_status_sync',9,NULL,1,'{\"event_type\":\"order_status_sync\",\"order_id\":9,\"timestamp\":\"2026-09-09 10:37:14\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":1,\"total_mandatory\":6,\"completed_mandatory\":1,\"all_mandatory_complete\":false},\"order_number\":\"FR-260909-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"BEN\",\"partner_name\":\"FLASHNET TECHNOLOGIES LIMITED\",\"total_nrc\":295000,\"total_mrc\":259600,\"total_revenue\":554600,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-09 10:37:14'),(43,'order_status_sync',9,NULL,1,'{\"event_type\":\"order_status_sync\",\"order_id\":9,\"timestamp\":\"2026-09-09 10:38:15\",\"data\":{\"trigger_action\":\"upload_evidence\",\"old_status\":\"Installation\",\"new_status\":\"Installation\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":2,\"total_mandatory\":6,\"completed_mandatory\":2,\"all_mandatory_complete\":false},\"order_number\":\"FR-260909-001\",\"status\":\"Installation\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"BEN\",\"partner_name\":\"FLASHNET TECHNOLOGIES LIMITED\",\"total_nrc\":295000,\"total_mrc\":259600,\"total_revenue\":554600,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-09 10:38:15'),(44,'order_status_sync',9,NULL,1,'{\"event_type\":\"order_status_sync\",\"order_id\":9,\"timestamp\":\"2026-09-09 10:39:44\",\"data\":{\"trigger_action\":\"submit_completion\",\"old_status\":\"Testing\",\"new_status\":\"Testing\",\"status_changed\":false,\"total_items\":8,\"uploaded_items\":2,\"total_mandatory\":6,\"completed_mandatory\":2,\"all_mandatory_complete\":false},\"order_number\":\"FR-260909-001\",\"status\":\"Testing\",\"service_type\":\"Layer 2 ( last mile)\",\"customer_name\":\"BEN\",\"partner_name\":\"FLASHNET TECHNOLOGIES LIMITED\",\"total_nrc\":295000,\"total_mrc\":259600,\"total_revenue\":554600,\"billing_start_date\":null,\"is_billing_active\":false}','2026-09-09 10:39:44'),(45,'kyc_status_updated',NULL,NULL,1,'{\"event_type\":\"kyc_status_updated\",\"order_id\":null,\"timestamp\":\"2026-09-10 08:20:41\",\"data\":{\"kyc_id\":7,\"status\":\"Submitted for Approval\"}}','2026-09-10 08:20:41');
/*!40000 ALTER TABLE `system_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=140501 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'usd_exchange_rate','2650.00',1,'2026-08-29 23:14:58','2026-08-29 23:14:58');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `partner_id` int(10) unsigned DEFAULT NULL COMMENT 'NULL = admin/internal user',
  `full_name` varchar(200) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `password_changed_at` datetime DEFAULT current_timestamp(),
  `mobile` varchar(30) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'Partner',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `permissions` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `is_first_login` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `otp_secret` varchar(32) DEFAULT NULL,
  `otp_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `otp_verified` tinyint(1) NOT NULL DEFAULT 0,
  `profile_picture` varchar(500) DEFAULT NULL,
  `status` enum('Active','Inactive','Suspended') NOT NULL DEFAULT 'Active',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `partner_id` (`partner_id`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,'System Administrator','admin','admin@neilosnetwork.co.tz','$2y$10$AFWPBl7pldA0p2fypm36LeD/9R0Cxdkz/G/v9jiLyw.bNKUiM/Z9u','2026-09-09 12:42:15','0712000001','System Admin',1,NULL,NULL,0,'2026-09-10 11:45:06',NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-09-10 11:45:06'),(2,NULL,'John KAM','kam_john','john.kam@neilosnetwork.co.tz','$2y$10$AFWPBl7pldA0p2fypm36LeD/9R0Cxdkz/G/v9jiLyw.bNKUiM/Z9u','2026-09-09 12:42:15','0712000002','KAM',1,NULL,NULL,0,'2026-08-24 20:37:35',NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-08-24 20:37:35'),(3,NULL,'Sarah BSA','bsa_sarah','comfortmnyinga@gmail.com','$2y$10$AFWPBl7pldA0p2fypm36LeD/9R0Cxdkz/G/v9jiLyw.bNKUiM/Z9u','2026-09-09 12:42:15','0712000003','BSA',1,NULL,NULL,0,'2026-09-02 20:14:27',NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-09-02 20:14:27'),(6,1,'Partner Admin (FastNet)','partner_fastnet','admin@fastnet.co.tz','$2y$10$AFWPBl7pldA0p2fypm36LeD/9R0Cxdkz/G/v9jiLyw.bNKUiM/Z9u','2026-09-09 12:42:15','0712000006','Partner',1,NULL,NULL,0,'2026-09-07 16:29:43',NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-09-07 16:29:43'),(7,2,'Partner Admin (Afrilink)','partner_afrilink','admin@afrilink.co.tz','$2y$10$AFWPBl7pldA0p2fypm36LeD/9R0Cxdkz/G/v9jiLyw.bNKUiM/Z9u','2026-09-09 12:42:15','0712000007','Partner',1,NULL,NULL,0,'2026-09-03 19:34:23',NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-09-03 19:34:23'),(10,NULL,'Operations Manager','manager','manager@neilosnetwork.co.tz','$2y$10$AFWPBl7pldA0p2fypm36LeD/9R0Cxdkz/G/v9jiLyw.bNKUiM/Z9u','2026-09-09 12:42:15','0712000010','Management',1,NULL,NULL,0,'2026-08-24 21:02:56',NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-08-24 21:02:56'),(11,NULL,'Project Manager','pm','pm@neilosnetwork.co.tz','$2y$10$AFWPBl7pldA0p2fypm36LeD/9R0Cxdkz/G/v9jiLyw.bNKUiM/Z9u','2026-09-09 12:42:15','0712000011','Project Manager',1,NULL,NULL,0,'2026-09-03 20:06:53',NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-09-03 20:06:53'),(12,NULL,'Finance / Billing','billing','billing@neilosnetwork.co.tz','$2y$10$AFWPBl7pldA0p2fypm36LeD/9R0Cxdkz/G/v9jiLyw.bNKUiM/Z9u','2026-09-09 12:42:15','0712000012','Billing',1,NULL,NULL,0,NULL,NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-08-24 11:10:42'),(13,4,'Contractor Admin','contractor1','admin@fiberworks.co.tz','$2y$10$AFWPBl7pldA0p2fypm36LeD/9R0Cxdkz/G/v9jiLyw.bNKUiM/Z9u','2026-09-09 12:42:15','0712000013','Contractor',1,NULL,NULL,0,'2026-09-03 19:49:58',NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-09-03 19:49:58'),(15,NULL,'MHINA KIHIYO','Mhina','mhina.kihiyo@savannafibre.co.tz','$2y$10$wacJ3LzOGhQ7hr9Sv9xJtODLWQdktxEbFhpVSYhHvrrElVi1PNfZ6','2026-09-09 12:42:15','0717449340','System Admin',1,NULL,1,0,'2026-09-10 12:53:18',NULL,0,0,NULL,'Active','2026-08-31 17:07:20','2026-09-10 12:53:18'),(16,NULL,'Aida Robert','arobert','aida.robert@neilosnetwork.co.tz','$2y$10$woZ4aiaNqX/CAoW8zrJAn.u2Ps7WttJtUqIBU1bIPMj6/LeUa/BrW','2026-09-09 12:42:15','0785670498','KAM',1,NULL,1,0,'2026-09-09 10:25:48',NULL,0,0,NULL,'Active','2026-09-01 16:10:16','2026-09-09 10:25:48'),(18,5,'Hellen','hellen','hellen@gmail.com','$2y$10$BIwb8Oa8uJlREFQeRf.CG.GyWJ43ErRvCN3tYe8iRIw4yina0g3Qu','2026-09-09 12:42:15','0713887984','Partner',1,NULL,1,0,'2026-09-02 18:54:24',NULL,0,1,NULL,'Active','2026-09-02 18:53:21','2026-09-02 18:54:24'),(19,6,'patner test','patner','chamuedwin@gmail.com','$2y$10$8Fopc1eQ469UiK8l6IC2Ou1hQE/aGEZ7UpUdOn5qTve4efMfpocYS','2026-09-09 12:42:15','0786670680','Partner',1,NULL,1,0,'2026-09-07 11:03:37',NULL,0,1,NULL,'Active','2026-09-03 10:16:09','2026-09-07 11:03:37'),(20,NULL,'EDWIN CHAMU','echamu','edwin.chamu@neilosnetwork.co.tz','$2y$10$FHxXY7XK5I3AqfGqdifdBOp3GShbA8.m7nsMwN1.AnJe7hCDsrPmW','2026-09-09 12:42:15','0786670680','BSA',1,NULL,1,0,'2026-09-09 10:23:07',NULL,0,1,NULL,'Active','2026-09-03 10:24:57','2026-09-09 10:23:07'),(22,7,'FLASHNET TECHNOLOGIES LIMITED','flashnet','sahu@flashnet.co.tz','$2y$10$m9k7eoL0x3OqzhuxIQyA4eFgvmWP9NOa5QX.1cu48nVpkciwXoMRW','2026-09-09 12:42:15','0786002344','Partner',1,NULL,1,0,'2026-09-09 10:41:34',NULL,0,1,NULL,'Active','2026-09-03 12:13:25','2026-09-09 10:41:34'),(30,10,'SPRINT TANZANIA LIMITED','sprint','Irene@sprinttz.co.tz','$2y$10$quEdAvSg.jIphn5KWmepye1iSeG6WV1lLinJO8lmiqeiaAmCLTKoW','2026-09-09 12:42:15','0797333063','Partner',1,NULL,1,1,NULL,NULL,0,0,NULL,'Active','2026-09-07 12:17:36','2026-09-07 12:17:36'),(31,11,'RADDY DIGITAL SOLUTION LIMITED','raddy','herman.luhanga@raddyfiber.co.tz','$2y$10$8IaNw.mpVrqcvQQWws7Nz.lMR0jmCrl2e6r56JfR9.LnN0flGrxK.','2026-09-09 12:42:15','0784670652','Partner',1,NULL,1,1,NULL,NULL,0,0,NULL,'Active','2026-09-07 14:28:50','2026-09-07 14:28:50');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-10 14:00:01
