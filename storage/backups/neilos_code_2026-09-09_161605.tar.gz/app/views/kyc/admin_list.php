<?php // Admin / PM KYC List View
$isPMUser = isProjectManager();
?>
<div class="page-header" style="margin-bottom:20px">
  <div class="page-header-left">
    <h1 class="page-title"><?= $isPMUser ? 'Contractor KYC Applications' : 'KYC Applications' ?></h1>
    <div class="page-subtitle"><?= $totalCount ?> application(s) registered · Partner &amp; Contractor Compliance Management</div>
  </div>
  <?php if (isAdmin() || hasRole('Management', 'Project Manager')): ?>
  <div class="page-header-actions">
    <a href="<?= APP_URL ?>/?page=kyc&action=new" class="btn btn-primary">
      <?= svgIcon('plus') ?> <?= $isPMUser ? 'New Contractor KYC' : 'New KYC Application' ?>
    </a>
  </div>
  <?php endif; ?>
</div>

<!-- 1. KPI Summary Cards Grid -->
<div class="stats-grid mb-24" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:16px;margin-bottom:20px">
  <!-- Total Applications -->
  <div class="stat-card" style="padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);display:flex;align-items:center;gap:14px">
    <div class="stat-icon blue" style="width:44px;height:44px;border-radius:10px;background:rgba(15,76,129,0.1);color:var(--accent);display:flex;align-items:center;justify-content:center">
      <?= svgIcon('document', 22) ?>
    </div>
    <div class="stat-info">
      <div class="stat-value" style="font-size:1.5rem;font-weight:700;line-height:1.2"><?= $totalCount ?></div>
      <div class="stat-label" style="font-size:0.82rem;color:var(--text-secondary)">Total Applications</div>
    </div>
  </div>

  <!-- Awaiting Review / Submitted -->
  <div class="stat-card" style="padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);display:flex;align-items:center;gap:14px">
    <div class="stat-icon yellow" style="width:44px;height:44px;border-radius:10px;background:rgba(217,119,6,0.1);color:var(--warning);display:flex;align-items:center;justify-content:center">
      <?= svgIcon('clock', 22) ?>
    </div>
    <div class="stat-info">
      <div class="stat-value" style="font-size:1.5rem;font-weight:700;line-height:1.2"><?= $submittedCount ?></div>
      <div class="stat-label" style="font-size:0.82rem;color:var(--text-secondary)">Awaiting Review</div>
    </div>
  </div>

  <!-- Approved -->
  <div class="stat-card" style="padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);display:flex;align-items:center;gap:14px">
    <div class="stat-icon green" style="width:44px;height:44px;border-radius:10px;background:rgba(5,150,105,0.1);color:var(--success);display:flex;align-items:center;justify-content:center">
      <?= svgIcon('check', 22) ?>
    </div>
    <div class="stat-info">
      <div class="stat-value" style="font-size:1.5rem;font-weight:700;line-height:1.2"><?= $approvedCount ?></div>
      <div class="stat-label" style="font-size:0.82rem;color:var(--text-secondary)">Approved</div>
    </div>
  </div>

  <!-- Drafts & Rejected -->
  <div class="stat-card" style="padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);display:flex;align-items:center;gap:14px">
    <div class="stat-icon" style="width:44px;height:44px;border-radius:10px;background:rgba(82,82,91,0.1);color:var(--text-secondary);display:flex;align-items:center;justify-content:center">
      <?= svgIcon('edit', 22) ?>
    </div>
    <div class="stat-info">
      <div class="stat-value" style="font-size:1.5rem;font-weight:700;line-height:1.2"><?= $draftCount ?> <span style="font-size:0.85rem;font-weight:400;color:var(--text-muted)">/ <?= $rejectedCount ?> rej</span></div>
      <div class="stat-label" style="font-size:0.82rem;color:var(--text-secondary)">Drafts / Rejected</div>
    </div>
  </div>
</div>

<!-- 2. Search & Filter Bar -->
<div class="card" style="margin-bottom:16px;border:1px solid var(--border);border-radius:var(--radius)">
  <div class="card-body" style="padding:14px 18px">
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
      <!-- Search input -->
      <div style="flex:1;min-width:240px;position:relative">
        <input type="text" id="kycSearchInput" class="form-control" placeholder="Search by organization, TIN, registration number..." onkeyup="filterKycTable()" style="padding-left:36px;font-size:0.9rem">
        <span style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);pointer-events:none">
          <?= svgIcon('search', 16) ?>
        </span>
      </div>

      <!-- Type Filter -->
      <div style="display:flex;align-items:center;gap:8px">
        <label for="kycTypeFilter" style="font-size:0.82rem;font-weight:600;color:var(--text-secondary);margin:0;white-space:nowrap">Type:</label>
        <select id="kycTypeFilter" class="form-control" onchange="filterKycTable()" style="width:auto;min-width:130px;font-size:0.88rem;padding:6px 10px">
          <option value="">All Types</option>
          <option value="Partner">Partner</option>
          <option value="Contractor">Contractor</option>
        </select>
      </div>

      <!-- Status Filter -->
      <div style="display:flex;align-items:center;gap:8px">
        <label for="kycStatusFilter" style="font-size:0.82rem;font-weight:600;color:var(--text-secondary);margin:0;white-space:nowrap">Status:</label>
        <select id="kycStatusFilter" class="form-control" onchange="filterKycTable()" style="width:auto;min-width:160px;font-size:0.88rem;padding:6px 10px">
          <option value="">All Statuses</option>
          <option value="Submitted for Approval">Submitted for Approval</option>
          <option value="Approved">Approved</option>
          <option value="Draft">Draft</option>
          <option value="Rejected">Rejected</option>
        </select>
      </div>

      <!-- Reset button -->
      <button type="button" class="btn btn-secondary btn-sm" onclick="resetKycFilters()" style="padding:7px 12px">
        Reset Filters
      </button>
    </div>
  </div>
</div>

<!-- 3. Clean Organized Table Card -->
<div class="card" style="border:1px solid var(--border);border-radius:var(--radius);overflow:hidden">
  <div class="table-responsive">
    <table class="data-table" id="kycApplicationsTable" style="width:100%;border-collapse:collapse">
      <thead>
        <tr style="background:var(--surface-3);border-bottom:1px solid var(--border)">
          <th style="padding:12px 16px;text-align:left;font-size:0.82rem;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.5px">Organization &amp; Entity</th>
          <th style="padding:12px 16px;text-align:left;font-size:0.82rem;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.5px;min-width:110px">Type</th>
          <th style="padding:12px 16px;text-align:left;font-size:0.82rem;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.5px;min-width:120px">TIN</th>
          <th style="padding:12px 16px;text-align:left;font-size:0.82rem;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.5px;min-width:140px">Status</th>
          <th style="padding:12px 16px;text-align:left;font-size:0.82rem;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.5px;min-width:120px">Submitted</th>
          <th style="padding:12px 16px;text-align:left;font-size:0.82rem;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.5px;min-width:120px">Reviewer</th>
          <th style="padding:12px 16px;text-align:left;font-size:0.82rem;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.5px;min-width:130px">Last Activity</th>
          <th style="padding:12px 16px;text-align:right;font-size:0.82rem;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.5px;min-width:140px">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($applications)): ?>
        <tr id="emptyRow"><td colspan="8"><div class="empty-state"><div class="empty-state-title">No KYC applications found</div></div></td></tr>
        <?php else: ?>
        <?php foreach ($applications as $a): ?>
        <?php
          $orgPrimary = $a['registered_name'] ?: ($a['partner_name'] ?: 'Unnamed Entity');
          $tinVal     = !empty($a['effective_tin']) ? $a['effective_tin'] : (!empty($a['tin']) ? $a['tin'] : '');
          $regNoVal   = !empty($a['effective_reg_no']) ? $a['effective_reg_no'] : (!empty($a['registration_number']) ? $a['registration_number'] : '');
          $st         = $a['status'] ?: 'Draft';
          $isPartner  = ($a['kyc_type'] ?? 'Partner') === 'Partner';

          $badgeCls = match(true) {
              $st === 'Approved'                                                        => 'badge-success',
              $st === 'Rejected'                                                       => 'badge-danger',
              in_array($st, ['Submitted for Approval','Pending Approval','Submitted']) => 'badge-warning',
              default                                                                  => 'badge-secondary',
          };
        ?>
        <tr id="kyc-row-<?= (int)$a['id'] ?>" 
            data-type="<?= e($a['kyc_type'] ?: 'Partner') ?>" 
            data-status="<?= e($st) ?>" 
            data-search="<?= e(strtolower($orgPrimary . ' ' . ($a['partner_name'] ?? '') . ' ' . $tinVal . ' ' . $regNoVal)) ?>"
            style="border-bottom:1px solid var(--border);transition:background 150ms">
          
          <!-- 1. Organization & Entity Details -->
          <td style="padding:14px 16px;vertical-align:middle">
            <div style="font-weight:700;font-size:0.95rem;color:var(--text-primary);line-height:1.3;margin-bottom:3px">
              <a href="<?= APP_URL ?>/?page=kyc&action=edit&id=<?= $a['id'] ?>" style="color:inherit;text-decoration:none">
                <?= e($orgPrimary) ?>
              </a>
            </div>
            <div style="display:flex;align-items:center;gap:8px;font-size:0.8rem;color:var(--text-muted);flex-wrap:wrap">
              <?php if (!empty($regNoVal)): ?>
                <span>Reg: <strong style="color:var(--text-secondary)"><?= e($regNoVal) ?></strong></span>
              <?php endif; ?>
              <?php if (!empty($a['partner_name']) && $a['partner_name'] !== $orgPrimary): ?>
                <span>&bull;</span>
                <span class="badge badge-secondary" style="font-size:0.72rem;padding:2px 6px"><?= e($a['partner_name']) ?></span>
              <?php endif; ?>
            </div>
          </td>

          <!-- 2. KYC Type -->
          <td style="padding:14px 16px;vertical-align:middle">
            <span class="badge <?= $isPartner ? 'badge-info' : 'badge-warning' ?>" style="display:inline-flex;align-items:center;gap:5px;font-weight:600;font-size:0.8rem;padding:4px 8px">
              <?= $isPartner ? svgIcon('building', 13) : svgIcon('users', 13) ?>
              <?= e($a['kyc_type'] ?: 'Partner') ?>
            </span>
          </td>

          <!-- 3. TIN (Clear Monospace Presentation) -->
          <td style="padding:14px 16px;vertical-align:middle">
            <?php if (!empty($tinVal)): ?>
              <span class="font-mono" style="display:inline-block;font-weight:700;color:var(--text-primary);letter-spacing:0.5px;font-size:0.88rem;white-space:nowrap">
                <?= e($tinVal) ?>
              </span>
            <?php else: ?>
              <span class="text-muted" style="font-size:0.85rem">—</span>
            <?php endif; ?>
          </td>

          <!-- 4. Status -->
          <td style="padding:14px 16px;vertical-align:middle">
            <span class="badge <?= $badgeCls ?>" style="font-weight:600;font-size:0.8rem;padding:5px 10px;white-space:nowrap">
              <?= e($st) ?>
            </span>
          </td>

          <!-- 5. Submission Date -->
          <td style="padding:14px 16px;vertical-align:middle;font-size:0.85rem">
            <?php if (!empty($a['submitted_at'])): ?>
              <span style="color:var(--text-primary);font-weight:500"><?= fmtDate($a['submitted_at']) ?></span>
            <?php else: ?>
              <span class="text-muted">Not Submitted</span>
            <?php endif; ?>
          </td>

          <!-- 6. Reviewer -->
          <td style="padding:14px 16px;vertical-align:middle;font-size:0.85rem">
            <?php if (!empty($a['reviewer_name'])): ?>
              <span style="font-weight:600;color:var(--text-secondary)"><?= e($a['reviewer_name']) ?></span>
            <?php else: ?>
              <span class="text-muted">—</span>
            <?php endif; ?>
          </td>

          <!-- 7. Last Updated -->
          <td style="padding:14px 16px;vertical-align:middle;font-size:0.82rem;color:var(--text-muted);white-space:nowrap">
            <?= fmtDateTime($a['updated_at']) ?>
          </td>

          <!-- 8. Actions -->
          <td style="padding:14px 16px;vertical-align:middle;text-align:right">
            <div class="actions" style="display:inline-flex;gap:6px;align-items:center;justify-content:flex-end">
              <a href="<?= APP_URL ?>/?page=kyc&action=edit&id=<?= $a['id'] ?>" class="btn btn-secondary btn-sm" title="Manage KYC Application" style="padding:5px 10px;font-size:0.82rem">
                <?= svgIcon('edit', 14) ?> Manage
              </a>
              <?php if (isAdmin() || isManagement() || hasRole('Management')): ?>
              <button type="button" class="btn btn-danger btn-sm"
                      onclick="openDeleteKycModal(event, <?= (int)$a['id'] ?>, '<?= e(addslashes($orgPrimary)) ?>', '<?= e($a['kyc_type'] ?: 'Partner') ?>', '<?= e($st) ?>')"
                      title="Delete KYC Application" style="padding:5px 9px;font-size:0.82rem">
                <?= svgIcon('trash', 14) ?>
              </button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        <tr id="noMatchesRow" style="display:none">
          <td colspan="8">
            <div class="empty-state" style="padding:32px 16px;text-align:center">
              <div class="empty-state-title" style="font-weight:600;color:var(--text-secondary)">No matching KYC applications</div>
              <div class="empty-state-text" style="font-size:0.85rem;color:var(--text-muted);margin-top:4px">Try adjusting your search query or filter options.</div>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<?php if (isAdmin() || isManagement() || hasRole('Management')): ?>
<!-- Delete Confirmation Modal (Admin & Management Only) -->
<div class="modal" id="deleteKycModal" style="display:none" onclick="handleBackdropClick(event)">
  <div class="modal-dialog" style="max-width:500px" onclick="event.stopPropagation()">
    <form id="deleteKycForm" onsubmit="handleKycDeletion(event)">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="kyc_id" id="deleteKycId">
      
      <div class="modal-header" style="border-bottom:1px solid var(--border);padding:16px 20px;display:flex;align-items:center;justify-content:space-between">
        <div class="modal-title" style="color:var(--danger);font-weight:700;font-size:1.1rem;display:flex;align-items:center;gap:8px">
          <?= svgIcon('trash', 20) ?> Delete KYC Application?
        </div>
        <button type="button" class="modal-close" onclick="closeDeleteKycModal()" style="background:none;border:none;font-size:1.4rem;cursor:pointer;color:var(--text-muted)">&times;</button>
      </div>

      <div class="modal-body" style="padding:20px">
        <p style="margin:0 0 16px;font-size:0.95rem;color:var(--text-primary);line-height:1.5">
          Are you sure you want to delete this KYC application? This action cannot be undone.
        </p>

        <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px 16px;margin-bottom:16px">
          <div style="font-size:0.85rem;margin-bottom:6px"><strong>Organization:</strong> <span id="deleteKycName" style="color:var(--primary);font-weight:600">—</span></div>
          <div style="font-size:0.85rem;margin-bottom:6px"><strong>KYC Type:</strong> <span id="deleteKycType" class="badge badge-info">—</span></div>
          <div style="font-size:0.85rem"><strong>Current Status:</strong> <span id="deleteKycStatus" class="badge badge-secondary">—</span></div>
        </div>

        <div id="deleteKycError" style="display:none;padding:10px 14px;background:var(--danger-light);color:var(--danger);border-radius:var(--radius-sm);font-size:0.88rem;margin-bottom:12px"></div>
      </div>

      <div class="modal-footer" style="border-top:1px solid var(--border);padding:14px 20px;display:flex;justify-content:flex-end;gap:10px">
        <button type="button" class="btn btn-secondary" onclick="closeDeleteKycModal()">Cancel</button>
        <button type="submit" class="btn btn-danger" id="deleteKycSubmitBtn">
          Delete KYC Application
        </button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<script>
let targetKycRow = null;

// Real-time table filter logic
function filterKycTable() {
  const query = (document.getElementById('kycSearchInput').value || '').trim().toLowerCase();
  const typeFilter = document.getElementById('kycTypeFilter').value;
  const statusFilter = document.getElementById('kycStatusFilter').value;

  const rows = document.querySelectorAll('#kycApplicationsTable tbody tr[id^="kyc-row-"]');
  let visibleCount = 0;

  rows.forEach(row => {
    const rowType = row.getAttribute('data-type') || '';
    const rowStatus = row.getAttribute('data-status') || '';
    const rowSearch = row.getAttribute('data-search') || '';

    const matchesQuery = !query || rowSearch.includes(query);
    const matchesType = !typeFilter || rowType === typeFilter;
    const matchesStatus = !statusFilter || rowStatus === statusFilter;

    if (matchesQuery && matchesType && matchesStatus) {
      row.style.display = '';
      visibleCount++;
    } else {
      row.style.display = 'none';
    }
  });

  const noMatchesRow = document.getElementById('noMatchesRow');
  if (noMatchesRow) {
    noMatchesRow.style.display = (visibleCount === 0 && rows.length > 0) ? '' : 'none';
  }
}

function resetKycFilters() {
  const searchInput = document.getElementById('kycSearchInput');
  const typeFilter = document.getElementById('kycTypeFilter');
  const statusFilter = document.getElementById('kycStatusFilter');

  if (searchInput) searchInput.value = '';
  if (typeFilter) typeFilter.value = '';
  if (statusFilter) statusFilter.value = '';

  filterKycTable();
}

<?php if (isAdmin() || isManagement() || hasRole('Management')): ?>
function openDeleteKycModal(evt, id, name, type, status) {
    document.getElementById('deleteKycId').value = id;
    document.getElementById('deleteKycName').textContent = name;
    document.getElementById('deleteKycType').textContent = type;
    document.getElementById('deleteKycStatus').textContent = status;
    document.getElementById('deleteKycError').style.display = 'none';

    targetKycRow = document.getElementById('kyc-row-' + id) || (evt.target ? evt.target.closest('tr') : null);

    document.getElementById('deleteKycModal').style.display = 'flex';
}

function closeDeleteKycModal() {
    document.getElementById('deleteKycModal').style.display = 'none';
    targetKycRow = null;
}

function handleBackdropClick(evt) {
    if (evt.target === document.getElementById('deleteKycModal')) {
        closeDeleteKycModal();
    }
}

function handleKycDeletion(e) {
    e.preventDefault();
    const form = e.target;
    const btn = document.getElementById('deleteKycSubmitBtn');
    const errDiv = document.getElementById('deleteKycError');
    const kycId = document.getElementById('deleteKycId').value;

    btn.disabled = true;
    btn.textContent = 'Deleting...';
    errDiv.style.display = 'none';

    const formData = new FormData(form);

    fetch('<?= APP_URL ?>/?page=kyc&action=delete', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(res => res.json())
    .then(data => {
        btn.disabled = false;
        btn.textContent = 'Delete KYC Application';

        if (data.success) {
            closeDeleteKycModal();
            
            // Remove the deleted KYC application row
            const rowToRemove = document.getElementById('kyc-row-' + kycId) || targetKycRow;
            if (rowToRemove) {
                rowToRemove.remove();
            }

            // Update visible counts
            const subtitle = document.querySelector('.page-subtitle');
            const tbody = document.querySelector('.data-table tbody');
            if (tbody) {
                const remainingRows = tbody.querySelectorAll('tr[id^="kyc-row-"]');
                const count = remainingRows.length;
                if (subtitle) {
                    subtitle.textContent = count + ' application(s) registered · Partner & Contractor Compliance Management';
                }
                if (count === 0) {
                    tbody.innerHTML = '<tr id="emptyRow"><td colspan="8"><div class="empty-state"><div class="empty-state-title">No KYC applications found</div></div></td></tr>';
                }
            }

            if (typeof showToast === 'function') {
                showToast(data.message || 'KYC application deleted successfully.', 'success');
            } else {
                alert(data.message || 'KYC application deleted successfully.');
            }
        } else {
            errDiv.textContent = data.message || 'Failed to delete KYC application. Please try again.';
            errDiv.style.display = 'block';

            if (typeof showToast === 'function') {
                showToast('Failed to delete KYC application. Please try again.', 'danger');
            }
        }
    })
    .catch(err => {
        btn.disabled = false;
        btn.textContent = 'Delete KYC Application';
        errDiv.textContent = 'Failed to delete KYC application. Please try again.';
        errDiv.style.display = 'block';

        if (typeof showToast === 'function') {
            showToast('Failed to delete KYC application. Please try again.', 'danger');
        }
    });
}
<?php endif; ?>
</script>

