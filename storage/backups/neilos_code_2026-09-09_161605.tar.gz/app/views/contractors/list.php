<div class="page-header">
  <div class="page-header-left">
    <h1 class="page-title">Contractors Management</h1>
    <div class="page-subtitle"><?= $total ?> contractor(s) found</div>
  </div>
  <div class="page-header-actions">
    <a href="?<?= http_build_query(array_merge($_GET, ['action' => 'export'])) ?>" class="btn btn-secondary">
      <?= svgIcon('download') ?> Export CSV
    </a>
  </div>
</div>

<!-- Period & Table Filters -->
<div class="card" style="margin-bottom:20px">
  <div class="card-body" style="padding:16px 20px">
    <form method="GET" action="" style="display:flex;flex-direction:column;gap:12px;margin:0">
      <input type="hidden" name="page" value="contractors">

      <!-- Row 1: Period Presets & Date Range -->
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;padding-bottom:12px;border-bottom:1px solid var(--border)">
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:0.82rem;font-weight:600;color:var(--text-secondary);margin-right:4px">Period:</span>
          <?php
            $presets = [
              'all'        => 'All Time',
              'today'      => 'Today',
              'this_month' => 'This Month',
              'last_month' => 'Last Month',
              'this_year'  => 'This Year',
            ];
            $curPreset = $filterPreset ?: 'all';
          ?>
          <?php foreach ($presets as $pKey => $pLabel): ?>
            <?php
              $pParams = $_GET;
              $pParams['preset'] = $pKey;
              unset($pParams['start_date'], $pParams['end_date'], $pParams['p']);
            ?>
            <a href="?<?= http_build_query($pParams) ?>"
               class="btn btn-sm <?= ($curPreset === $pKey && !$filterStart && !$filterEnd) ? 'btn-primary' : 'btn-secondary' ?>"
               style="font-size:0.78rem;padding:4px 10px">
              <?= $pLabel ?>
            </a>
          <?php endforeach; ?>
        </div>

        <!-- Custom Date Range -->
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <span style="font-size:0.82rem;color:var(--text-secondary)">Custom:</span>
          <input type="date" name="start_date" class="form-control" style="font-size:0.8rem;padding:4px 8px;width:auto;height:32px" value="<?= e($filterStart) ?>" placeholder="From">
          <span style="color:var(--text-muted)">to</span>
          <input type="date" name="end_date" class="form-control" style="font-size:0.8rem;padding:4px 8px;width:auto;height:32px" value="<?= e($filterEnd) ?>" placeholder="To">
        </div>
      </div>

      <!-- Row 2: Search & Column Filters -->
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
        <!-- Search Box -->
        <div style="flex:2;min-width:240px">
          <div class="search-box" style="width:100%">
            <?= svgIcon('search') ?>
            <input type="text" name="q" placeholder="Search contractor name, trading name, reg #, TIN, city..." value="<?= e($search) ?>">
          </div>
        </div>

        <!-- Organization Status -->
        <div style="flex:1;min-width:140px">
          <select name="status" class="form-control" style="font-size:0.85rem">
            <option value="">All Org Statuses</option>
            <?php foreach (['Active', 'Inactive', 'Suspended'] as $st): ?>
            <option value="<?= $st ?>" <?= $statusFilter === $st ? 'selected' : '' ?>><?= $st ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- KYC Status -->
        <div style="flex:1;min-width:140px">
          <select name="kyc_status" class="form-control" style="font-size:0.85rem">
            <option value="">All KYC Statuses</option>
            <?php foreach (['Approved', 'Submitted', 'Under Review', 'Draft', 'Rejected'] as $kst): ?>
            <option value="<?= $kst ?>" <?= $kycFilter === $kst ? 'selected' : '' ?>><?= $kst ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Jobs Filter -->
        <div style="flex:1;min-width:140px">
          <select name="jobs_filter" class="form-control" style="font-size:0.85rem">
            <option value="">All Jobs</option>
            <option value="has_active" <?= $jobsFilter === 'has_active' ? 'selected' : '' ?>>Has Active Jobs</option>
            <option value="has_completed" <?= $jobsFilter === 'has_completed' ? 'selected' : '' ?>>Has Completed Jobs</option>
            <option value="no_jobs" <?= $jobsFilter === 'no_jobs' ? 'selected' : '' ?>>No Jobs</option>
          </select>
        </div>

        <button type="submit" class="btn btn-primary btn-sm" style="height:38px;padding:0 16px">
          <?= svgIcon('filter') ?> Filter
        </button>
        <?php if ($search !== '' || $statusFilter !== '' || $kycFilter !== '' || $jobsFilter !== '' || $filterStart !== '' || $filterEnd !== '' || ($filterPreset !== '' && $filterPreset !== 'all')): ?>
        <a href="<?= APP_URL ?>/?page=contractors" class="btn btn-secondary btn-sm" style="height:38px;padding:0 14px;display:inline-flex;align-items:center">
          Clear
        </a>
        <?php endif; ?>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Contractor Name</th>
          <th>Trading Name</th>
          <th>Type</th>
          <th>KYC Status</th>
          <th>Status</th>
          <th>Total Jobs</th>
          <th>Active Jobs</th>
          <th>Completed</th>
          <th>Users</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($contractors)): ?>
        <tr><td colspan="10"><div class="empty-state"><?= svgIcon('building', 32) ?><div class="empty-state-title">No contractors found</div><div class="empty-state-text">No contractor organizations match the selected criteria.</div></div></td></tr>
        <?php else: ?>
        <?php foreach ($contractors as $c): ?>
        <tr>
          <td><a href="<?= APP_URL ?>/?page=contractors&action=detail&id=<?= $c['id'] ?>" class="font-600" style="color:var(--primary)"><?= e($c['name']) ?></a></td>
          <td class="font-sm"><?= e($c['trading_name'] ?: '—') ?></td>
          <td><span class="badge badge-primary"><?= e($c['partner_type']) ?></span></td>
          <td>
            <?php $kycClass = match($c['kyc_status'] ?? '') {
                'Approved' => 'badge-success',
                'Submitted', 'Under Review' => 'badge-info',
                'Rejected' => 'badge-danger',
                default => 'badge-warning'
            }; ?>
            <span class="badge <?= $kycClass ?>"><?= e($c['kyc_status'] ?? 'Draft') ?></span>
          </td>
          <td>
            <?php if ($c['status'] === 'Active'): ?>
            <span class="badge badge-success">Active</span>
            <?php elseif ($c['status'] === 'Inactive'): ?>
            <span class="badge badge-secondary">Inactive</span>
            <?php else: ?>
            <span class="badge badge-danger">Suspended</span>
            <?php endif; ?>
          </td>
          <td class="font-600"><?= (int)$c['total_jobs'] ?></td>
          <td class="font-sm">
            <?php if ((int)$c['active_jobs'] > 0): ?>
            <span class="badge badge-warning"><?= (int)$c['active_jobs'] ?> active</span>
            <?php else: ?>
            <span class="text-muted">0</span>
            <?php endif; ?>
          </td>
          <td class="font-sm text-muted"><?= (int)$c['completed_jobs'] ?></td>
          <td class="font-sm"><?= (int)$c['user_count'] ?></td>
          <td>
            <div class="actions">
              <a href="<?= APP_URL ?>/?page=contractors&action=detail&id=<?= $c['id'] ?>" class="btn btn-secondary btn-sm btn-icon" title="View"><?= svgIcon('eye') ?></a>
              <a href="<?= APP_URL ?>/?page=contractors&action=edit&id=<?= $c['id'] ?>" class="btn btn-secondary btn-sm btn-icon" title="Edit"><?= svgIcon('edit') ?></a>
              <?php if (isAdmin() || hasRole('Management')): ?>
              <form method="POST" action="<?= APP_URL ?>/?page=contractors&action=delete" style="display:inline" data-confirm="Permanently delete contractor <?= e($c['name']) ?>?">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                <input type="hidden" name="id" value="<?= $c['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete Contractor"><?= svgIcon('trash') ?></button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($pages > 1): ?>
  <div class="card-footer" style="display:flex;gap:8px;align-items:center;justify-content:center">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
    <a href="?<?= http_build_query(array_merge($_GET, ['p' => $i])) ?>" class="btn <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?> btn-sm"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>
