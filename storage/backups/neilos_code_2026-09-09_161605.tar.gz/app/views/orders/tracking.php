<?php // Order Tracking List View ?>
<div class="page-header">
  <div class="page-header-left">
    <h1 class="page-title">Order Tracking</h1>
    <div class="page-subtitle"><?= $total ?> order(s) found</div>
  </div>
  <div class="page-header-actions">
    <a href="<?= APP_URL ?>/?page=new_order" class="btn btn-primary"><?= svgIcon('plus') ?> New Order</a>
    <a href="?<?= http_build_query(array_merge($_GET, ['page' => 'orders', 'export' => 'csv'])) ?>" class="btn btn-secondary"><?= svgIcon('download') ?> Export CSV</a>
  </div>
</div>

<!-- Filter Card (Exact Contractors Appearance) -->
<div class="card mb-20" style="margin-bottom:20px">
  <div class="card-body" style="padding:16px">
    <form method="GET" action="<?= APP_URL ?>/" style="display:flex;flex-direction:column;gap:12px">
      <input type="hidden" name="page" value="orders">

      <!-- Row 1: Period Presets + Custom Date Range -->
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;padding-bottom:12px;border-bottom:1px solid var(--border)">
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:0.82rem;font-weight:600;color:var(--text-secondary);margin-right:4px">Period:</span>
          <?php
            $presets = [
              'all'        => 'All Time',
              'today'      => 'Today',
              'this_month' => 'This Month',
              'last_month' => 'Last Month',
              'this_year'  => 'This Year',
            ];
            $curPreset = $filterPreset ?: 'all';
          ?>
          <?php foreach ($presets as $pKey => $pLabel): ?>
            <?php
              $pParams = $_GET;
              $pParams['page'] = 'orders';
              $pParams['preset'] = $pKey;
              unset($pParams['start_date'], $pParams['end_date'], $pParams['p']);
            ?>
            <a href="?<?= http_build_query($pParams) ?>"
               class="btn btn-sm <?= ($curPreset === $pKey && !$filterStart && !$filterEnd) ? 'btn-primary' : 'btn-secondary' ?>"
               style="font-size:0.78rem;padding:4px 10px">
              <?= $pLabel ?>
            </a>
          <?php endforeach; ?>
        </div>

        <!-- Custom Date Range -->
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <span style="font-size:0.82rem;color:var(--text-secondary)">Custom:</span>
          <input type="date" name="start_date" class="form-control" style="font-size:0.8rem;padding:4px 8px;width:auto;height:32px" value="<?= e($filterStart) ?>" placeholder="From">
          <span style="color:var(--text-muted)">to</span>
          <input type="date" name="end_date" class="form-control" style="font-size:0.8rem;padding:4px 8px;width:auto;height:32px" value="<?= e($filterEnd) ?>" placeholder="To">
        </div>
      </div>

      <!-- Row 2: Search & Column Filters -->
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
        <!-- Search Box -->
        <div style="flex:2;min-width:240px">
          <div class="search-box" style="width:100%">
            <?= svgIcon('search') ?>
            <input type="text" name="q" placeholder="Search order #, customer, circuit..." value="<?= e($filterSearch) ?>">
          </div>
        </div>

        <!-- Status Filter -->
        <div style="flex:1;min-width:140px">
          <select name="status" class="form-control" style="font-size:0.85rem">
            <option value="">All Statuses</option>
            <?php foreach($allStatuses as $s): ?>
            <option value="<?= e($s) ?>" <?= $filterStatus === $s ? 'selected' : '' ?>><?= e($s) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Service Type Filter -->
        <div style="flex:1;min-width:140px">
          <select name="service_type" class="form-control" style="font-size:0.85rem">
            <option value="">All Service Types</option>
            <?php foreach($serviceTypes as $s): ?>
            <option value="<?= e($s) ?>" <?= $filterService === $s ? 'selected' : '' ?>><?= e($s) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <?php if (isAdmin() || isManagement()): ?>
        <!-- Active / Inactive Filter -->
        <div style="flex:1;min-width:140px">
          <select name="active_filter" class="form-control" style="font-size:0.85rem">
            <option value="">All (Active + Inactive)</option>
            <option value="1" <?= ($filterActive === '1') ? 'selected' : '' ?>>Active Only</option>
            <option value="0" <?= ($filterActive === '0') ? 'selected' : '' ?>>Inactive Only</option>
          </select>
        </div>
        <?php endif; ?>

        <button type="submit" class="btn btn-primary btn-sm" style="height:38px;padding:0 16px">
          <?= svgIcon('filter') ?> Filter
        </button>
        <?php if ($filterStart !== '' || $filterEnd !== '' || ($filterPreset !== '' && $filterPreset !== 'all') || $filterSearch !== '' || $filterStatus !== '' || $filterService !== '' || $filterActive !== ''): ?>
        <a href="<?= APP_URL ?>/?page=orders" class="btn btn-secondary btn-sm" style="height:38px;padding:0 14px;display:inline-flex;align-items:center">
          Clear
        </a>
        <?php endif; ?>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Order #</th>
          <?php if (!isPartnerUser()): ?><th>Partner</th><?php endif; ?>
          <th>Customer</th>
          <th>Service Type</th>
          <th>Assigned KAM</th>
          <th>Status</th>
          <?php if (!isPartnerUser()): ?>
          <th>NRC</th>
          <th>MRC</th>
          <?php endif; ?>
          <th>Billing Date</th>
          <th>Active</th>
          <th>Created</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($orders)): ?>
        <tr><td colspan="<?= isPartnerUser() ? 10 : 12 ?>"><div class="empty-state"><?= svgIcon('list', 32) ?><div class="empty-state-title">No orders found</div><div class="empty-state-text">Try adjusting your filters or create a new order.</div></div></td></tr>
        <?php else: ?>
        <?php foreach($orders as $o): ?>
        <?php
          $stVal = !empty($o['service_type']) ? $o['service_type'] : '';
          if (!$stVal) {
              if (!empty($o['fttx_package'])) {
                  $stVal = 'FTTH';
              } elseif (!empty($o['aggregate_capacity'])) {
                  $stVal = 'Layer 2 ( last mile)';
              } elseif (!empty($o['bandwidth'])) {
                  $stVal = 'BIA (Broadband Internet Access)';
              } elseif ((float)($o['remote_hands_nrc_usd'] ?? 0) > 0 || (float)($o['base_nrc_usd'] ?? 0) == 80000) {
                  $stVal = 'Remote Hands Only';
              } else {
                  $stVal = 'Not specified';
              }
          }
          // An order is active ONLY when Closed and has a billing date
          $isActive = isOrderActive($o);
          $billingDate = $o['billing_start_date'] ?? null;
        ?>
        <tr>
          <td><a href="<?= APP_URL ?>/?page=order_detail&id=<?= $o['id'] ?>" class="font-600" style="color:var(--primary)"><?= e($o['order_number']) ?></a></td>
          <?php if (!isPartnerUser()): ?><td class="font-sm"><?= e($o['partner_name']) ?></td><?php endif; ?>
          <td><?= e($o['customer_name']) ?></td>
          <td><span class="badge badge-primary"><?= e($stVal) ?></span></td>
          <td class="font-sm"><?= e($o['assigned_kam_name'] ?: '—') ?></td>
          <td><span class="badge <?= orderStatusClass($o['status']) ?>"><?= e($o['status']) ?></span></td>
          <?php if (!isPartnerUser()): ?>
          <td class="font-sm">TZS <?= money($o['total_nrc_incl_vat']) ?></td>
          <td class="font-sm"><?= $o['total_mrc_incl_vat'] > 0 ? e($o['mrc_currency']).' '.money($o['total_mrc_incl_vat']) : '—' ?></td>
          <?php endif; ?>
          <!-- Billing Date column -->
          <td class="font-sm">
            <?php if ($billingDate): ?>
              <span style="color:var(--text-primary);font-weight:500"><?= fmtDate($billingDate) ?></span>
            <?php else: ?>
              <span class="text-muted">—</span>
            <?php endif; ?>
          </td>
          <!-- Active/Inactive column -->
          <td>
            <?php if ($isActive): ?>
              <span class="badge badge-success" style="display:inline-flex;align-items:center;gap:4px">
                <span style="width:6px;height:6px;border-radius:50%;background:currentColor;display:inline-block"></span>
                Active
              </span>
            <?php else: ?>
              <span class="badge badge-secondary" style="display:inline-flex;align-items:center;gap:4px">
                <span style="width:6px;height:6px;border-radius:50%;background:currentColor;display:inline-block"></span>
                Inactive
              </span>
            <?php endif; ?>
          </td>
          <td class="text-muted font-sm"><?= fmtDate($o['created_at']) ?></td>
          <td>
            <div class="actions">
              <a href="<?= APP_URL ?>/?page=order_detail&id=<?= $o['id'] ?>" class="btn btn-secondary btn-sm btn-icon" title="View"><?= svgIcon('eye') ?></a>
              <?php if (isAdmin() || hasRole('Management')): ?>
              <form method="POST" action="<?= APP_URL ?>/?page=orders&action=delete" style="display:inline" data-confirm="Permanently delete order <?= e($o['order_number']) ?>?">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                <input type="hidden" name="id" value="<?= $o['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete Order"><?= svgIcon('trash') ?></button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($pages > 1): ?>
  <div class="card-footer" style="display:flex;gap:8px;align-items:center;justify-content:center">
    <?php for($i=1;$i<=$pages;$i++): ?>
    <a href="?<?= http_build_query(array_merge($_GET, ['p'=>$i])) ?>" class="btn <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?> btn-sm"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>
