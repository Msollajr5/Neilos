<div class="page-header">
  <div class="page-header-left">
    <div class="page-title">Settings & System Migration</div>
    <div class="page-subtitle">Configure company details, or export/import complete system migration packages</div>
  </div>
  <div class="page-header-actions">
    <div class="tab-nav" style="display:inline-flex;background:var(--surface-2);border-radius:var(--radius-md);padding:4px;gap:4px">
      <a href="<?= APP_URL ?>/?page=settings&tab=company" class="btn <?= $tab === 'company' ? 'btn-primary' : 'btn-ghost' ?>" style="font-size:0.85rem">
        <?= svgIcon('building', 15) ?> Company Info
      </a>
      <a href="<?= APP_URL ?>/?page=settings&tab=migration" class="btn <?= $tab === 'migration' ? 'btn-primary' : 'btn-ghost' ?>" style="font-size:0.85rem">
        <?= svgIcon('download', 15) ?> Backup & Migration
      </a>
    </div>
  </div>
</div>

<?php if ($tab === 'migration'): ?>
<!-- ============================================================ -->
<!-- SYSTEM MIGRATION & PORTABILITY TAB                           -->
<!-- ============================================================ -->

<!-- Live System Overview Counters -->
<div class="kpi-grid" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:16px;margin-bottom:24px">
  <div class="card" style="padding:18px;border-left:4px solid var(--primary)">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">Database State</div>
    <div style="font-size:1.6rem;font-weight:800;color:var(--text-primary);margin-top:4px">
      <?= count($dbStats) ?> <span style="font-size:0.9rem;font-weight:500;color:var(--text-muted)">Tables</span>
    </div>
    <div style="font-size:0.8rem;color:var(--text-secondary);margin-top:4px">
      <?= array_sum(array_column($dbStats, 'rows')) ?> total database rows
    </div>
  </div>

  <div class="card" style="padding:18px;border-left:4px solid #10B981">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">Uploaded File Storage</div>
    <div style="font-size:1.6rem;font-weight:800;color:#10B981;margin-top:4px">
      <?= count($uploadFiles) ?> <span style="font-size:0.9rem;font-weight:500;color:var(--text-muted)">Files</span>
    </div>
    <div style="font-size:0.8rem;color:var(--text-secondary);margin-top:4px">
      <?= round($totalUploadSize / (1024 * 1024), 2) ?> MB total storage size
    </div>
  </div>

  <div class="card" style="padding:18px;border-left:4px solid #F59E0B">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">System Environment</div>
    <div style="font-size:1.4rem;font-weight:800;color:var(--text-primary);margin-top:4px">
      PHP <?= PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION ?>
    </div>
    <div style="font-size:0.8rem;color:var(--text-secondary);margin-top:4px">
      <?= htmlspecialchars(php_uname('s')) ?> (<?= htmlspecialchars(php_uname('n')) ?>)
    </div>
  </div>

  <div class="card" style="padding:18px;border-left:4px solid <?= $systemIntegrity['healthy'] ? '#10B981' : '#EF4444' ?>">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">Integrity Health</div>
    <div style="font-size:1.4rem;font-weight:800;color:<?= $systemIntegrity['healthy'] ? '#10B981' : '#EF4444' ?>;margin-top:4px">
      <?= $systemIntegrity['healthy'] ? '100% Healthy' : 'Action Required' ?>
    </div>
    <div style="font-size:0.8rem;color:var(--text-secondary);margin-top:4px">
      <?= count($systemIntegrity['warnings']) ?> warnings, <?= count($systemIntegrity['errors']) ?> errors
    </div>
  </div>
</div>

<div class="grid-2col" style="gap:24px;margin-bottom:24px">
  <!-- Card 1: Export Complete System -->
  <div class="card" style="border:1px solid var(--border)">
    <div class="card-header" style="background:rgba(15, 76, 129, 0.04)">
      <div class="card-title" style="display:flex;align-items:center;gap:8px">
        <?= svgIcon('download', 18) ?> Export System Package (Device A)
      </div>
    </div>
    <div class="card-body">
      <p style="font-size:0.9rem;color:var(--text-secondary);line-height:1.6;margin-bottom:16px">
        Creates a single, self-contained migration archive (<code>system-migration-*.zip</code>) containing:
      </p>
      <ul style="font-size:0.88rem;color:var(--text-primary);padding-left:20px;line-height:1.8;margin-bottom:20px">
        <li><strong>Complete Database Snapshot:</strong> All <?= count($dbStats) ?> tables, rows, relationships, and constraints.</li>
        <li><strong>Uploaded Files Storage:</strong> All <?= count($uploadFiles) ?> physical files (Signed SOFs, PDFs, DOCX, evidence, KYC attachments).</li>
        <li><strong>Portable Configuration:</strong> Company information, pricing rules, and SLA definitions.</li>
        <li><strong>Manifest & SHA-256 Checksums:</strong> Cryptographic integrity verification for every bundled file.</li>
      </ul>

      <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px;margin-bottom:20px">
        <div style="font-size:0.8rem;font-weight:700;text-transform:uppercase;color:var(--text-muted);margin-bottom:6px">Package Estimate</div>
        <div style="display:flex;justify-content:space-between;font-size:0.88rem">
          <span>Estimated Archive Size:</span>
          <span style="font-weight:700">~<?= round($totalUploadSize / (1024 * 1024), 2) + 0.5 ?> MB</span>
        </div>
      </div>

      <a href="<?= APP_URL ?>/?page=settings&action=export_system" class="btn btn-primary btn-lg" style="width:100%;justify-content:center">
        <?= svgIcon('download', 16) ?> Export & Download Migration Package (.zip)
      </a>
    </div>
  </div>

  <!-- Card 2: Import & Restore System -->
  <div class="card" style="border:1px solid var(--border)">
    <div class="card-header" style="background:rgba(16, 185, 129, 0.04)">
      <div class="card-title" style="display:flex;align-items:center;gap:8px">
        <?= svgIcon('upload', 18) ?> Restore / Import System (Device B)
      </div>
    </div>
    <div class="card-body">
      <form method="POST" action="<?= APP_URL ?>/?page=settings&action=import_system" enctype="multipart/form-data" onsubmit="return confirm('WARNING: Restoring this migration package will synchronize the database and uploads directory with the contents of the package. Do you wish to proceed?');">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

        <p style="font-size:0.9rem;color:var(--text-secondary);line-height:1.6;margin-bottom:16px">
          Select a <code>system-migration-*.zip</code> package exported from Device A to restore the entire portal state.
        </p>

        <div class="form-group" style="margin-bottom:16px">
          <label class="form-label" style="font-weight:700">Migration Package File (.zip) <span class="text-danger">*</span></label>
          <input type="file" name="migration_package" class="form-control" accept=".zip" required style="padding:10px">
          <div class="form-hint">Must contain a valid <code>manifest.json</code> and database snapshot.</div>
        </div>

        <div class="alert alert-warning" style="font-size:0.84rem;margin-bottom:20px">
          <strong>Notice:</strong> Database tables will be safely imported using transactions, and uploaded files will be unpacked directly into the active upload directory.
        </div>

        <button type="submit" class="btn btn-success btn-lg" style="width:100%;justify-content:center">
          <?= svgIcon('check', 16) ?> Validate & Restore System Migration
        </button>
      </form>
    </div>
  </div>
</div>

<!-- Card 3: Live System Health & Integrity Audit -->
<div class="card" style="border:1px solid var(--border)">
  <div class="card-header">
    <div class="card-title"><?= svgIcon('activity') ?> Live System & Storage Integrity Audit</div>
  </div>
  <div class="card-body">
    <div class="grid-2col" style="gap:24px">
      <!-- Database Entities -->
      <div>
        <div style="font-size:0.85rem;font-weight:700;color:var(--text-primary);margin-bottom:12px">Key Record Counts</div>
        <table class="table table-sm" style="width:100%;font-size:0.86rem">
          <thead>
            <tr>
              <th>Entity</th>
              <th style="text-align:right">Total Records</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($systemIntegrity['records'] as $tbl => $info): ?>
            <tr>
              <td><?= e($info['label']) ?> (<code><?= e($tbl) ?></code>)</td>
              <td style="text-align:right;font-weight:700"><?= number_format($info['count']) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Storage Locations & Warnings -->
      <div>
        <div style="font-size:0.85rem;font-weight:700;color:var(--text-primary);margin-bottom:12px">Storage Status & Warnings</div>
        <div style="background:var(--surface-2);border-radius:var(--radius-md);padding:14px;margin-bottom:14px;font-size:0.86rem">
          <div><strong>Upload Directory:</strong> <code><?= e($systemIntegrity['storage']['upload_dir']) ?></code></div>
          <div style="margin-top:6px"><strong>Directory Status:</strong> <?= $systemIntegrity['storage']['writable'] ? '<span class="badge badge-success">Writable</span>' : '<span class="badge badge-danger">Read Only</span>' ?></div>
          <div style="margin-top:6px"><strong>Physical Files on Disk:</strong> <?= number_format($systemIntegrity['storage']['file_count']) ?> files (<?= $systemIntegrity['storage']['total_mb'] ?> MB)</div>
        </div>

        <?php if (!empty($systemIntegrity['warnings'])): ?>
          <div class="alert alert-warning" style="font-size:0.82rem">
            <strong>Audit Notes:</strong>
            <ul style="margin:6px 0 0 16px;padding:0">
              <?php foreach ($systemIntegrity['warnings'] as $w): ?>
                <li><?= e($w) ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php else: ?>
          <div class="alert alert-success" style="font-size:0.84rem">
            <?= svgIcon('check') ?> All database file links and physical storage directories are 100% synchronized and healthy.
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php else: ?>
<!-- ============================================================ -->
<!-- COMPANY IDENTITY SETTINGS TAB                                -->
<!-- ============================================================ -->
<form method="POST" action="<?= APP_URL ?>/?page=settings&action=save_company" enctype="multipart/form-data">
  <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

  <div class="grid-2col">
    <!-- General Information -->
    <div class="card">
      <div class="card-header">
        <div class="card-title"><?= svgIcon('building') ?> Company Identity</div>
      </div>
      <div class="card-body">
        <div class="form-group">
          <label class="form-label">Legal Company Name <span class="text-danger">*</span></label>
          <input type="text" name="company_name" class="form-control" required value="<?= e($company['company_name'] ?? 'Neilos Network Ltd') ?>">
        </div>

        <div class="form-group">
          <label class="form-label">Trading / Brand Name</label>
          <input type="text" name="trading_name" class="form-control" value="<?= e($company['trading_name'] ?? 'Neilos') ?>" placeholder="e.g. Neilos Network">
        </div>

        <div class="grid-2col" style="gap:12px">
          <div class="form-group">
            <label class="form-label">TIN (Tax Identification No.)</label>
            <input type="text" name="tin" class="form-control" value="<?= e($company['tin'] ?? '') ?>" placeholder="e.g. 123-456-789">
          </div>
          <div class="form-group">
            <label class="form-label">VAT / VRN</label>
            <input type="text" name="vat_vrn" class="form-control" value="<?= e($company['vat_vrn'] ?? '') ?>" placeholder="e.g. 40-001234-X">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Certificate of Incorporation / Reg. No.</label>
          <input type="text" name="registration_number" class="form-control" value="<?= e($company['registration_number'] ?? '') ?>" placeholder="e.g. 145982">
        </div>

        <div class="form-group">
          <label class="form-label">Physical Address</label>
          <textarea name="address" class="form-control" rows="2" placeholder="e.g. Plot 42, Ali Hassan Mwinyi Rd, Victoria"><?= e($company['address'] ?? '') ?></textarea>
        </div>

        <div class="grid-2col" style="gap:12px">
          <div class="form-group">
            <label class="form-label">City / Region</label>
            <input type="text" name="city_region" class="form-control" value="<?= e($company['city_region'] ?? 'Dar es Salaam') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Country</label>
            <input type="text" name="country" class="form-control" value="<?= e($company['country'] ?? 'Tanzania') ?>">
          </div>
        </div>
      </div>
    </div>

    <!-- Contact & Signatory Details -->
    <div>
      <div class="card" style="margin-bottom:1.5rem">
        <div class="card-header">
          <div class="card-title"><?= svgIcon('user-check') ?> Authorized Signatory (For Countersigning SOF)</div>
        </div>
        <div class="card-body">
          <div class="form-group">
            <label class="form-label">Authorized Signatory Full Name</label>
            <input type="text" name="authorized_signatory" class="form-control" value="<?= e($company['authorized_signatory'] ?? '') ?>" placeholder="e.g. John Doe">
          </div>
          <div class="form-group">
            <label class="form-label">Designation / Title</label>
            <input type="text" name="signatory_title" class="form-control" value="<?= e($company['signatory_title'] ?? '') ?>" placeholder="e.g. Chief Executive Officer / Managing Director">
          </div>
        </div>
      </div>

      <div class="card" style="margin-bottom:1.5rem">
        <div class="card-header">
          <div class="card-title"><?= svgIcon('phone') ?> Official Contacts</div>
        </div>
        <div class="card-body">
          <div class="grid-2col" style="gap:12px">
            <div class="form-group">
              <label class="form-label">Official Phone</label>
              <input type="text" name="phone" class="form-control" value="<?= e($company['phone'] ?? '') ?>" placeholder="+255 22 ...">
            </div>
            <div class="form-group">
              <label class="form-label">General Email</label>
              <input type="email" name="email" class="form-control" value="<?= e($company['email'] ?? '') ?>" placeholder="info@neilos.co.tz">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Website URL</label>
            <input type="text" name="website" class="form-control" value="<?= e($company['website'] ?? 'https://neilos.co.tz') ?>">
          </div>

          <div class="grid-2col" style="gap:12px">
            <div class="form-group">
              <label class="form-label">Finance Billing Contact</label>
              <input type="text" name="finance_contact" class="form-control" value="<?= e($company['finance_contact'] ?? '') ?>" placeholder="Finance Dept">
            </div>
            <div class="form-group">
              <label class="form-label">Finance Email</label>
              <input type="email" name="finance_email" class="form-control" value="<?= e($company['finance_email'] ?? '') ?>" placeholder="billing@neilos.co.tz">
            </div>
          </div>

          <div class="grid-2col" style="gap:12px">
            <div class="form-group">
              <label class="form-label">NOC / Technical Contact</label>
              <input type="text" name="tech_contact" class="form-control" value="<?= e($company['tech_contact'] ?? '') ?>" placeholder="NOC Support Desk">
            </div>
            <div class="form-group">
              <label class="form-label">Technical Email</label>
              <input type="email" name="tech_email" class="form-control" value="<?= e($company['tech_email'] ?? '') ?>" placeholder="noc@neilos.co.tz">
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div class="card-title"><?= svgIcon('image') ?> Company Logo</div>
        </div>
        <div class="card-body">
          <?php if (!empty($company['logo_path'])): ?>
            <div style="margin-bottom:12px;padding:12px;background:#f8f9fa;border-radius:6px;text-align:center">
              <img src="<?= e(APP_URL . '/' . $company['logo_path']) ?>" alt="Neilos Logo" style="max-height:60px;max-width:200px;object-fit:contain">
            </div>
          <?php endif; ?>
          <div class="form-group">
            <label class="form-label">Upload New Logo (PNG / JPG / SVG)</label>
            <input type="file" name="logo" class="form-control" accept="image/*">
            <div class="form-hint">Shown in header of all printed Service Order Forms</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div style="margin-top:1.5rem;text-align:right">
    <button type="submit" class="btn btn-primary btn-lg"><?= svgIcon('check') ?> Save Company Settings</button>
  </div>
</form>
<?php endif; ?>

