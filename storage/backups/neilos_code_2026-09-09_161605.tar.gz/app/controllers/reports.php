<?php
requireLogin();
requirePermission('reports.view');

$db     = getDB();
$user   = currentUser();
$action = $_GET['action'] ?? 'index';

$pw = partnerWhere('');

// ------------------------------------------------------------------
// Orders Report
// ------------------------------------------------------------------
if ($action === 'orders') {
    $pw = partnerWhere('o');
    $cond = "WHERE {$pw['condition']}";
    $sql = "SELECT o.order_number, o.customer_name, o.customer_location, o.service_type, o.status, o.assigned_kam_name, p.name as partner_name, o.created_at, o.updated_at FROM orders o JOIN partners p ON o.partner_id = p.id {$cond} ORDER BY o.created_at DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($pw['params']);
    $rows = $stmt->fetchAll();

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="orders_report.csv"');
    $f = fopen('php://output', 'w');
    fputcsv($f, ['Order #','Customer','Location','Service Type','Status','KAM','Partner','Created At','Updated At']);
    foreach ($rows as $r) fputcsv($f, $r);
    fclose($f);
    exit;
}

// ------------------------------------------------------------------
// Order SLA Report
// ------------------------------------------------------------------
if ($action === 'order_sla') {
    $pw = partnerWhere('o');
    $cond = "WHERE {$pw['condition']}";
    $sql = "SELECT o.id, o.order_number, o.customer_name, o.service_type, o.status, o.created_at FROM orders o {$cond} ORDER BY o.created_at DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($pw['params']);
    $orders = $stmt->fetchAll();

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="order_sla_report.csv"');
    $f = fopen('php://output', 'w');
    fputcsv($f, ['Order #','Customer','Service Type','Status','Created','Submitted→BSA (hrs)','BSA→Approved (hrs)','Approved→Activated (hrs)','Total (hrs)']);

    $now = date('Y-m-d H:i:s');
    foreach ($orders as $o) {
        $tl = $db->prepare("SELECT status, changed_at FROM order_timeline WHERE order_id = ? ORDER BY changed_at ASC");
        $tl->execute([$o['id']]);
        $tlRows = $tl->fetchAll();

        $submitted = $bsaStart = $approved = $activated = null;
        foreach ($tlRows as $t) {
            if ($t['status'] === 'Submitted') $submitted = strtotime($t['changed_at']);
            if (in_array($t['status'], ['Feasibility Review','Awaiting BSA Approval']) && !$bsaStart) $bsaStart = strtotime($t['changed_at']);
            if ($t['status'] === 'Approved') $approved = strtotime($t['changed_at']);
            if ($t['status'] === 'Activated') $activated = strtotime($t['changed_at']);
        }
        $end = $activated ?: strtotime($now);
        $t1 = $bsaStart && $submitted ? round(($bsaStart - $submitted) / 3600, 1) : '';
        $t2 = $approved && $bsaStart ? round(($approved - $bsaStart) / 3600, 1) : '';
        $t3 = $activated && $approved ? round(($activated - $approved) / 3600, 1) : '';
        $total = $end && $submitted ? round(($end - $submitted) / 3600, 1) : '';
        fputcsv($f, [$o['order_number'], $o['customer_name'], $o['service_type'], $o['status'], $o['created_at'], $t1, $t2, $t3, $total]);
    }
    fclose($f);
    exit;
}

// ------------------------------------------------------------------
// KYC Report
// ------------------------------------------------------------------
if ($action === 'kyc') {
    $pw = partnerWhere('k');
    $cond = "WHERE {$pw['condition']}";
    $sql = "SELECT k.id, p.name as partner_name, k.registered_name, k.trading_name, k.partner_type, k.status, k.submitted_at, k.reviewed_at, k.review_notes FROM partner_kyc_applications k JOIN partners p ON k.partner_id = p.id {$cond} ORDER BY k.created_at DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($pw['params']);
    $rows = $stmt->fetchAll();

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="kyc_report.csv"');
    $f = fopen('php://output', 'w');
    fputcsv($f, ['KYC ID','Partner','Registered Name','Trading Name','Partner Type','Status','Submitted At','Reviewed At','Review Notes']);
    foreach ($rows as $r) fputcsv($f, $r);
    fclose($f);
    exit;
}

// ------------------------------------------------------------------
// Financial & Billing Commercials Report
// ------------------------------------------------------------------
if ($action === 'financial') {
    $pw = partnerWhere('o');
    $cond = "WHERE {$pw['condition']}";
    $sql = "SELECT o.order_number, 
                   p.name as partner_name, 
                   o.customer_name, 
                   o.service_type, 
                   o.status, 
                   o.mrc_currency, 
                   o.base_mrc, 
                   o.discount_pct, 
                   o.discount_amount, 
                   o.vat_on_mrc, 
                   o.total_mrc_incl_vat, 
                   o.base_nrc_usd, 
                   o.remote_hands_nrc_usd, 
                   o.total_nrc_incl_vat, 
                   o.usd_tzs_rate, 
                   ROUND(IF(o.mrc_currency = 'TZS', o.base_mrc / o.usd_tzs_rate, o.base_mrc), 2) as mrc_usd_equiv, 
                   o.created_at 
            FROM orders o 
            JOIN partners p ON o.partner_id = p.id 
            {$cond} 
            ORDER BY o.created_at DESC";
            
    $stmt = $db->prepare($sql);
    $stmt->execute($pw['params']);
    $rows = $stmt->fetchAll();

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="financial_billing_report_' . date('Y-m-d') . '.csv"');
    $f = fopen('php://output', 'w');
    fputs($f, "\xEF\xBB\xBF");
    fputcsv($f, [
        'Order #',
        'Partner Name',
        'Customer Name',
        'Service Type',
        'Order Status',
        'MRC Currency',
        'Base MRC',
        'Discount %',
        'Discount Amount',
        'VAT on MRC',
        'Total MRC Incl. VAT',
        'Base NRC (USD)',
        'Remote Hands NRC (USD)',
        'Total NRC (USD Incl. VAT)',
        'USD / TZS Exchange Rate',
        'MRC USD Equiv ($)',
        'Order Created Date'
    ]);
    foreach ($rows as $r) fputcsv($f, $r);
    fclose($f);
    auditLog('Downloaded Financial & Billing Report CSV', 'reports', 0);
    exit;
}

// ------------------------------------------------------------------
// Report selection page
// ------------------------------------------------------------------
$pageTitle = 'Reports';
include APP_DIR . '/views/layout/header.php';
include APP_DIR . '/views/reports/index.php';
include APP_DIR . '/views/layout/footer.php';
