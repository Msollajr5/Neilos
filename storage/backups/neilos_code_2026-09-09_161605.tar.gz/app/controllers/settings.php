<?php
// ============================================================
// Neilos Company Settings & Migration Controller
// Allows Admin to maintain Neilos company info and export/import system packages
// ============================================================
requireLogin();
requirePermission('admin.settings');

$db     = getDB();
$user   = currentUser();
$action = $_GET['action'] ?? 'index';
$tab    = $_GET['tab'] ?? 'company';

// ------------------------------------------------------------------
// GET / POST: Export Complete System Migration Package
// ------------------------------------------------------------------
if ($action === 'export_system') {
    try {
        $result = exportSystemMigration();
        $zipPath  = $result['zip_path'];
        $filename = $result['filename'];

        if (!file_exists($zipPath)) {
            throw new RuntimeException("Generated export package not found.");
        }

        auditLog("Exported full system migration package ({$filename})", 'system', 0);

        // Stream file download to browser
        header('Content-Description: File Transfer');
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Remove temporary package from public upload dir after streaming
        @unlink($zipPath);
        exit;
    } catch (Throwable $e) {
        setFlash('danger', 'System Export Error: ' . e($e->getMessage()));
        header('Location: ' . APP_URL . '/?page=settings&tab=migration');
        exit;
    }
}

// ------------------------------------------------------------------
// POST: Import System Migration Package
// ------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'import_system') {
    verifyCsrf();

    if (empty($_FILES['migration_package']['name']) || $_FILES['migration_package']['error'] !== UPLOAD_ERR_OK) {
        setFlash('danger', 'Please select a valid migration ZIP package to upload.');
        header('Location: ' . APP_URL . '/?page=settings&tab=migration');
        exit;
    }

    $uploadedFile = $_FILES['migration_package']['tmp_name'];
    $originalName = $_FILES['migration_package']['name'];

    try {
        $restoreResult = importSystemMigration($uploadedFile);
        auditLog("Imported and restored system migration package ({$originalName})", 'system', 0);
        
        $msg = "System restored successfully! Restored <strong>{$restoreResult['restored_tables']}</strong> database tables and <strong>{$restoreResult['restored_files']}</strong> uploaded files.";
        if (!empty($restoreResult['file_errors'])) {
            $msg .= "<br><small class='text-warning'>" . count($restoreResult['file_errors']) . " non-critical file notes.</small>";
        }
        setFlash('success', $msg);
    } catch (Throwable $e) {
        setFlash('danger', 'Migration Import Failed: ' . e($e->getMessage()));
    }

    header('Location: ' . APP_URL . '/?page=settings&tab=migration');
    exit;
}

// ------------------------------------------------------------------
// POST: Save company info
// ------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'save_company') {
    verifyCsrf();

    $fields = [
        'company_name', 'trading_name', 'registration_number',
        'tin', 'vat_vrn', 'address', 'city_region', 'country',
        'phone', 'email', 'website',
        'authorized_signatory', 'signatory_title',
        'finance_contact', 'finance_email',
        'tech_contact', 'tech_email',
    ];

    $set  = [];
    $vals = [];
    foreach ($fields as $f) {
        $set[]  = "$f = ?";
        $vals[] = trim($_POST[$f] ?? '');
    }
    $set[]  = 'updated_by = ?';
    $vals[] = $user['id'];

    // Handle logo upload
    if (!empty($_FILES['logo']['name']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        try {
            $up = uploadFile($_FILES['logo'], 'neilos/logo');
            $set[]  = 'logo_path = ?';
            $vals[] = $up['path'];
        } catch (RuntimeException $e) {
            setFlash('warning', 'Logo upload note: ' . e($e->getMessage()));
        }
    }

    // Upsert row id=1
    $existing = $db->prepare("SELECT id FROM neilos_company_info WHERE id = 1");
    $existing->execute();
    if ($existing->fetch()) {
        $sql = "UPDATE neilos_company_info SET " . implode(', ', $set) . " WHERE id = 1";
        $db->prepare($sql)->execute($vals);
    } else {
        $allCols = array_merge($fields, ['updated_by']);
        $sql = "INSERT INTO neilos_company_info (" . implode(',', $allCols) . ") VALUES (" . implode(',', array_fill(0, count($vals), '?')) . ")";
        $db->prepare($sql)->execute($vals);
    }

    auditLog('Updated Neilos company settings', 'neilos_company_info', 1);
    setFlash('success', 'Company settings saved successfully.');
    header('Location: ' . APP_URL . '/?page=settings&tab=company');
    exit;
}

// ------------------------------------------------------------------
// GET: Load company info and live migration stats
// ------------------------------------------------------------------
$company         = $db->query("SELECT * FROM neilos_company_info WHERE id = 1")->fetch() ?: [];
$systemIntegrity = verifySystemIntegrity();
$dbStats         = getDatabaseStats($db);
$uploadFiles     = scanUploadFiles(UPLOAD_DIR);
$totalUploadSize = array_sum(array_column($uploadFiles, 'size'));

$pageTitle = 'Settings & System Migration';
include APP_DIR . '/views/layout/header.php';
include APP_DIR . '/views/settings/company.php';
include APP_DIR . '/views/layout/footer.php';

