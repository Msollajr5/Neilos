// ============================================================
// Neilos Portal — Order Form JS
// FTTx, Layer 2 (last mile), BIA, Remote Hands dynamic pricing
// ============================================================

const VAT = 0.18;

function getDynamicFttxPackageOptions() {
  if (window.SERVER_PRICING_PACKAGES && Array.isArray(window.SERVER_PRICING_PACKAGES) && window.SERVER_PRICING_PACKAGES.length > 0) {
    const opts = { FTTH: [], FTTB: [] };
    window.SERVER_PRICING_PACKAGES.forEach(pkg => {
      const st = (pkg.service_type || '').toUpperCase();
      const item = {
        key: pkg.package_code || pkg.package_name,
        label: `${pkg.package_name}`,
        price: parseFloat(pkg.mrc_amount) || 0,
        nrc: parseFloat(pkg.nrc_amount) || 140000,
        priceLabel: `${Number(pkg.mrc_amount || 0).toLocaleString('en-US')} TZS / mo`
      };
      if (st.includes('FTTB')) {
        opts.FTTB.push(item);
      } else if (st.includes('FTTH') || st.includes('FTTX')) {
        opts.FTTH.push(item);
      }
    });
    if (opts.FTTH.length > 0 || opts.FTTB.length > 0) {
      return opts;
    }
  }

  return {
    FTTH: [
      { key: 'FTTx-30', label: 'FTTx-30 (30 Mbps)', price: 69000, nrc: 140000, priceLabel: '69,000 TZS / mo' },
      { key: 'FTTx-40', label: 'FTTx-40 (40 Mbps)', price: 27500, nrc: 140000, priceLabel: '27,500 TZS / mo' },
      { key: 'FTTx-50', label: 'FTTx-50 (50 Mbps)', price: 33000, nrc: 140000, priceLabel: '33,000 TZS / mo' },
      { key: 'FTTx-60', label: 'FTTx-60 (60 Mbps)', price: 39500, nrc: 140000, priceLabel: '39,500 TZS / mo' },
      { key: 'FTTx-70', label: 'FTTx-70 (70 Mbps)', price: 46000, nrc: 140000, priceLabel: '46,000 TZS / mo' },
      { key: 'FTTx-80', label: 'FTTx-80 (80 Mbps)', price: 52500, nrc: 140000, priceLabel: '52,500 TZS / mo' },
      { key: 'FTTx-90', label: 'FTTx-90 (90 Mbps)', price: 59000, nrc: 140000, priceLabel: '59,000 TZS / mo' },
      { key: 'FTTx-100', label: 'FTTx-100 (100 Mbps)', price: 65500, nrc: 140000, priceLabel: '65,500 TZS / mo' }
    ],
    FTTB: [
      { key: 'FTTB-30', label: 'FTTB-30 (30 Mbps)', price: 99000, nrc: 140000, priceLabel: '99,000 TZS / mo' },
      { key: 'FTTB-40', label: 'FTTB-40 (40 Mbps)', price: 27500, nrc: 140000, priceLabel: '27,500 TZS / mo' },
      { key: 'FTTB-50', label: 'FTTB-50 (50 Mbps)', price: 33000, nrc: 140000, priceLabel: '33,000 TZS / mo' },
      { key: 'FTTB-60', label: 'FTTB-60 (60 Mbps)', price: 39500, nrc: 140000, priceLabel: '39,500 TZS / mo' },
      { key: 'FTTB-70', label: 'FTTB-70 (70 Mbps)', price: 46000, nrc: 140000, priceLabel: '46,000 TZS / mo' },
      { key: 'FTTB-80', label: 'FTTB-80 (80 Mbps)', price: 52500, nrc: 140000, priceLabel: '52,500 TZS / mo' },
      { key: 'FTTB-90', label: 'FTTB-90 (90 Mbps)', price: 59000, nrc: 140000, priceLabel: '59,000 TZS / mo' },
      { key: 'FTTB-100', label: 'FTTB-100 (100 Mbps)', price: 65500, nrc: 140000, priceLabel: '65,500 TZS / mo' }
    ]
  };
}

let fttxPackageOptions = getDynamicFttxPackageOptions();

const fttxMrcPrices = {
  'FTTx-30': 69000,
  'FTTH-30': 69000,
  'FTTB-30': 99000,
  'FTTx-40': 27500,
  'FTTB-40': 27500,
  'FTTx-50': 33000,
  'FTTB-50': 33000,
  'FTTx-60': 39500,
  'FTTB-60': 39500,
  'FTTx-70': 46000,
  'FTTB-70': 46000,
  'FTTx-80': 52500,
  'FTTB-80': 52500,
  'FTTx-90': 59000,
  'FTTB-90': 59000,
  'FTTx-100': 65500,
  'FTTB-100': 65500
};

let currentServiceType = '';
let currentBaseMRC     = 0;
let currentBaseNRC     = 0;
let currentRHNRC       = 0;

function fmt(n, curr = '') {
  const s = Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return curr ? `${curr} ${s}` : s;
}
function setHid(id, val) { const el = document.getElementById(id); if (el) el.value = val; }
function setTxt(id, val) { const el = document.getElementById(id); if (el) el.textContent = val; }
function show(id) { const el = document.getElementById(id); if (el) el.style.display = ''; }
function hide(id) { const el = document.getElementById(id); if (el) el.style.display = 'none'; }

function handleServiceType(type) {
  currentServiceType = type;

  // Reset all optional rows
  hide('fttxPackageRow'); hide('diaRow'); hide('nniRow'); hide('l2CapRow');
  hide('contractTermRow'); hide('remoteHandsRow'); hide('otherProductNoteRow');

  currentBaseMRC = 0;
  currentBaseNRC = 0;
  currentRHNRC   = 0;

  if (type === 'FTTH' || type === 'FTTB') {
    show('fttxPackageRow');
    show('contractTermRow');
    show('remoteHandsRow');
    currentBaseNRC = 140000;

    const labelEl = document.getElementById('fttxPackageLabel');
    if (labelEl) {
      labelEl.innerHTML = (type === 'FTTB' ? 'FTTB Package' : 'FTTH Package') + ' <span class="required">*</span>';
    }

    const pkgSelect = document.getElementById('fttxPackage');
    if (pkgSelect) {
      const isPartner = pkgSelect.dataset.isPartner === '1';
      const options = (type === 'FTTB') ? fttxPackageOptions.FTTB : fttxPackageOptions.FTTH;
      const prevVal = pkgSelect.value;

      let matched = false;
      options.forEach(opt => {
        const optEl = document.createElement('option');
        optEl.value = opt.key;
        optEl.textContent = isPartner ? opt.label : `${opt.label} (${opt.priceLabel})`;
        if (prevVal === opt.key || (prevVal && prevVal.split('-')[1] && prevVal.split('-')[1] === opt.key.split('-')[1])) {
          optEl.selected = true;
          matched = true;
        }
        pkgSelect.appendChild(optEl);
      });

      if (pkgSelect.value) {
        updateFTTxPrice(pkgSelect.value);
      }
    }
  } else if (type === 'Layer 2 ( last mile)' || type === 'Dedicated Layer 2') {
    show('nniRow');
    show('l2CapRow');
    show('contractTermRow');
    show('remoteHandsRow');
    currentBaseNRC = 250000;
  } else if (type === 'Remote Hands Only' || type === 'Remote Hands') {
    show('contractTermRow');
    currentBaseNRC = 80000;
  } else if (type === 'BIA (Broadband Internet Access)' || type === 'DIA') {
    show('diaRow');
    show('contractTermRow');
    show('otherProductNoteRow');
    currentBaseNRC = 0; // Prices inserted by BSA and KAM
  } else if (type) {
    show('contractTermRow');
    show('otherProductNoteRow');
    currentBaseNRC = 0; // Prices inserted by BSA and KAM
  }

  const rhSelect = document.querySelector('[name="remote_hands_required"]');
  const rhVal = rhSelect ? rhSelect.value : '0';
  const rhNRC = (rhVal === '1' || rhVal === 1) ? 80000 : 0;

  setHid('hidMRCCurr', 'TZS');
  updateNRC(currentBaseNRC, rhNRC);
  updateMRC(0);
  if (type) {
    show('commercialSection');
  } else {
    hide('commercialSection');
  }
}

function updateNRC(base, rhNRC) {
  currentBaseNRC = base;
  currentRHNRC   = rhNRC;
  const sub  = base + rhNRC;
  const vat  = sub * VAT;
  const tot  = sub + vat;

  setTxt('baseNRCDisplay', base > 0 ? `TZS ${fmt(base)}` : 'Inserted by BSA');
  setTxt('nrcSubtotal',    sub > 0 ? `TZS ${fmt(sub)}` : (rhNRC > 0 ? `TZS ${fmt(rhNRC)}` : 'Inserted by BSA'));
  setTxt('vatNRC',         sub > 0 ? `TZS ${fmt(vat)}` : (rhNRC > 0 ? `TZS ${fmt(vat)}` : '—'));
  setTxt('totalNRC',       sub > 0 ? `TZS ${fmt(tot)}` : (rhNRC > 0 ? `TZS ${fmt(tot)}` : 'Inserted by BSA'));

  setHid('hidBaseNRC', base.toFixed(2));
  setHid('hidRHNRC', rhNRC.toFixed(2));
  setHid('hidNRCSub', sub.toFixed(2));
  setHid('hidVatNRC', vat.toFixed(2));
  setHid('hidTotalNRC', tot.toFixed(2));

  if (rhNRC > 0) { setTxt('rhNRCDisplay', `TZS ${fmt(rhNRC)}`); show('remoteHandsNRCRow'); }
  else           { hide('remoteHandsNRCRow'); }
}

function updateMRC(baseMRC) {
  currentBaseMRC = baseMRC;
  const vatMRC  = baseMRC * VAT;
  const totMRC  = baseMRC + vatMRC;

  setTxt('baseMRCDisplay', baseMRC > 0 ? `TZS ${fmt(baseMRC)}` : 'Inserted by KAM');
  setTxt('vatMRC',         baseMRC > 0 ? `TZS ${fmt(vatMRC)}` : '—');
  setTxt('totalMRC',       baseMRC > 0 ? `TZS ${fmt(totMRC)}` : 'Inserted by KAM');

  setHid('hidBaseMRC', baseMRC.toFixed(2));
  setHid('hidDiscPct', '0.00');
  setHid('hidDiscAmt', '0.00');
  setHid('hidVatMRC',  vatMRC.toFixed(2));
  setHid('hidTotalMRC',totMRC.toFixed(2));
  hide('discountRow');
}

function updateFTTxPrice(pkg) {
  let mrc = 0;
  const options = (currentServiceType === 'FTTB') ? fttxPackageOptions.FTTB : fttxPackageOptions.FTTH;
  const found = options.find(o => o.key === pkg || o.key.replace('FTTB-', 'FTTx-') === pkg || o.key.replace('FTTH-', 'FTTx-') === pkg);
  if (found) {
    mrc = found.price;
  } else if (pkg.includes('30')) {
    mrc = (currentServiceType === 'FTTB') ? 99000 : 69000;
  } else if (fttxMrcPrices[pkg]) {
    mrc = fttxMrcPrices[pkg];
  }
  updateMRC(mrc);
}

function updateL2Price(cap) {
  let val = 0;
  if (/Gbps|Gb/i.test(cap)) {
    val = (parseFloat(cap) || 0) * 1000;
  } else if (/Mbps|Mb/i.test(cap)) {
    val = parseFloat(cap) || 0;
  } else {
    val = parseFloat(cap) || 0;
  }
  const mrc = (val <= 100 && val > 0) ? 110000 : (val > 100 ? 220000 : 0);
  updateMRC(mrc);
}

function updateRemoteHands(val) {
  const rhNRC = (val === '1' || val === 1) ? 80000 : 0;
  updateNRC(currentBaseNRC, rhNRC);
}

function renderSelectedFiles(input) {
  if (typeof window.renderFileInputPreview === 'function') {
    window.renderFileInputPreview(input);
  }
}

window.renderSelectedFiles = renderSelectedFiles;

document.addEventListener('DOMContentLoaded', function() {
  const dropZone = document.getElementById('dropZone');
  const fileInput = document.getElementById('fileInput');
  if (!dropZone || !fileInput) return;

  ['dragenter', 'dragover'].forEach(eventName => {
    dropZone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.style.borderColor = 'var(--accent)';
      dropZone.style.background = 'rgba(59, 130, 246, 0.08)';
    }, false);
  });

  ['dragleave', 'drop'].forEach(eventName => {
    dropZone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.style.borderColor = '';
      dropZone.style.background = '';
    }, false);
  });

  dropZone.addEventListener('drop', (e) => {
    const dt = e.dataTransfer;
    if (dt && dt.files && dt.files.length > 0) {
      const existing = Array.from(fileInput.files || []);
      const incoming = Array.from(dt.files);
      const dedupeFn = window.deduplicateFiles || function(arr) {
        const seen = new Set();
        return arr.filter(f => {
          const k = `${f.name}_${f.size}_${f.lastModified || 0}`;
          if (seen.has(k)) return false;
          seen.add(k);
          return true;
        });
      };

      const merged = dedupeFn([...existing, ...incoming]);
      try {
        const newDt = new DataTransfer();
        merged.forEach(f => newDt.items.add(f));
        fileInput.files = newDt.files;
      } catch (err) {}

      fileInput.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }, false);
});

// ============================================================
// BSA Bill of Materials (BoM) / Cost Breakdown Functions
// ============================================================
window.addNrcBoMRow = function(preset = null) {
  const tbody = document.getElementById('bomTableBody');
  if (!tbody) return;

  const rowId = 'bom_row_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
  const cat = preset?.category || 'Device';
  const desc = preset?.description || '';
  const brand = preset?.brand_model || '';
  const serial = preset?.serial || '';
  const qty = preset?.qty !== undefined ? preset.qty : 1;
  const unitPrice = preset?.unit_price !== undefined ? preset.unit_price : 0;
  const lineTotal = (qty * unitPrice);

  const tr = document.createElement('tr');
  tr.id = rowId;
  tr.className = 'bom-item-row';
  tr.innerHTML = `
    <td style="padding:8px 6px;vertical-align:middle">
      <select class="form-control form-control-sm bom-cat" onchange="recalcNrcBoMTotal()" style="padding:4px 8px;font-size:0.82rem">
        <option value="Device" ${cat === 'Device' ? 'selected' : ''}>Device / Equipment</option>
        <option value="Materials" ${cat === 'Materials' ? 'selected' : ''}>Materials / Cabling</option>
        <option value="Labor" ${cat === 'Labor' ? 'selected' : ''}>Labor / Installation Fee</option>
        <option value="Logistics" ${cat === 'Logistics' ? 'selected' : ''}>Transport / Logistics</option>
        <option value="Service" ${cat === 'Service' ? 'selected' : ''}>Service Fee / Configuration</option>
        <option value="Other" ${cat === 'Other' ? 'selected' : ''}>Other</option>
      </select>
    </td>
    <td style="padding:8px 6px;vertical-align:middle">
      <input type="text" class="form-control form-control-sm bom-desc" placeholder="e.g. Huawei Extender, Drop Cable..." value="${escapeHtml(desc)}" oninput="recalcNrcBoMTotal()" style="padding:4px 8px;font-size:0.82rem" required>
    </td>
    <td style="padding:8px 6px;vertical-align:middle">
      <input type="text" class="form-control form-control-sm bom-brand" placeholder="e.g. Huawei K562 / ZTE" value="${escapeHtml(brand)}" oninput="recalcNrcBoMTotal()" style="padding:4px 8px;font-size:0.82rem">
    </td>
    <td style="padding:8px 6px;vertical-align:middle">
      <input type="text" class="form-control form-control-sm bom-serial" placeholder="e.g. SN123456 (optional)" value="${escapeHtml(serial)}" oninput="recalcNrcBoMTotal()" style="padding:4px 8px;font-size:0.82rem">
    </td>
    <td style="padding:8px 6px;vertical-align:middle;width:80px">
      <input type="number" min="1" step="1" class="form-control form-control-sm bom-qty text-center" value="${qty}" oninput="recalcNrcBoMTotal()" style="padding:4px 8px;font-size:0.82rem" required>
    </td>
    <td style="padding:8px 6px;vertical-align:middle;width:130px">
      <div class="input-group input-group-sm" style="margin:0">
        <span class="input-group-text" style="font-size:0.75rem;padding:2px 6px">TZS</span>
        <input type="text" class="form-control form-control-sm bom-price text-end currency-input" data-currency="TZS" placeholder="0" value="${formatNumber(unitPrice)}" oninput="recalcNrcBoMTotal()" style="padding:4px 8px;font-size:0.82rem" required>
      </div>
    </td>
    <td style="padding:8px 6px;vertical-align:middle;text-align:right;font-weight:700;font-size:0.85rem;white-space:nowrap;width:130px">
      <span class="bom-line-total">TZS ${formatNumber(lineTotal)}</span>
    </td>
    <td style="padding:8px 6px;vertical-align:middle;text-align:center;width:40px">
      <button type="button" class="btn btn-sm btn-ghost text-danger" onclick="removeNrcBoMRow(this)" title="Remove item" style="padding:4px 6px">
        &times;
      </button>
    </td>
  `;

  tbody.appendChild(tr);
  recalcNrcBoMTotal();
};

window.removeNrcBoMRow = function(btn) {
  const row = btn.closest('tr');
  if (row) {
    row.remove();
    recalcNrcBoMTotal();
  }
};

window.recalcNrcBoMTotal = function() {
  const tbody = document.getElementById('bomTableBody');
  if (!tbody) return;

  const rows = tbody.querySelectorAll('.bom-item-row');
  const items = [];
  let grandTotal = 0;

  rows.forEach(r => {
    const cat = r.querySelector('.bom-cat')?.value || 'Other';
    const desc = r.querySelector('.bom-desc')?.value.trim() || '';
    const brand = r.querySelector('.bom-brand')?.value.trim() || '';
    const serial = r.querySelector('.bom-serial')?.value.trim() || '';
    const qtyVal = parseInt(r.querySelector('.bom-qty')?.value, 10);
    const qty = isNaN(qtyVal) || qtyVal < 1 ? 1 : qtyVal;

    const priceRaw = r.querySelector('.bom-price')?.value || '0';
    const cleanPrice = parseFloat(priceRaw.replace(/[^0-9.]/g, '')) || 0;
    const lineTotal = qty * cleanPrice;
    grandTotal += lineTotal;

    const lineTotalEl = r.querySelector('.bom-line-total');
    if (lineTotalEl) {
      lineTotalEl.textContent = 'TZS ' + formatNumber(lineTotal);
    }

    if (desc || cleanPrice > 0) {
      items.push({
        category: cat,
        description: desc,
        brand_model: brand,
        serial: serial,
        qty: qty,
        unit_price: cleanPrice,
        total: lineTotal
      });
    }
  });

  // Update Grand Total Display
  const grandTotalEl = document.getElementById('bomGrandTotalDisplay');
  if (grandTotalEl) {
    grandTotalEl.textContent = 'TZS ' + formatNumber(grandTotal);
  }

  // Update hidden JSON input
  const jsonInput = document.getElementById('nrcBreakdownJson');
  if (jsonInput) {
    jsonInput.value = items.length > 0 ? JSON.stringify(items) : '';
  }

  // Auto-sync with Revised NRC input field
  const revisedNrcInput = document.querySelector('input[name="revised_nrc"]');
  if (revisedNrcInput && items.length > 0) {
    revisedNrcInput.value = formatNumber(grandTotal);
    revisedNrcInput.dispatchEvent(new Event('input', { bubbles: true }));
  }

  // Auto-populate / suggest justification if empty or previously auto-generated
  const justInput = document.querySelector('input[name="nrc_justification"]');
  if (justInput && items.length > 0) {
    const isAuto = !justInput.value || justInput.dataset.autoGen === '1' || justInput.value.startsWith('BoM:');
    if (isAuto) {
      const summaryParts = items.map(it => `${it.description || it.category}${it.brand_model ? ' (' + it.brand_model + ')' : ''} x${it.qty}`);
      justInput.value = 'BoM: ' + summaryParts.join(', ');
      justInput.dataset.autoGen = '1';
    }
  }
};

function formatNumber(num) {
  return Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function escapeHtml(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

