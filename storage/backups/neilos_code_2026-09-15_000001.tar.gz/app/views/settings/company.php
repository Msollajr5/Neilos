<div class="page-header">
  <div class="page-header-left">
    <div class="page-title">Settings &amp; System Management</div>
    <div class="page-subtitle">Configure company details, service pricing, service types, and backup/migration</div>
  </div>
  <div class="page-header-actions">
    <div class="tab-nav" style="display:inline-flex;background:var(--surface-2);border-radius:var(--radius-md);padding:4px;gap:4px;flex-wrap:wrap">
      <a href="<?= APP_URL ?>/?page=settings&tab=company" class="btn <?= $tab === 'company' ? 'btn-primary' : 'btn-ghost' ?>" style="font-size:0.85rem">
        <?= svgIcon('building', 15) ?> Company Info
      </a>
      <a href="<?= APP_URL ?>/?page=settings&tab=pricing" class="btn <?= $tab === 'pricing' ? 'btn-primary' : 'btn-ghost' ?>" style="font-size:0.85rem">
        <?= svgIcon('dollar', 15) ?> Pricing &amp; Packages
      </a>
      <a href="<?= APP_URL ?>/?page=settings&tab=service_types" class="btn <?= $tab === 'service_types' ? 'btn-primary' : 'btn-ghost' ?>" style="font-size:0.85rem">
        <?= svgIcon('server', 15) ?> Service Types
      </a>
      <a href="<?= APP_URL ?>/?page=settings&tab=migration" class="btn <?= $tab === 'migration' ? 'btn-primary' : 'btn-ghost' ?>" style="font-size:0.85rem">
        <?= svgIcon('download', 15) ?> Backup &amp; Migration
      </a>
    </div>
  </div>
</div>

<?php if ($tab === 'migration'): ?>
<!-- ============================================================ -->
<!-- SYSTEM MIGRATION & PORTABILITY TAB                           -->
<!-- ============================================================ -->

<!-- Live System Overview Counters -->
<div class="kpi-grid" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:16px;margin-bottom:24px">
  <div class="card" style="padding:18px;border-left:4px solid var(--primary)">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">Database State</div>
    <div style="font-size:1.6rem;font-weight:800;color:var(--text-primary);margin-top:4px">
      <?= count($dbStats) ?> <span style="font-size:0.9rem;font-weight:500;color:var(--text-muted)">Tables</span>
    </div>
    <div style="font-size:0.8rem;color:var(--text-secondary);margin-top:4px">
      <?= array_sum(array_column($dbStats, 'rows')) ?> total database rows
    </div>
  </div>

  <div class="card" style="padding:18px;border-left:4px solid #10B981">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">Uploaded File Storage</div>
    <div style="font-size:1.6rem;font-weight:800;color:#10B981;margin-top:4px">
      <?= count($uploadFiles) ?> <span style="font-size:0.9rem;font-weight:500;color:var(--text-muted)">Files</span>
    </div>
    <div style="font-size:0.8rem;color:var(--text-secondary);margin-top:4px">
      <?= round($totalUploadSize / (1024 * 1024), 2) ?> MB total storage size
    </div>
  </div>

  <div class="card" style="padding:18px;border-left:4px solid #F59E0B">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">System Environment</div>
    <div style="font-size:1.4rem;font-weight:800;color:var(--text-primary);margin-top:4px">
      PHP <?= PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION ?>
    </div>
    <div style="font-size:0.8rem;color:var(--text-secondary);margin-top:4px">
      <?= htmlspecialchars(php_uname('s')) ?> (<?= htmlspecialchars(php_uname('n')) ?>)
    </div>
  </div>

  <div class="card" style="padding:18px;border-left:4px solid <?= $systemIntegrity['healthy'] ? '#10B981' : '#EF4444' ?>">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">Integrity Health</div>
    <div style="font-size:1.4rem;font-weight:800;color:<?= $systemIntegrity['healthy'] ? '#10B981' : '#EF4444' ?>;margin-top:4px">
      <?= $systemIntegrity['healthy'] ? '100% Healthy' : 'Action Required' ?>
    </div>
    <div style="font-size:0.8rem;color:var(--text-secondary);margin-top:4px">
      <?= count($systemIntegrity['warnings']) ?> warnings, <?= count($systemIntegrity['errors']) ?> errors
    </div>
  </div>
</div>

<div class="grid-2col" style="gap:24px;margin-bottom:24px">
  <!-- Card 1: Export Complete System -->
  <div class="card" style="border:1px solid var(--border)">
    <div class="card-header" style="background:rgba(15, 76, 129, 0.04)">
      <div class="card-title" style="display:flex;align-items:center;gap:8px">
        <?= svgIcon('download', 18) ?> Export System Package (Device A)
      </div>
    </div>
    <div class="card-body">
      <p style="font-size:0.9rem;color:var(--text-secondary);line-height:1.6;margin-bottom:16px">
        Creates a single, self-contained migration archive (<code>system-migration-*.zip</code>) containing:
      </p>
      <ul style="font-size:0.88rem;color:var(--text-primary);padding-left:20px;line-height:1.8;margin-bottom:20px">
        <li><strong>Complete Database Snapshot:</strong> All <?= count($dbStats) ?> tables, rows, relationships, and constraints.</li>
        <li><strong>Uploaded Files Storage:</strong> All <?= count($uploadFiles) ?> physical files (Signed SOFs, PDFs, DOCX, evidence, KYC attachments).</li>
        <li><strong>Portable Configuration:</strong> Company information, pricing rules, and SLA definitions.</li>
        <li><strong>Manifest & SHA-256 Checksums:</strong> Cryptographic integrity verification for every bundled file.</li>
      </ul>

      <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px;margin-bottom:20px">
        <div style="font-size:0.8rem;font-weight:700;text-transform:uppercase;color:var(--text-muted);margin-bottom:6px">Package Estimate</div>
        <div style="display:flex;justify-content:space-between;font-size:0.88rem">
          <span>Estimated Archive Size:</span>
          <span style="font-weight:700">~<?= round($totalUploadSize / (1024 * 1024), 2) + 0.5 ?> MB</span>
        </div>
      </div>

      <a href="<?= APP_URL ?>/?page=settings&action=export_system" class="btn btn-primary btn-lg" style="width:100%;justify-content:center">
        <?= svgIcon('download', 16) ?> Export & Download Migration Package (.zip)
      </a>
    </div>
  </div>

  <!-- Card 2: Import & Restore System -->
  <div class="card" style="border:1px solid var(--border)">
    <div class="card-header" style="background:rgba(16, 185, 129, 0.04)">
      <div class="card-title" style="display:flex;align-items:center;gap:8px">
        <?= svgIcon('upload', 18) ?> Restore / Import System (Device B)
      </div>
    </div>
    <div class="card-body">
      <form method="POST" action="<?= APP_URL ?>/?page=settings&action=import_system" enctype="multipart/form-data" onsubmit="return confirm('WARNING: Restoring this migration package will synchronize the database and uploads directory with the contents of the package. Do you wish to proceed?');">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

        <p style="font-size:0.9rem;color:var(--text-secondary);line-height:1.6;margin-bottom:16px">
          Select a <code>system-migration-*.zip</code> package exported from Device A to restore the entire portal state.
        </p>

        <div class="form-group" style="margin-bottom:16px">
          <label class="form-label" style="font-weight:700">Migration Package File (.zip) <span class="text-danger">*</span></label>
          <input type="file" name="migration_package" class="form-control" accept=".zip" required style="padding:10px">
          <div class="form-hint">Must contain a valid <code>manifest.json</code> and database snapshot.</div>
        </div>

        <div class="alert alert-warning" style="font-size:0.84rem;margin-bottom:20px">
          <strong>Notice:</strong> Database tables will be safely imported using transactions, and uploaded files will be unpacked directly into the active upload directory.
        </div>

        <button type="submit" class="btn btn-success btn-lg" style="width:100%;justify-content:center">
          <?= svgIcon('check', 16) ?> Validate & Restore System Migration
        </button>
      </form>
    </div>
  </div>
</div>

<!-- Card 3: Live System Health & Integrity Audit -->
<div class="card" style="border:1px solid var(--border)">
  <div class="card-header">
    <div class="card-title"><?= svgIcon('activity') ?> Live System & Storage Integrity Audit</div>
  </div>
  <div class="card-body">
    <div class="grid-2col" style="gap:24px">
      <!-- Database Entities -->
      <div>
        <div style="font-size:0.85rem;font-weight:700;color:var(--text-primary);margin-bottom:12px">Key Record Counts</div>
        <table class="table table-sm" style="width:100%;font-size:0.86rem">
          <thead>
            <tr>
              <th>Entity</th>
              <th style="text-align:right">Total Records</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($systemIntegrity['records'] as $tbl => $info): ?>
            <tr>
              <td><?= e($info['label']) ?> (<code><?= e($tbl) ?></code>)</td>
              <td style="text-align:right;font-weight:700"><?= number_format($info['count']) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Storage Locations & Warnings -->
      <div>
        <div style="font-size:0.85rem;font-weight:700;color:var(--text-primary);margin-bottom:12px">Storage Status & Warnings</div>
        <div style="background:var(--surface-2);border-radius:var(--radius-md);padding:14px;margin-bottom:14px;font-size:0.86rem">
          <div><strong>Upload Directory:</strong> <code><?= e($systemIntegrity['storage']['upload_dir']) ?></code></div>
          <div style="margin-top:6px"><strong>Directory Status:</strong> <?= $systemIntegrity['storage']['writable'] ? '<span class="badge badge-success">Writable</span>' : '<span class="badge badge-danger">Read Only</span>' ?></div>
          <div style="margin-top:6px"><strong>Physical Files on Disk:</strong> <?= number_format($systemIntegrity['storage']['file_count']) ?> files (<?= $systemIntegrity['storage']['total_mb'] ?> MB)</div>
        </div>

        <?php if (!empty($systemIntegrity['warnings'])): ?>
          <div class="alert alert-warning" style="font-size:0.82rem">
            <strong>Audit Notes:</strong>
            <ul style="margin:6px 0 0 16px;padding:0">
              <?php foreach ($systemIntegrity['warnings'] as $w): ?>
                <li><?= e($w) ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php else: ?>
          <div class="alert alert-success" style="font-size:0.84rem">
            <?= svgIcon('check') ?> All database file links and physical storage directories are 100% synchronized and healthy.
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php else: ?>
<!-- ============================================================ -->
<!-- COMPANY IDENTITY SETTINGS TAB                                -->
<!-- ============================================================ -->
<form method="POST" action="<?= APP_URL ?>/?page=settings&action=save_company" enctype="multipart/form-data">
  <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

  <div class="grid-2col">
    <!-- General Information -->
    <div class="card">
      <div class="card-header">
        <div class="card-title"><?= svgIcon('building') ?> Company Identity</div>
      </div>
      <div class="card-body">
        <div class="form-group">
          <label class="form-label">Legal Company Name <span class="text-danger">*</span></label>
          <input type="text" name="company_name" class="form-control" required value="<?= e($company['company_name'] ?? 'Neilos Network Ltd') ?>">
        </div>

        <div class="form-group">
          <label class="form-label">Trading / Brand Name</label>
          <input type="text" name="trading_name" class="form-control" value="<?= e($company['trading_name'] ?? 'Neilos') ?>" placeholder="e.g. Neilos Network">
        </div>

        <div class="grid-2col" style="gap:12px">
          <div class="form-group">
            <label class="form-label">TIN (Tax Identification No.)</label>
            <input type="text" name="tin" class="form-control" value="<?= e($company['tin'] ?? '') ?>" placeholder="e.g. 123-456-789">
          </div>
          <div class="form-group">
            <label class="form-label">VAT / VRN</label>
            <input type="text" name="vat_vrn" class="form-control" value="<?= e($company['vat_vrn'] ?? '') ?>" placeholder="e.g. 40-001234-X">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Certificate of Incorporation / Reg. No.</label>
          <input type="text" name="registration_number" class="form-control" value="<?= e($company['registration_number'] ?? '') ?>" placeholder="e.g. 145982">
        </div>

        <div class="form-group">
          <label class="form-label">Physical Address</label>
          <textarea name="address" class="form-control" rows="2" placeholder="e.g. Plot 42, Ali Hassan Mwinyi Rd, Victoria"><?= e($company['address'] ?? '') ?></textarea>
        </div>

        <div class="grid-2col" style="gap:12px">
          <div class="form-group">
            <label class="form-label">City / Region</label>
            <input type="text" name="city_region" class="form-control" value="<?= e($company['city_region'] ?? 'Dar es Salaam') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Country</label>
            <input type="text" name="country" class="form-control" value="<?= e($company['country'] ?? 'Tanzania') ?>">
          </div>
        </div>
      </div>
    </div>

    <!-- Contact & Signatory Details -->
    <div>
      <div class="card" style="margin-bottom:1.5rem">
        <div class="card-header">
          <div class="card-title"><?= svgIcon('user-check') ?> Authorized Signatory (For Countersigning SOF)</div>
        </div>
        <div class="card-body">
          <div class="form-group">
            <label class="form-label">Authorized Signatory Full Name</label>
            <input type="text" name="authorized_signatory" class="form-control" value="<?= e($company['authorized_signatory'] ?? '') ?>" placeholder="e.g. John Doe">
          </div>
          <div class="form-group">
            <label class="form-label">Designation / Title</label>
            <input type="text" name="signatory_title" class="form-control" value="<?= e($company['signatory_title'] ?? '') ?>" placeholder="e.g. Chief Executive Officer / Managing Director">
          </div>
        </div>
      </div>

      <div class="card" style="margin-bottom:1.5rem">
        <div class="card-header">
          <div class="card-title"><?= svgIcon('phone') ?> Official Contacts</div>
        </div>
        <div class="card-body">
          <div class="grid-2col" style="gap:12px">
            <div class="form-group">
              <label class="form-label">Official Phone</label>
              <input type="text" name="phone" class="form-control" value="<?= e($company['phone'] ?? '') ?>" placeholder="+255 22 ...">
            </div>
            <div class="form-group">
              <label class="form-label">General Email</label>
              <input type="email" name="email" class="form-control" value="<?= e($company['email'] ?? '') ?>" placeholder="info@neilos.co.tz">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Website URL</label>
            <input type="text" name="website" class="form-control" value="<?= e($company['website'] ?? 'https://neilos.co.tz') ?>">
          </div>

          <div class="grid-2col" style="gap:12px">
            <div class="form-group">
              <label class="form-label">Finance Billing Contact</label>
              <input type="text" name="finance_contact" class="form-control" value="<?= e($company['finance_contact'] ?? '') ?>" placeholder="Finance Dept">
            </div>
            <div class="form-group">
              <label class="form-label">Finance Email</label>
              <input type="email" name="finance_email" class="form-control" value="<?= e($company['finance_email'] ?? '') ?>" placeholder="billing@neilos.co.tz">
            </div>
          </div>

          <div class="grid-2col" style="gap:12px">
            <div class="form-group">
              <label class="form-label">NOC / Technical Contact</label>
              <input type="text" name="tech_contact" class="form-control" value="<?= e($company['tech_contact'] ?? '') ?>" placeholder="NOC Support Desk">
            </div>
            <div class="form-group">
              <label class="form-label">Technical Email</label>
              <input type="email" name="tech_email" class="form-control" value="<?= e($company['tech_email'] ?? '') ?>" placeholder="noc@neilos.co.tz">
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div class="card-title"><?= svgIcon('image') ?> Company Logo</div>
        </div>
        <div class="card-body">
          <?php if (!empty($company['logo_path'])): ?>
            <div style="margin-bottom:12px;padding:12px;background:#f8f9fa;border-radius:6px;text-align:center">
              <img src="<?= e(APP_URL . '/' . $company['logo_path']) ?>" alt="Neilos Logo" style="max-height:60px;max-width:200px;object-fit:contain">
            </div>
          <?php endif; ?>
          <div class="form-group">
            <label class="form-label">Upload New Logo (PNG / JPG / SVG)</label>
            <input type="file" name="logo" class="form-control" accept="image/*">
            <div class="form-hint">Shown in header of all printed Service Order Forms</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div style="margin-top:1.5rem;text-align:right">
    <button type="submit" class="btn btn-primary btn-lg"><?= svgIcon('check') ?> Save Company Settings</button>
  </div>
</form>
<?php endif; ?>

<?php if ($tab === 'pricing'): ?>
<!-- ============================================================ -->
<!-- PRICING & PACKAGES MANAGEMENT TAB                            -->
<!-- ============================================================ -->
<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:20px">
  <div>
    <h2 style="font-size:1.25rem;font-weight:700;margin:0">Service Pricing &amp; Package Management</h2>
    <div style="font-size:0.86rem;color:var(--text-secondary);margin-top:2px">
      Manage MRC and NRC pricing for FTTH, FTTB, Layer 2, and all service tiers without code changes.
    </div>
  </div>
  <button type="button" class="btn btn-primary" onclick="openAddPackageModal()">
    <?= svgIcon('plus') ?> Add New Package
  </button>
</div>

<!-- KPI Cards -->
<div class="stats-grid mb-24" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:16px;margin-bottom:20px">
  <div class="card" style="padding:16px;border-left:4px solid var(--primary)">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">Total Packages</div>
    <div style="font-size:1.6rem;font-weight:800;color:var(--text-primary);margin-top:4px"><?= count($allPricingPackages) ?></div>
  </div>
  <div class="card" style="padding:16px;border-left:4px solid #10B981">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">Active Packages</div>
    <div style="font-size:1.6rem;font-weight:800;color:#10B981;margin-top:4px">
      <?= count(array_filter($allPricingPackages, fn($p) => (int)$p['is_active'] === 1)) ?>
    </div>
  </div>
  <div class="card" style="padding:16px;border-left:4px solid #3B82F6">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">FTTH Tiers</div>
    <div style="font-size:1.6rem;font-weight:800;color:#3B82F6;margin-top:4px">
      <?= count(array_filter($allPricingPackages, fn($p) => stripos($p['service_type'], 'FTTH') !== false)) ?>
    </div>
  </div>
  <div class="card" style="padding:16px;border-left:4px solid #8B5CF6">
    <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase;font-weight:700">FTTB Tiers</div>
    <div style="font-size:1.6rem;font-weight:800;color:#8B5CF6;margin-top:4px">
      <?= count(array_filter($allPricingPackages, fn($p) => stripos($p['service_type'], 'FTTB') !== false)) ?>
    </div>
  </div>
</div>

<!-- Package Data Table -->
<div class="card">
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Service Type</th>
          <th>Package Name</th>
          <th>Code / Key</th>
          <th>Speed</th>
          <th>Monthly Recurring Charge (MRC)</th>
          <th>Non-Recurring (NRC)</th>
          <th>Status</th>
          <th>Order</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($allPricingPackages)): ?>
        <tr>
          <td colspan="9" style="text-align:center;padding:30px;color:var(--text-muted)">
            No pricing packages configured yet. Click <strong>[ + Add New Package ]</strong> to create your first package.
          </td>
        </tr>
        <?php else: ?>
        <?php foreach ($allPricingPackages as $pkg): ?>
        <tr>
          <td>
            <span class="badge badge-primary"><?= e($pkg['service_type']) ?></span>
          </td>
          <td class="font-600"><?= e($pkg['package_name']) ?></td>
          <td><code><?= e($pkg['package_code']) ?></code></td>
          <td><?= $pkg['speed_mbps'] ? (int)$pkg['speed_mbps'] . ' Mbps' : '—' ?></td>
          <td class="font-600" style="color:var(--accent)">
            <?= e($pkg['currency'] ?? 'TZS') ?> <?= money($pkg['mrc_amount']) ?>
          </td>
          <td class="text-muted font-sm">
            <?= e($pkg['currency'] ?? 'TZS') ?> <?= money($pkg['nrc_amount']) ?>
          </td>
          <td>
            <?php if ((int)$pkg['is_active'] === 1): ?>
              <span class="badge badge-success">Active</span>
            <?php else: ?>
              <span class="badge badge-secondary">Inactive</span>
            <?php endif; ?>
          </td>
          <td class="text-muted font-sm"><?= (int)$pkg['display_order'] ?></td>
          <td>
            <div class="actions" style="display:flex;gap:6px">
              <button type="button" class="btn btn-secondary btn-sm btn-icon" title="Edit Package" onclick='openEditPackageModal(<?= json_encode($pkg, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)'>
                <?= svgIcon('edit') ?>
              </button>
              <form method="POST" action="<?= APP_URL ?>/?page=settings&action=delete_pricing_package" style="display:inline" data-confirm="Delete pricing package '<?= e($pkg['package_name']) ?>'?">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                <input type="hidden" name="package_id" value="<?= $pkg['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete Package"><?= svgIcon('trash') ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal: Add / Edit Pricing Package -->
<div class="modal-backdrop" id="addEditPackageModal">
  <div class="modal" style="max-width:560px">
    <div class="modal-header">
      <div class="modal-title" id="packageModalTitle">Add New Pricing Package</div>
      <button class="modal-close" data-modal-close>&times;</button>
    </div>
    <form method="POST" action="<?= APP_URL ?>/?page=settings&action=save_pricing_package">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="package_id" id="modalPkgId" value="0">
      
      <div class="modal-body">
        <div class="form-grid form-grid-2">
          <div class="form-group">
            <label class="form-label">Service Type <span class="text-danger">*</span></label>
            <select name="service_type" id="modalPkgServiceType" class="form-control" required>
              <?php foreach ($allServiceTypes as $st): ?>
              <option value="<?= e($st['name']) ?>"><?= e($st['name']) ?></option>
              <?php endforeach; ?>
              <option value="FTTH">FTTH</option>
              <option value="FTTB">FTTB</option>
              <option value="Layer 2 ( last mile)">Layer 2 ( last mile)</option>
              <option value="BIA (Broadband Internet Access)">BIA (Broadband Internet Access)</option>
              <option value="DIA">DIA</option>
              <option value="Remote Hands Only">Remote Hands Only</option>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Speed in Mbps <span class="text-muted font-sm">(Optional)</span></label>
            <input type="number" name="speed_mbps" id="modalPkgSpeed" class="form-control" placeholder="e.g. 30" min="0">
          </div>
        </div>

        <div class="form-grid form-grid-2" style="margin-top:10px">
          <div class="form-group">
            <label class="form-label">Package Name <span class="text-danger">*</span></label>
            <input type="text" name="package_name" id="modalPkgName" class="form-control" placeholder="e.g. 30 Mbps or FTTx-30" required>
          </div>

          <div class="form-group">
            <label class="form-label">Package Code / Key <span class="text-muted font-sm">(Unique identifier)</span></label>
            <input type="text" name="package_code" id="modalPkgCode" class="form-control" placeholder="e.g. FTTx-30 or FTTB-30">
          </div>
        </div>

        <div class="form-grid form-grid-2" style="margin-top:10px">
          <div class="form-group">
            <label class="form-label">Monthly Recurring Charge (MRC) in TZS <span class="text-danger">*</span></label>
            <div class="input-group currency-input-group">
              <span class="input-group-text currency-badge">TZS</span>
              <input type="text" name="mrc_amount" id="modalPkgMrc" class="form-control currency-input" placeholder="e.g. 69,000" required>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Standard NRC in TZS <span class="text-muted font-sm">(Installation)</span></label>
            <div class="input-group currency-input-group">
              <span class="input-group-text currency-badge">TZS</span>
              <input type="text" name="nrc_amount" id="modalPkgNrc" class="form-control currency-input" placeholder="e.g. 140,000" value="140,000">
            </div>
          </div>
        </div>

        <div class="form-grid form-grid-2" style="margin-top:10px">
          <div class="form-group">
            <label class="form-label">Status</label>
            <select name="is_active" id="modalPkgActive" class="form-control">
              <option value="1">Active (Available in Portal)</option>
              <option value="0">Inactive (Hidden from New Orders)</option>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Display Order</label>
            <input type="number" name="display_order" id="modalPkgOrder" class="form-control" value="0" min="0">
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
        <button type="submit" class="btn btn-primary" id="packageModalSubmitBtn">Save Package</button>
      </div>
    </form>
  </div>
</div>

<script>
function openAddPackageModal() {
  document.getElementById('packageModalTitle').innerText = 'Add New Pricing Package';
  document.getElementById('modalPkgId').value = '0';
  document.getElementById('modalPkgName').value = '';
  document.getElementById('modalPkgCode').value = '';
  document.getElementById('modalPkgSpeed').value = '';
  document.getElementById('modalPkgMrc').value = '';
  document.getElementById('modalPkgNrc').value = '140,000';
  document.getElementById('modalPkgActive').value = '1';
  document.getElementById('modalPkgOrder').value = '0';
  document.getElementById('packageModalSubmitBtn').innerText = 'Create Package';
  document.getElementById('addEditPackageModal').classList.add('active');
}

function openEditPackageModal(pkg) {
  document.getElementById('packageModalTitle').innerText = 'Edit Pricing Package: ' + pkg.package_name;
  document.getElementById('modalPkgId').value = pkg.id;
  document.getElementById('modalPkgServiceType').value = pkg.service_type;
  document.getElementById('modalPkgName').value = pkg.package_name;
  document.getElementById('modalPkgCode').value = pkg.package_code;
  document.getElementById('modalPkgSpeed').value = pkg.speed_mbps || '';
  document.getElementById('modalPkgMrc').value = Number(pkg.mrc_amount).toLocaleString('en-US');
  document.getElementById('modalPkgNrc').value = Number(pkg.nrc_amount).toLocaleString('en-US');
  document.getElementById('modalPkgActive').value = pkg.is_active;
  document.getElementById('modalPkgOrder').value = pkg.display_order || 0;
  document.getElementById('packageModalSubmitBtn').innerText = 'Update Package';
  document.getElementById('addEditPackageModal').classList.add('active');
}
</script>
<?php endif; ?>

<?php if ($tab === 'service_types'): ?>
<!-- ============================================================ -->
<!-- SERVICE TYPES MANAGEMENT TAB                                 -->
<!-- ============================================================ -->
<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:20px">
  <div>
    <h2 style="font-size:1.25rem;font-weight:700;margin:0">Service Types Management</h2>
    <div style="font-size:0.86rem;color:var(--text-secondary);margin-top:2px">
      Add, edit, or disable service types dynamically across order creation, feasibility, and tracking.
    </div>
  </div>
  <button type="button" class="btn btn-primary" onclick="openAddServiceTypeModal()">
    <?= svgIcon('plus') ?> Add Service Type
  </button>
</div>

<!-- Service Types Table -->
<div class="card">
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Service Type Name</th>
          <th>Code / Key</th>
          <th>Description</th>
          <th>Pricing Model</th>
          <th>Status</th>
          <th>Order</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($allServiceTypes)): ?>
        <tr>
          <td colspan="7" style="text-align:center;padding:30px;color:var(--text-muted)">
            No service types found. Click <strong>[ + Add Service Type ]</strong> to configure.
          </td>
        </tr>
        <?php else: ?>
        <?php foreach ($allServiceTypes as $st): ?>
        <tr>
          <td class="font-600">
            <span class="badge badge-primary"><?= e($st['name']) ?></span>
          </td>
          <td><code><?= e($st['code']) ?></code></td>
          <td class="font-sm text-secondary"><?= e($st['description'] ?: '—') ?></td>
          <td>
            <?php
              $modelLabel = match($st['pricing_model'] ?? 'package') {
                'package'  => 'Package Tiers (FTTH / FTTB)',
                'capacity' => 'Capacity-based (Layer 2)',
                'custom'   => 'Custom Quote (BIA / DIA)',
                'fixed'    => 'Fixed Charge (Remote Hands)',
                default    => ucfirst($st['pricing_model'] ?? 'package')
              };
            ?>
            <span class="badge badge-secondary"><?= e($modelLabel) ?></span>
          </td>
          <td>
            <?php if ((int)$st['is_active'] === 1): ?>
              <span class="badge badge-success">Active</span>
            <?php else: ?>
              <span class="badge badge-secondary">Inactive</span>
            <?php endif; ?>
          </td>
          <td class="text-muted font-sm"><?= (int)$st['display_order'] ?></td>
          <td>
            <div class="actions" style="display:flex;gap:6px">
              <button type="button" class="btn btn-secondary btn-sm btn-icon" title="Edit Service Type" onclick='openEditServiceTypeModal(<?= json_encode($st, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)'>
                <?= svgIcon('edit') ?>
              </button>
              <form method="POST" action="<?= APP_URL ?>/?page=settings&action=delete_service_type" style="display:inline" data-confirm="Delete service type '<?= e($st['name']) ?>'?">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                <input type="hidden" name="service_type_id" value="<?= $st['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete Service Type"><?= svgIcon('trash') ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal: Add / Edit Service Type -->
<div class="modal-backdrop" id="addEditServiceTypeModal">
  <div class="modal" style="max-width:540px">
    <div class="modal-header">
      <div class="modal-title" id="serviceTypeModalTitle">Add Service Type</div>
      <button class="modal-close" data-modal-close>&times;</button>
    </div>
    <form method="POST" action="<?= APP_URL ?>/?page=settings&action=save_service_type">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="service_type_id" id="modalStId" value="0">
      
      <div class="modal-body">
        <div class="form-grid form-grid-2">
          <div class="form-group">
            <label class="form-label">Service Type Name <span class="text-danger">*</span></label>
            <input type="text" name="name" id="modalStName" class="form-control" placeholder="e.g. FTTH or Metro Fibre" required>
          </div>

          <div class="form-group">
            <label class="form-label">Code / Key <span class="text-muted font-sm">(Unique identifier)</span></label>
            <input type="text" name="code" id="modalStCode" class="form-control" placeholder="e.g. FTTH or Metro-Fibre">
          </div>
        </div>

        <div class="form-group" style="margin-top:10px">
          <label class="form-label">Description</label>
          <textarea name="description" id="modalStDescription" class="form-control" rows="2" placeholder="Brief explanation of the service type..."></textarea>
        </div>

        <div class="form-grid form-grid-2" style="margin-top:10px">
          <div class="form-group">
            <label class="form-label">Pricing Model</label>
            <select name="pricing_model" id="modalStModel" class="form-control">
              <option value="package">Package Tiers (FTTH / FTTB)</option>
              <option value="capacity">Capacity-based (Layer 2)</option>
              <option value="custom">Custom / Quote-based (BIA / DIA)</option>
              <option value="fixed">Fixed Rate (Remote Hands)</option>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Status</label>
            <select name="is_active" id="modalStActive" class="form-control">
              <option value="1">Active (Enabled across CRM)</option>
              <option value="0">Inactive (Disabled)</option>
            </select>
          </div>
        </div>

        <div class="form-group" style="margin-top:10px">
          <label class="form-label">Display Order</label>
          <input type="number" name="display_order" id="modalStOrder" class="form-control" value="0" min="0">
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
        <button type="submit" class="btn btn-primary" id="serviceTypeModalSubmitBtn">Save Service Type</button>
      </div>
    </form>
  </div>
</div>

<script>
function openAddServiceTypeModal() {
  document.getElementById('serviceTypeModalTitle').innerText = 'Add New Service Type';
  document.getElementById('modalStId').value = '0';
  document.getElementById('modalStName').value = '';
  document.getElementById('modalStCode').value = '';
  document.getElementById('modalStDescription').value = '';
  document.getElementById('modalStModel').value = 'package';
  document.getElementById('modalStActive').value = '1';
  document.getElementById('modalStOrder').value = '0';
  document.getElementById('serviceTypeModalSubmitBtn').innerText = 'Create Service Type';
  document.getElementById('addEditServiceTypeModal').classList.add('active');
}

function openEditServiceTypeModal(st) {
  document.getElementById('serviceTypeModalTitle').innerText = 'Edit Service Type: ' + st.name;
  document.getElementById('modalStId').value = st.id;
  document.getElementById('modalStName').value = st.name;
  document.getElementById('modalStCode').value = st.code;
  document.getElementById('modalStDescription').value = st.description || '';
  document.getElementById('modalStModel').value = st.pricing_model || 'package';
  document.getElementById('modalStActive').value = st.is_active;
  document.getElementById('modalStOrder').value = st.display_order || 0;
  document.getElementById('serviceTypeModalSubmitBtn').innerText = 'Update Service Type';
  document.getElementById('addEditServiceTypeModal').classList.add('active');
}
</script>
<?php endif; ?>


