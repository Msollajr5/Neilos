<?php
// ============================================================
// Order Detail View — v1.0
// Role-specific action panels for each lifecycle status
// ============================================================
require_once APP_DIR . '/helpers/sla.php';

$docs             = $docs ?? [];
$evidence         = $evidence ?? [];
$progressUpdates  = $progressUpdates ?? [];
$contractorList   = $contractorList ?? [];
$contractorTeams  = $contractorTeams ?? [];
$orderReturns     = $orderReturns ?? [];
$assignment       = $assignment ?? null;
$priceAudit       = $priceAudit ?? [];

$status = $order['status'] ?? 'Feasibility Review';
$isPartner = isPartnerUser();
$isBSA = hasRole('BSA');
$isKAM = hasRole('KAM');
$isMgmt = hasRole('Management');
$isPM   = hasRole('Project Manager');
$isContractor = isContractorUser();
$isAdminUser = isAdmin();
$isPMOnly = ($isPM && !$isAdminUser && !$isMgmt && !$isKAM && !$isBSA);

// Effective MRC (management override → revised → standard)
$effectiveMrc = $order['management_approved_price'] ?? $order['revised_mrc'] ?? $order['base_mrc'] ?? 0;
$effectiveNrc = $order['revised_nrc'] ?? $order['standard_nrc'] ?? $order['base_nrc_usd'] ?? 0;

$uatInfo = getUatCountdownInfo($order);

$stDisplay = !empty($order['service_type']) ? $order['service_type'] : '';
if (!$stDisplay) {
    if (!empty($order['fttx_package'])) {
        $stDisplay = 'FTTH';
    } elseif (!empty($order['aggregate_capacity'])) {
        $stDisplay = 'Layer 2 ( last mile)';
    } elseif (!empty($order['bandwidth'])) {
        $stDisplay = 'BIA (Broadband Internet Access)';
    } elseif ((float)($order['remote_hands_nrc_usd'] ?? 0) > 0 || (float)($order['base_nrc_usd'] ?? 0) == 80000) {
        $stDisplay = 'Remote Hands Only';
    } else {
        $stDisplay = 'Not specified';
    }
}
$partnerDisplayName = $order['partner_name'] ?? '';
?>
<div class="page-header" data-order-detail-id="<?= $order['id'] ?>">
  <div class="page-header-left">
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <div class="page-title" style="margin:0"><?= e($order['order_number']) ?></div>
      <?php if ($uatInfo['is_uat']): ?>
        <?= $uatInfo['badge_html'] ?>
      <?php endif; ?>
    </div>
    <div class="page-subtitle"><?= e($stDisplay) ?> · <?= e($order['customer_name'] ?? '') ?><?= !empty($partnerDisplayName) ? ' · ' . e($partnerDisplayName) : '' ?></div>
  </div>
  <div class="page-header-actions">
    <a href="<?= APP_URL ?>/?page=orders" class="btn btn-secondary"><?= svgIcon('list') ?> All Orders</a>
    <?php if ($status === 'Closed'): ?>
      <?php if ($isAdminUser || $isMgmt): ?>
        <button type="button" class="btn btn-warning" data-modal-open="editClosedOrderModal"><?= svgIcon('edit') ?> Edit Closed Order</button>
        <button type="button" class="btn btn-secondary" data-modal-open="statusModal"><?= svgIcon('refresh') ?> Status Override</button>
      <?php else: ?>
        <span class="badge badge-secondary" style="font-size:0.8rem;padding:7px 12px;display:inline-flex;align-items:center;gap:4px">🔒 Closed &amp; Locked</span>
      <?php endif; ?>
    <?php else: ?>
      <?php if ($isAdminUser || $isMgmt): ?>
        <button class="btn btn-secondary" data-modal-open="statusModal"><?= svgIcon('edit') ?> Admin Override</button>
      <?php endif; ?>
    <?php endif; ?>
    <?php if ($isAdminUser || $isMgmt): ?>
    <form method="POST" action="<?= APP_URL ?>/?page=orders&action=delete" style="display:inline" data-confirm="Permanently delete order <?= e($order['order_number']) ?>?">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="id" value="<?= $order['id'] ?>">
      <button type="submit" class="btn btn-danger"><?= svgIcon('trash') ?> Delete Order</button>
    </form>
    <?php endif; ?>
  </div>
</div>

<div class="<?= $isPartner ? 'order-detail-single-col' : 'order-detail-grid' ?> mb-24">
  <div class="card" style="margin-bottom:0">
    <div class="card-header"><div class="card-title">Order Details</div></div>
    <div class="card-body">
      <div class="order-kv-grid <?= $isPartner ? 'grid-3col' : '' ?>">
        <div class="order-kv-item">
          <span class="order-kv-label">Status :</span>
          <div class="order-kv-value"><span class="badge <?= orderStatusClass($status) ?>" style="font-size:.82rem;padding:4px 12px"><?= e($status) ?></span></div>
        </div>
        <div class="order-kv-item">
          <span class="order-kv-label">Service Type :</span>
          <div class="order-kv-value"><span class="badge badge-primary" style="font-size:.82rem;padding:4px 12px"><?= e($stDisplay) ?></span></div>
        </div>
        <?php if (!empty($order['fttx_package'])): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">FTTx Package :</span>
          <div class="order-kv-value"><?= e($order['fttx_package']) ?></div>
        </div>
        <?php endif; ?>
        <?php if (!empty($order['bandwidth'])): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">Bandwidth :</span>
          <div class="order-kv-value"><?= e($order['bandwidth']) ?> Mbps</div>
        </div>
        <?php endif; ?>
        <?php if (!empty($order['aggregate_capacity'])): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">Capacity :</span>
          <div class="order-kv-value"><?= e($order['aggregate_capacity']) ?> Mbps</div>
        </div>
        <?php endif; ?>
        <?php if (!empty($order['nni_location'])): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">NNI / Handoff :</span>
          <div class="order-kv-value"><?= e($order['nni_location']) ?></div>
        </div>
        <?php endif; ?>
        <?php if (!empty($order['remote_hands_required']) || (float)($order['remote_hands_nrc_usd'] ?? 0) > 0): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">Remote Hands :</span>
          <div class="order-kv-value"><span class="badge badge-warning">Required (+$<?= number_format((float)($order['remote_hands_nrc_usd'] ?? 35), 2) ?> USD)</span></div>
        </div>
        <?php endif; ?>
        <?php if (!empty($order['contract_term'])): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">Minimum Service Term :</span>
          <div class="order-kv-value"><?= e($order['contract_term']) ?></div>
        </div>
        <?php endif; ?>
        <div class="order-kv-item">
          <span class="order-kv-label">Customer Name :</span>
          <div class="order-kv-value"><?= e($order['customer_name']) ?></div>
        </div>
        <div class="order-kv-item">
          <span class="order-kv-label">Contact Person :</span>
          <div class="order-kv-value"><?= e($order['customer_contact_name'] ?: '—') ?></div>
        </div>
        <div class="order-kv-item">
          <span class="order-kv-label">Contact Phone :</span>
          <div class="order-kv-value"><?= e($order['customer_contact_phone'] ?? '—') ?></div>
        </div>
        <div class="order-kv-item">
          <span class="order-kv-label">Contact Email :</span>
          <div class="order-kv-value"><?= e($order['customer_contact_email'] ?? '—') ?></div>
        </div>
        <div class="order-kv-item">
          <span class="order-kv-label">Location :</span>
          <div class="order-kv-value"><?= e($order['customer_location'] ?? '—') ?></div>
        </div>
        <div class="order-kv-item">
          <span class="order-kv-label">Pickup Location :</span>
          <div class="order-kv-value">
            <?php if (!empty($order['pickup_location'])): ?>
              <span style="font-weight:600;color:var(--primary)">📍 <?= e($order['pickup_location']) ?></span>
            <?php else: ?>
              <span class="text-muted" style="font-style:italic">not updated</span>
            <?php endif; ?>
          </div>
        </div>
        <?php if (!empty($order['site_category'])): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">Site Category :</span>
          <div class="order-kv-value"><?= e($order['site_category']) ?></div>
        </div>
        <?php endif; ?>
        <?php if (!empty($order['gps_coordinates'])): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">GPS :</span>
          <div class="order-kv-value" style="font-family:monospace;font-size:0.83rem"><?= e($order['gps_coordinates']) ?></div>
        </div>
        <?php endif; ?>
        <div class="order-kv-item">
          <span class="order-kv-label">Partner :</span>
          <div class="order-kv-value"><?= e($order['partner_name'] ?? '—') ?></div>
        </div>
        <?php
          $hasProceededToKam = !empty($order['circuit_id']) || !in_array($order['status'] ?? '', ['Feasibility Review', 'Not Feasible', 'Cancelled']);
        ?>
        <?php if ($hasProceededToKam): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">Circuit ID :</span>
          <div class="order-kv-value font-mono text-primary" style="font-weight:700"><?= e($order['circuit_id'] ?: ('CKT-' . $order['order_number'])) ?></div>
        </div>
        <?php endif; ?>
        <?php 
          $installDateVal = $order['installation_date'] ?? ($assignment['completed_at'] ?? ($order['activation_date'] ?? ($order['closed_date'] ?? null)));
          $showInstallDate = !empty($installDateVal) || in_array($order['status'] ?? '', ['Testing', 'UAT', 'Closed']);
        ?>
        <?php if ($showInstallDate && !empty($installDateVal)): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">Installation Date :</span>
          <div class="order-kv-value font-600" style="color:var(--primary)"><?= fmtDate($installDateVal) ?></div>
        </div>
        <?php endif; ?>
        <?php if (!empty($order['closed_date']) || !empty($order['billing_start_date']) || $order['status'] === 'Closed'): ?>
        <div class="order-kv-item">
          <span class="order-kv-label">Closed Date :</span>
          <div class="order-kv-value text-success font-600"><?= fmtDate($order['closed_date'] ?? null) ?></div>
        </div>
        <div class="order-kv-item">
          <span class="order-kv-label">Billing Start Date :</span>
          <div class="order-kv-value text-success font-600"><?= fmtDate($order['billing_start_date'] ?? null) ?></div>
        </div>
        <div class="order-kv-item">
          <span class="order-kv-label">Service Active Status :</span>
          <div class="order-kv-value">
            <?php if (isOrderActive($order)): ?>
              <span class="badge badge-success">● Active</span>
            <?php else: ?>
              <span class="badge badge-secondary">● Inactive</span>
            <?php endif; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
      <?php if (!empty($order['special_requirements'])): ?>
      <div class="divider" style="margin:16px 0 12px"></div>
      <div class="order-kv-item" style="display:block;border-bottom:none">
        <span class="order-kv-label" style="margin-bottom:6px;display:inline-flex">Special Requirements :</span>
        <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px 14px;font-size:.875rem;white-space:pre-wrap"><?= e($order['special_requirements']) ?></div>
      </div>
      <?php endif; ?>
      <?php if (!$isPartner && !empty($order['bsa_technical_result'])): ?>
      <div class="divider" style="margin:16px 0 12px"></div>
      <div class="order-kv-item" style="border-bottom:none">
        <span class="order-kv-label">Technical Assessment :</span>
        <div class="order-kv-value">
          <span class="badge <?= $order['bsa_technical_result'] === 'Technically Feasible' ? 'badge-success' : 'badge-danger' ?>"><?= e($order['bsa_technical_result']) ?></span>
          <?php if (!empty($order['bsa_special_conditions'])): ?><span class="text-muted font-sm" style="margin-left:8px"><?= e($order['bsa_special_conditions']) ?></span><?php endif; ?>
        </div>
      </div>
      <?php endif; ?>
      <?php if (!$isPartner && $order['return_reason']): ?>
      <div class="divider" style="margin:16px 0 12px"></div>
      <div class="alert alert-warning" style="margin-bottom:0">
        <strong>Returned:</strong> <?= e($order['return_reason']) ?> — <?= e($order['return_remarks']) ?>
        <?php if ($order['returned_at']): ?><div class="font-sm text-muted"><?= fmtDateTime($order['returned_at']) ?></div><?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

<?php if ($isPMOnly): ?>
  <!-- Materials & Devices Used Card (PM View — Commercial pricing hidden) -->
  <div class="card" style="border:1px solid var(--border);border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);overflow:hidden;margin-bottom:0">
    <div class="card-header" style="background:var(--accent-pale);padding:14px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
      <div class="card-title" style="display:flex;align-items:center;gap:8px;font-size:1.05rem;font-weight:700;color:var(--text-primary)">
        <?= svgIcon('server', 18) ?> Materials &amp; Devices Used
      </div>
      <span class="badge badge-primary" style="font-size:0.75rem;padding:3px 8px">Technical Scope</span>
    </div>
    
    <div class="card-body" style="padding:18px">
      <?php 
        $nrcBreakdownList = !empty($order['nrc_breakdown']) ? json_decode($order['nrc_breakdown'], true) : null;
      ?>
      <div style="margin-bottom:16px">
        <div style="font-size:0.8rem;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-muted);margin-bottom:10px;display:flex;align-items:center;justify-content:space-between">
          <span>Bill of Materials &amp; Equipment</span>
          <span class="badge badge-secondary" style="font-size:0.72rem"><?= (!empty($nrcBreakdownList) && is_array($nrcBreakdownList)) ? count($nrcBreakdownList) . ' Item(s)' : 'Standard Package' ?></span>
        </div>

        <?php if (!empty($nrcBreakdownList) && is_array($nrcBreakdownList)): ?>
        <div style="background:var(--surface-2);border-radius:6px;border:1px solid var(--border);overflow:hidden">
          <table style="width:100%;font-size:0.8rem;border-collapse:collapse">
            <thead>
              <tr style="border-bottom:1px solid var(--border);background:rgba(0,0,0,0.02);color:var(--text-muted);text-align:left">
                <th style="padding:8px 10px">Category</th>
                <th style="padding:8px 10px">Item / Hardware Description</th>
                <th style="padding:8px 10px;text-align:center;width:45px">Qty</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($nrcBreakdownList as $bom): ?>
              <?php 
                $cat = $bom['category'] ?? 'Device';
                $isDev = ($cat === 'Device');
                $isMat = ($cat === 'Material' || $cat === 'Materials');
                $brandModelParts = array_filter([$bom['brand'] ?? '', $bom['model'] ?? '', $bom['brand_model'] ?? '']);
                $brandModelStr = implode(' ', array_unique($brandModelParts));
              ?>
              <tr style="border-bottom:1px solid var(--border)">
                <td style="padding:8px 10px;vertical-align:middle">
                  <?php if ($isDev): ?>
                    <span class="badge badge-primary" style="font-size:0.68rem;padding:2px 6px">Device</span>
                  <?php elseif ($isMat): ?>
                    <span class="badge" style="background:#e0f2fe;color:#0369a1;border:1px solid #bae6fd;font-size:0.68rem;padding:2px 6px">Material</span>
                  <?php else: ?>
                    <span class="badge badge-secondary" style="font-size:0.68rem;padding:2px 6px">Service</span>
                  <?php endif; ?>
                </td>
                <td style="padding:8px 10px;vertical-align:middle">
                  <div style="font-weight:600;color:var(--text-primary)"><?= e($bom['description'] ?? 'Item') ?></div>
                  <?php if ($brandModelStr): ?>
                    <div class="text-muted" style="font-size:0.75rem"><?= e($brandModelStr) ?></div>
                  <?php endif; ?>
                  <?php if (!empty($bom['serial'])): ?>
                    <div style="font-size:0.72rem;margin-top:2px">SN: <code><?= e($bom['serial']) ?></code></div>
                  <?php endif; ?>
                </td>
                <td style="padding:8px 10px;text-align:center;vertical-align:middle;font-weight:700"><?= (int)($bom['qty'] ?? 1) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
        <div style="padding:12px;background:var(--surface-2);border-radius:6px;border:1px solid var(--border);font-size:0.85rem;color:var(--text-secondary)">
          Standard installation materials and customer-premises equipment (ONT/ONU/CPE) allocated according to <strong><?= e($stDisplay) ?></strong> specifications.
        </div>
        <?php endif; ?>
      </div>

      <!-- Technical Specifications Summary -->
      <div style="padding-top:12px;border-top:1px dashed var(--border);display:flex;flex-direction:column;gap:8px;font-size:0.85rem">
        <div style="display:flex;justify-content:space-between">
          <span style="color:var(--text-secondary)">Service Profile:</span>
          <span style="font-weight:600;color:var(--text-primary)"><?= e($stDisplay) ?></span>
        </div>
        <?php if (!empty($order['fttx_package']) || !empty($order['bandwidth']) || !empty($order['aggregate_capacity'])): ?>
        <div style="display:flex;justify-content:space-between">
          <span style="color:var(--text-secondary)">Capacity / Plan:</span>
          <span style="font-weight:600;color:var(--text-primary)"><?= e($order['fttx_package'] ?: ($order['bandwidth'] ? $order['bandwidth'].' Mbps' : ($order['aggregate_capacity'] ? $order['aggregate_capacity'].' Mbps' : 'Standard'))) ?></span>
        </div>
        <?php endif; ?>
        <div style="display:flex;justify-content:space-between">
          <span style="color:var(--text-secondary)">Installation Location:</span>
          <span style="font-weight:600;color:var(--text-primary);text-align:right"><?= e($order['customer_location'] ?: '—') ?></span>
        </div>
        <div style="display:flex;justify-content:space-between">
          <span style="color:var(--text-secondary)">Confirmed Pickup Site:</span>
          <span style="font-weight:600;color:var(--primary);text-align:right">
            <?= !empty($order['pickup_location']) ? '📍 ' . e($order['pickup_location']) : '<em class="text-muted">Pending confirmation</em>' ?>
          </span>
        </div>
      </div>
    </div>
  </div>
<?php elseif (!$isPartner && $status !== 'Management Approval' && !$isPMOnly): ?>
  <!-- Commercial Summary Card (Internal Only — BSA, KAM, Mgmt, Admin) -->
  <div class="card" style="border:1px solid var(--border);border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);overflow:hidden;margin-bottom:0">
    <div class="card-header" style="background:var(--accent-pale);padding:14px 20px;border-bottom:1px solid var(--border)">
      <div class="card-title" style="display:flex;align-items:center;gap:8px;font-size:1.05rem;font-weight:700;color:var(--text-primary)">
        <?= svgIcon('chart', 18) ?> Commercial Summary
      </div>
    </div>
    
    <div class="card-body" style="padding:18px">
      <?php 
        $comm = getOrderCommercialSummary($order);
        $mrcCurr = $order['mrc_currency'] ?: 'USD';
        $currSymbol = ($mrcCurr === 'USD') ? '$' : $mrcCurr . ' ';
      ?>
      
      <!-- 1. NRC — One-Time Charges -->
      <div style="margin-bottom:18px;padding-bottom:16px;border-bottom:1px dashed var(--border)">
        <div style="font-size:0.8rem;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-muted);margin-bottom:10px;display:flex;align-items:center;justify-content:space-between">
          <span>NRC — One-Time Charges</span>
          <span style="font-size:0.72rem;font-weight:500;text-transform:none">Non-Recurring</span>
        </div>

        <div style="display:flex;flex-direction:column;gap:6px;font-size:0.88rem">
          <?php if (!$comm['has_rev_nrc'] && $comm['std_nrc'] > 0): ?>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="color:var(--text-secondary)">Standard NRC</span>
            <span style="font-weight:600;color:var(--text-primary);text-align:right"><?= $currSymbol ?><?= money($comm['std_nrc']) ?></span>
          </div>
          <?php endif; ?>

          <?php if ($comm['has_rev_nrc']): ?>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <span style="color:var(--text-muted);text-decoration:line-through">Standard NRC (<?= $currSymbol ?><?= money($comm['std_nrc']) ?>)</span>
              <span class="badge badge-secondary" style="font-size:0.7rem">Replaced</span>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <span style="color:var(--text-primary);font-weight:600">Revised NRC</span>
              <span style="font-weight:700;color:var(--accent);text-align:right"><?= $currSymbol ?><?= money($comm['rev_nrc']) ?></span>
            </div>
            <?php if (!empty($order['nrc_justification'])): ?>
            <div style="font-size:0.78rem;color:var(--text-muted);background:var(--surface-2);padding:4px 8px;border-radius:4px;margin-top:2px">
              <strong>Justification:</strong> <?= e($order['nrc_justification']) ?>
            </div>
            <?php endif; ?>
            <?php 
              $nrcBreakdownList = !empty($order['nrc_breakdown']) ? json_decode($order['nrc_breakdown'], true) : null;
              if (!empty($nrcBreakdownList) && is_array($nrcBreakdownList)):
            ?>
            <div style="margin-top:8px;padding:8px 10px;background:var(--surface-2);border-radius:6px;border:1px solid var(--border)">
              <div style="font-weight:700;font-size:0.78rem;color:var(--text-primary);margin-bottom:6px;display:flex;align-items:center;justify-content:space-between">
                <span><?= svgIcon('server', 12) ?> BoM Itemized Breakdown</span>
                <span class="badge badge-primary" style="font-size:0.68rem;padding:2px 6px"><?= count($nrcBreakdownList) ?> Items</span>
              </div>
              <table style="width:100%;font-size:0.75rem;border-collapse:collapse">
                <thead>
                  <tr style="border-bottom:1px solid var(--border);color:var(--text-muted);text-align:left">
                    <th style="padding:3px 2px">Item / Material / Service Details</th>
                    <th style="padding:3px 2px;text-align:center;width:35px">Qty</th>
                    <th style="padding:3px 2px;text-align:right">Unit Price</th>
                    <th style="padding:3px 2px;text-align:right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($nrcBreakdownList as $bom): ?>
                  <?php 
                    $cat = $bom['category'] ?? 'Device';
                    $isDev = ($cat === 'Device');
                    $isMat = ($cat === 'Material' || $cat === 'Materials');
                    $isSvc = (!$isDev && !$isMat);
                    $brandModelParts = array_filter([$bom['brand'] ?? '', $bom['model'] ?? '', $bom['brand_model'] ?? '']);
                    $brandModelStr = implode(' ', array_unique($brandModelParts));
                  ?>
                  <tr style="border-bottom:1px solid rgba(0,0,0,0.04)">
                    <td style="padding:4px 2px">
                      <?php if ($isDev): ?>
                        <span class="badge badge-primary" style="font-size:0.65rem;padding:1px 5px;margin-right:3px">Device</span>
                      <?php elseif ($isMat): ?>
                        <span class="badge" style="background:#e0f2fe;color:#0369a1;border:1px solid #bae6fd;font-size:0.65rem;padding:1px 5px;margin-right:3px">Material</span>
                      <?php else: ?>
                        <span class="badge badge-secondary" style="font-size:0.65rem;padding:1px 5px;margin-right:3px">Service</span>
                      <?php endif; ?>
                      <span style="font-weight:600;color:var(--text-primary)"><?= e($bom['description'] ?? 'Item') ?></span>
                      <?php if ($isDev && $brandModelStr): ?>
                        <span class="text-muted" style="font-size:0.72rem">(<?= e($brandModelStr) ?>)</span>
                      <?php endif; ?>
                      <?php if ($isDev && !empty($bom['serial'])): ?>
                        <div class="text-muted" style="font-size:0.7rem;margin-left:2px">SN: <code><?= e($bom['serial']) ?></code></div>
                      <?php endif; ?>
                    </td>
                    <td style="padding:4px 2px;text-align:center"><?= (int)($bom['qty'] ?? 1) ?></td>
                    <td style="padding:4px 2px;text-align:right"><?= $currSymbol ?><?= number_format((float)($bom['unit_price'] ?? 0), 2) ?></td>
                    <td style="padding:4px 2px;text-align:right;font-weight:600"><?= $currSymbol ?><?= number_format((float)($bom['total'] ?? 0), 2) ?></td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
            <?php endif; ?>
          <?php endif; ?>

          <?php if ($comm['rh_nrc'] > 0): ?>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="color:var(--text-secondary)">Remote Hands NRC</span>
            <span style="font-weight:600;color:var(--text-primary);text-align:right"><?= $currSymbol ?><?= money($comm['rh_nrc']) ?></span>
          </div>
          <?php endif; ?>

          <!-- Total NRC (One-Time) -->
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:rgba(16, 185, 129, 0.08);border:1px solid rgba(16, 185, 129, 0.3);border-radius:var(--radius-md);margin-top:6px">
            <span style="font-weight:700;color:#065F46">Total NRC (One-Time)</span>
            <span style="font-weight:800;font-size:1.05rem;color:#065F46;text-align:right"><?= $currSymbol ?><?= money($comm['total_nrc_net']) ?></span>
          </div>
        </div>
      </div>

      <!-- 2. MRC — Recurring Charges -->
      <div>
        <div style="font-size:0.8rem;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-muted);margin-bottom:10px;display:flex;align-items:center;justify-content:space-between">
          <span>MRC — Recurring Charges</span>
          <span style="font-size:0.72rem;font-weight:500;text-transform:none">Monthly</span>
        </div>

        <div style="display:flex;flex-direction:column;gap:6px;font-size:0.88rem">
          <?php if (!$comm['has_rev_mrc'] && !$comm['has_mgmt_mrc']): ?>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="color:var(--text-secondary)">Standard MRC (<?= e($mrcCurr) ?>)</span>
            <span style="font-weight:600;color:var(--text-primary);text-align:right"><?= $currSymbol ?><?= money($comm['std_mrc']) ?></span>
          </div>
          <?php endif; ?>

          <?php if ($comm['has_rev_mrc'] && !$comm['has_mgmt_mrc']): ?>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <span style="color:var(--text-muted);text-decoration:line-through">Standard MRC (<?= $currSymbol ?><?= money($comm['std_mrc']) ?>)</span>
              <span class="badge badge-secondary" style="font-size:0.7rem">Replaced</span>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <span style="color:var(--text-primary);font-weight:600">Proposed Exception MRC</span>
              <span style="font-weight:700;color:var(--accent);text-align:right"><?= $currSymbol ?><?= money($comm['rev_mrc']) ?></span>
            </div>
          <?php endif; ?>

          <?php if ($comm['has_mgmt_mrc']): ?>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <span style="color:var(--text-muted);text-decoration:line-through">Standard MRC (<?= $currSymbol ?><?= money($comm['std_mrc']) ?>)</span>
              <span class="badge badge-secondary" style="font-size:0.7rem">Overridden</span>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <span style="color:var(--text-primary);font-weight:600">Management Approved Price</span>
              <span style="font-weight:700;color:#10B981;text-align:right"><?= $currSymbol ?><?= money($comm['mgmt_mrc']) ?></span>
            </div>
          <?php endif; ?>

          <?php if (!empty($order['mrc_justification'])): ?>
          <div style="font-size:0.78rem;color:var(--text-muted);background:var(--surface-2);padding:4px 8px;border-radius:4px;margin-top:2px">
            <strong>MRC Justification:</strong> <?= e($order['mrc_justification']) ?>
          </div>
          <?php endif; ?>

          <?php if ($order['management_remarks'] && $order['management_remarks_visible']): ?>
          <div style="font-size:0.78rem;background:var(--surface-2);border-radius:4px;padding:6px 8px;margin-top:2px">
            <strong>Management note:</strong> <?= e($order['management_remarks']) ?>
          </div>
          <?php endif; ?>

          <!-- Total Monthly MRC -->
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:rgba(15, 76, 129, 0.08);border:1px solid rgba(15, 76, 129, 0.3);border-radius:var(--radius-md);margin-top:6px">
            <span style="font-weight:700;color:#0F4C81">Total Monthly MRC</span>
            <span style="font-weight:800;font-size:1.05rem;color:#0F4C81;text-align:right"><?= $currSymbol ?><?= money($comm['total_mrc_net']) ?></span>
          </div>
        </div>
      </div>

      <!-- Combined Contract Total -->
      <div style="margin-top:16px;padding:10px 14px;background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
        <span style="font-size:0.85rem;font-weight:700;color:var(--text-primary)">Total First Payment (NRC + 1st Month MRC)</span>
        <span style="font-size:1.05rem;font-weight:800;color:var(--text-primary);text-align:right"><?= $currSymbol ?><?= money($comm['total_first_payment_net']) ?></span>
      </div>

    </div>
  </div>
<?php endif; // !$isPartner ?>
</div>

<?php
// Authoritative Partner KYC for Billing Information
$orderPartnerKyc = getAuthoritativePartnerKyc($db, (int)$order['partner_id']) ?: [];
?>
<!-- Dedicated Billing Information & Billing Cycle Card -->
<div class="card mb-24" style="border:1px solid var(--border);border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);overflow:hidden">
  <div class="card-header" style="background:var(--accent-pale);padding:14px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
    <div class="card-title" style="display:flex;align-items:center;gap:8px;font-size:1.05rem;font-weight:700;color:var(--text-primary)">
      <?= svgIcon('credit-card', 18) ?> Billing Information &amp; Billing Cycle
    </div>
    <span class="badge badge-info" style="font-size:0.75rem;padding:3px 8px">USD ($) Standard</span>
  </div>
  <div class="card-body" style="padding:18px">
    <div class="order-kv-grid grid-3col">
      <div class="order-kv-item">
        <span class="order-kv-label">Billing Cycle :</span>
        <div class="order-kv-value font-600">Monthly in Advance</div>
      </div>
      <div class="order-kv-item">
        <span class="order-kv-label">Payment Terms :</span>
        <div class="order-kv-value font-600">Net 30 Days</div>
      </div>
      <div class="order-kv-item">
        <span class="order-kv-label">Billing Currency :</span>
        <div class="order-kv-value font-700 text-primary">USD ($)</div>
      </div>
      <div class="order-kv-item">
        <span class="order-kv-label">Billing Contact Person :</span>
        <div class="order-kv-value"><?= e($orderPartnerKyc['billing_contact_name'] ?? ($order['customer_contact_name'] ?: '—')) ?></div>
      </div>
      <div class="order-kv-item">
        <span class="order-kv-label">Billing Contact Email :</span>
        <div class="order-kv-value font-sm"><?= e($orderPartnerKyc['billing_contact_email'] ?? ($order['customer_contact_email'] ?: '—')) ?></div>
      </div>
      <div class="order-kv-item">
        <span class="order-kv-label">Billing Start Date :</span>
        <div class="order-kv-value">
          <?php if (!empty($order['billing_start_date'])): ?>
            <span class="text-success font-700">🗓️ <?= fmtDate($order['billing_start_date']) ?></span>
          <?php else: ?>
            <span class="text-muted font-sm" style="font-style:italic">Effective upon UAT completion</span>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php // ============================================================
// STATUS PROGRESS BAR (LIFECYCLE PIPELINE)
// ============================================================ ?>
<?php
$statusSteps = ['Feasibility Review','Await Commercial Approval','Pending SOF','SOF Review','Installation','Testing','UAT','Closed'];
$currentIdx = array_search($status, $statusSteps);
?>
<div class="card mb-24">
  <div class="card-header" style="padding:12px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;background:var(--surface-2)">
    <div style="font-weight:700;font-size:0.88rem;color:var(--text-primary);display:flex;align-items:center;gap:6px">
      <?= svgIcon('activity', 15) ?> Lifecycle Fulfillment Pipeline
    </div>
    <span class="badge <?= orderStatusClass($status) ?>" style="font-size:0.76rem;padding:3px 8px"><?= e($status) ?></span>
  </div>
  <div class="card-body" style="padding:18px 20px;overflow-x:auto">
    <div class="order-steps-scroll-wrapper">
      <?php foreach ($statusSteps as $idx => $step): ?>
      <?php
        if ($status === 'Closed') {
            $isDone    = true;
            $isCurrent = false;
        } else {
            $isDone    = $currentIdx !== false && $idx < $currentIdx;
            $isCurrent = $currentIdx !== false && $idx === $currentIdx;
        }
        $cls = $isDone ? 'step-done' : ($isCurrent ? 'step-current' : 'step-pending');
      ?>
      <div class="order-step <?= $cls ?>">
        <div class="order-step-dot"><?= $isDone ? svgIcon('check', 14) : ($idx + 1) ?></div>
        <div class="order-step-label"><?= e($step) ?></div>
      </div>
      <?php if ($idx < count($statusSteps) - 1): ?>
      <div class="order-step-connector <?= ($status === 'Closed' || ($currentIdx !== false && $idx < $currentIdx)) ? 'done' : '' ?>"></div>
      <?php endif; ?>
      <?php endforeach; ?>
    </div>
    <?php if (!empty($order['sla_paused'])): ?>
    <div class="alert alert-warning" style="margin-top:12px;margin-bottom:0;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
      <div>
        <strong>⏸ SLA Clock Paused:</strong> A contractor blocker has been posted on this order. (Paused since <?= fmtDateTime($order['sla_paused_at']) ?> · Accumulated: <?= (float)$order['sla_paused_hours'] ?> hrs)
      </div>
      <span class="badge badge-warning" style="font-size:0.8rem">SLA Clock Paused</span>
    </div>
    <?php endif; ?>
    <?php if ($status === 'Not Feasible'): ?>
    <div class="alert alert-danger" style="margin-top:12px;margin-bottom:0">
      <?= svgIcon('x') ?> <strong>Not Feasible:</strong> <?= e($order['bsa_not_feasible_reason']) ?>
    </div>
    <?php elseif ($status === 'Management Approval'): ?>
    <div class="alert alert-warning" style="margin-top:12px;margin-bottom:0">
      <?= svgIcon('users') ?> This order is awaiting <strong>Management Exception Approval</strong> (KAM Proposed NRC: <?= $order['kam_proposed_nrc'] !== null ? '$' . number_format((float)$order['kam_proposed_nrc'], 2) : 'Standard' ?>, MRC: <?= $order['kam_proposed_mrc'] !== null ? '$' . number_format((float)$order['kam_proposed_mrc'], 2) : 'Standard' ?>).
    </div>
    <?php endif; ?>
  </div>
</div>

<?php // ============================================================
// ROLE-SPECIFIC ACTION PANELS
// ============================================================ ?>

<?php // === PARTNER: INFORMATIVE PANELS FOR EARLY STAGES === ?>
<?php if ($status === 'Feasibility Review' && $isPartner): ?>
<div class="card" style="margin-bottom:24px;border:1px solid var(--border)">
  <div class="card-header" style="background:rgba(var(--primary-rgb,99,102,241),.06)">
    <div class="card-title"><?= svgIcon('search') ?> Technical Feasibility in Progress</div>
    <div class="card-subtitle">Our engineering team is assessing site coordinates, fibre path availability, and infrastructure feasibility.</div>
  </div>
  <div class="card-body">
    <div class="alert alert-info" style="margin-bottom:0">
      <?= svgIcon('info') ?> Initial site survey and route verification are underway. Once finalized, confirmed NRC and technical feasibility status will be updated here.
    </div>
  </div>
</div>
<?php endif; ?>

<?php if (in_array($status, ['Await Commercial Approval', 'Management Approval']) && $isPartner): ?>
<div class="card" style="margin-bottom:24px;border:1px solid var(--border)">
  <div class="card-header" style="background:rgba(var(--warning-rgb,245,158,11),.08)">
    <div class="card-title"><?= svgIcon('dollar') ?> Commercial Review in Progress</div>
    <div class="card-subtitle">Technical feasibility is confirmed. Your account manager is preparing and finalizing commercial terms.</div>
  </div>
  <div class="card-body">
    <div class="alert alert-info" style="margin-bottom:0">
      <?= svgIcon('clock') ?> Your order is under commercial review. As soon as pricing is confirmed, you will be prompted here to generate and sign your Service Order Form (SOF).
    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($status === 'Testing' && $isPartner): ?>
<div class="card" style="margin-bottom:24px;border:1px solid var(--border)">
  <div class="card-header" style="background:rgba(var(--primary-rgb,99,102,241),.06)">
    <div class="card-title"><?= svgIcon('check') ?> Testing &amp; Quality Verification</div>
    <div class="card-subtitle">Installation work is complete and line testing is underway.</div>
  </div>
  <div class="card-body">
    <div class="alert alert-info" style="margin-bottom:0">
      <?= svgIcon('info') ?> IP routing and line parameters are being tested by our NOC. You will be notified as soon as the link is released for your UAT (User Acceptance Testing) sign-off.
    </div>
  </div>
</div>
<?php endif; ?>

<?php // ============================================================
// ROLE-SPECIFIC ACTION PANELS
// ============================================================ ?>

<?php // === BSA: FEASIBILITY REVIEW PANEL === ?>
<?php if ($status === 'Feasibility Review' && ($isBSA || $isAdminUser)): ?>
<div class="card" style="margin-bottom:24px;border:2px solid var(--warning)">
  <div class="card-header" style="background:rgba(var(--warning-rgb,255,171,64),.12)">
    <div class="card-title"><?= svgIcon('search') ?> BSA Technical Review</div>
    <div class="card-subtitle">Review technical feasibility and confirm NRC. NRC only — do not edit MRC.</div>
  </div>
  <div class="card-body">
    <?php if ($order['return_remarks']): ?>
    <div class="alert alert-info" style="margin-bottom:16px">
      <strong>Partner concern:</strong> <?= e($order['return_remarks']) ?>
    </div>
    <?php endif; ?>

    <form method="POST" action="<?= APP_URL ?>/?page=orders&action=bsa_feasible" id="bsaFeasibilityForm">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
      <div class="form-grid form-grid-3">
        <div class="form-group">
          <label>Standard NRC (USD)</label>
          <div class="input-group currency-input-group">
            <span class="input-group-text currency-badge">$</span>
            <input type="text" class="form-control" value="<?= number_format((float)($order['standard_nrc'] ?? $order['base_nrc_usd']), 2) ?>" disabled style="opacity:.7">
          </div>
        </div>
        <div class="form-group">
          <label>Revised NRC (USD) <span class="text-muted font-sm">Calculated from BoM or direct USD</span></label>
          <div class="input-group currency-input-group">
            <span class="input-group-text currency-badge">$</span>
            <input type="text" name="revised_nrc" class="form-control currency-input" data-currency="USD" value="<?= $order['revised_nrc'] !== null ? number_format((float)$order['revised_nrc'], 2) : '' ?>" placeholder="e.g. 60.00">
          </div>
        </div>
        <div class="form-group">
          <label>NRC Justification <span class="required">*</span> <span class="text-muted font-sm">Mandatory if NRC changes</span></label>
          <input type="text" name="nrc_justification" class="form-control" value="<?= e($order['nrc_justification'] ?? '') ?>" placeholder="e.g. Extended fibre route 350m / BoM breakdown">
        </div>
      </div>

      <!-- Bill of Materials (BoM) / Itemized Cost Breakdown -->
      <div style="margin:20px 0 16px 0;border:1px solid var(--border);border-radius:var(--radius-md);overflow:hidden;background:var(--surface)">
        <div style="padding:12px 16px;background:var(--surface-2);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
          <div>
            <div style="font-weight:700;font-size:0.92rem;color:var(--text-primary);display:flex;align-items:center;gap:6px">
              <?= svgIcon('server', 15) ?> Itemized Cost Breakdown / Bill of Materials (BoM)
            </div>
            <div style="font-size:0.8rem;color:var(--text-secondary);margin-top:2px">
              Click <strong>+ Add Device</strong> (equipment with brand/model/serial), <strong>+ Add Material</strong> (materials with qty &amp; price), or <strong>+ Add Service</strong> (service fee).
            </div>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button type="button" class="btn btn-sm btn-primary" onclick="addNrcBoMRow({category:'Device',description:'',brand:'FiberHome',model:'',serial:'',qty:1,unit_price:0})" style="font-weight:600">
              <?= svgIcon('plus', 14) ?> Add Device
            </button>
            <button type="button" class="btn btn-sm btn-info" onclick="addNrcBoMRow({category:'Material',description:'',brand:'',model:'',serial:'',qty:1,unit_price:0})" style="font-weight:600;background:#0284c7;color:#fff;border-color:#0284c7">
              <?= svgIcon('plus', 14) ?> Add Material
            </button>
            <button type="button" class="btn btn-sm btn-secondary" onclick="addNrcBoMRow({category:'Service',description:'',brand:'',model:'',serial:'',qty:1,unit_price:0})" style="font-weight:600">
              <?= svgIcon('plus', 14) ?> Add Service
            </button>
          </div>
        </div>

        <div style="overflow-x:auto;padding:8px">
          <table class="data-table" style="width:100%;min-width:780px;font-size:0.85rem">
            <thead>
              <tr style="background:var(--surface-hover)">
                <th style="width:125px">Category <span class="text-danger">*</span></th>
                <th>Item / Material / Service Name <span class="text-danger">*</span></th>
                <th style="width:130px">Brand</th>
                <th style="width:120px">Model</th>
                <th style="width:130px">Serial #</th>
                <th style="width:65px;text-align:center">Qty</th>
                <th style="width:135px;text-align:right">Price ($)</th>
                <th style="width:130px;text-align:right">Total ($)</th>
                <th style="width:36px"></th>
              </tr>
            </thead>
            <tbody id="bomTableBody">
              <tr id="bomEmptyRow">
                <td colspan="9" style="text-align:center;padding:22px 16px;color:var(--text-muted);background:var(--surface-2)">
                  <div style="font-size:1.1rem;margin-bottom:4px">📦</div>
                  <div style="font-weight:600;font-size:0.86rem;color:var(--text-secondary)">No Breakdown Items Added Yet</div>
                  <div style="font-size:0.78rem;margin-top:2px">Click <strong>+ Add Device</strong>, <strong>+ Add Material</strong>, or <strong>+ Add Service</strong> to build your itemized cost breakdown.</div>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr style="font-weight:700;background:var(--surface-2);border-top:2px solid var(--border)">
                <td colspan="7" style="text-align:right;padding:10px 12px;font-size:0.9rem">
                  Calculated BoM Total (Auto-applied to Revised NRC):
                </td>
                <td style="text-align:right;padding:10px 12px;font-size:0.95rem;color:var(--accent)" id="bomGrandTotalDisplay">
                  $0.00
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
      <input type="hidden" name="nrc_breakdown_json" id="nrcBreakdownJson" value="<?= e($order['nrc_breakdown'] ?? '') ?>">

      <script>
      (function() {
        function escapeHtml(text) {
          if (!text) return '';
          return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
        }

        function formatNumber(num) {
          return Number(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }

        window.onBoMCatChange = function(selectEl) {
          const row = selectEl.closest('tr');
          if (!row) return;
          const cat = selectEl.value;
          const isDev = (cat === 'Device');
          const isMat = (cat === 'Material');
          const isSvc = (cat === 'Service');
          
          const descInput = row.querySelector('.bom-desc');
          const brandInput = row.querySelector('.bom-brand');
          const modelInput = row.querySelector('.bom-model');
          const serialInput = row.querySelector('.bom-serial');
          const qtyInput = row.querySelector('.bom-qty');
          const priceInput = row.querySelector('.bom-price');
          
          if (isDev) {
            if (descInput) descInput.placeholder = 'e.g. Fiber Router, Mesh Extender, ONU';
            if (brandInput) {
              brandInput.disabled = false;
              brandInput.style.background = '#fff';
              brandInput.style.color = 'inherit';
              if (!brandInput.value || brandInput.value === '—') brandInput.value = 'FiberHome';
              brandInput.placeholder = 'FiberHome';
            }
            if (modelInput) {
              modelInput.disabled = false;
              modelInput.style.background = '#fff';
              modelInput.style.color = 'inherit';
              if (modelInput.value === '—') modelInput.value = '';
              modelInput.placeholder = 'e.g. HG6245D';
            }
            if (serialInput) {
              serialInput.disabled = false;
              serialInput.style.background = '#fff';
              serialInput.style.color = 'inherit';
              if (serialInput.value === '—') serialInput.value = '';
              serialInput.placeholder = 'SN (if available)';
            }
            if (qtyInput) {
              qtyInput.disabled = false;
              qtyInput.style.background = '#fff';
              qtyInput.style.color = 'inherit';
              if (!qtyInput.value || qtyInput.value === '0') qtyInput.value = '1';
            }
            if (priceInput) priceInput.placeholder = '0.00';
          } else if (isMat) {
            if (descInput) descInput.placeholder = 'e.g. Fiber Cable 100m, Patch Cord, OTB, Fast Connector';
            if (brandInput) {
              brandInput.disabled = true;
              brandInput.style.background = '#f1f5f9';
              brandInput.style.color = '#94a3b8';
              brandInput.value = '—';
            }
            if (modelInput) {
              modelInput.disabled = true;
              modelInput.style.background = '#f1f5f9';
              modelInput.style.color = '#94a3b8';
              modelInput.value = '—';
            }
            if (serialInput) {
              serialInput.disabled = true;
              serialInput.style.background = '#f1f5f9';
              serialInput.style.color = '#94a3b8';
              serialInput.value = '—';
            }
            if (qtyInput) {
              qtyInput.disabled = false;
              qtyInput.style.background = '#fff';
              qtyInput.style.color = 'inherit';
              if (!qtyInput.value || qtyInput.value === '0') qtyInput.value = '1';
            }
            if (priceInput) priceInput.placeholder = '0.00';
          } else {
            // Service
            if (descInput) descInput.placeholder = 'e.g. Installation Fee, Splicing, Civil Works';
            if (brandInput) {
              brandInput.disabled = true;
              brandInput.style.background = '#f1f5f9';
              brandInput.style.color = '#94a3b8';
              brandInput.value = '—';
            }
            if (modelInput) {
              modelInput.disabled = true;
              modelInput.style.background = '#f1f5f9';
              modelInput.style.color = '#94a3b8';
              modelInput.value = '—';
            }
            if (serialInput) {
              serialInput.disabled = true;
              serialInput.style.background = '#f1f5f9';
              serialInput.style.color = '#94a3b8';
              serialInput.value = '—';
            }
            if (qtyInput) {
              qtyInput.disabled = true;
              qtyInput.style.background = '#f1f5f9';
              qtyInput.style.color = '#94a3b8';
              qtyInput.value = '1';
            }
            if (priceInput) priceInput.placeholder = '0.00';
          }
          
          recalcNrcBoMTotal();
        };

        window.addNrcBoMRow = function(preset = null) {
          const tbody = document.getElementById('bomTableBody');
          if (!tbody) return;

          const emptyRow = document.getElementById('bomEmptyRow');
          if (emptyRow) {
            emptyRow.style.display = 'none';
          }

          const rowId = 'bom_row_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
          const rawCat = preset?.category || 'Device';
          let cat = 'Device';
          if (rawCat === 'Material' || rawCat === 'Materials') cat = 'Material';
          else if (rawCat === 'Service') cat = 'Service';
          
          const isDev = (cat === 'Device');
          const isMat = (cat === 'Material');

          const desc = preset?.description || '';
          const brand = isDev ? (preset?.brand || preset?.brand_model || 'FiberHome') : '—';
          const model = isDev ? (preset?.model || '') : '—';
          const serial = isDev ? (preset?.serial || '') : '—';
          const qty = (isDev || isMat) ? (preset?.qty !== undefined ? preset.qty : 1) : 1;
          const unitPrice = preset?.unit_price !== undefined ? preset.unit_price : 0;
          const lineTotal = (qty * unitPrice);

          const tr = document.createElement('tr');
          tr.id = rowId;
          tr.className = 'bom-item-row';
          tr.style.borderBottom = '1px solid var(--border)';
          tr.innerHTML = `
            <td style="padding:6px 4px;vertical-align:middle">
              <select class="form-control form-control-sm bom-cat" onchange="onBoMCatChange(this)" style="padding:5px 6px;font-size:0.82rem;font-weight:600;background:#fff;border:1px solid #cbd5e1">
                <option value="Device" ${cat === 'Device' ? 'selected' : ''}>Device</option>
                <option value="Material" ${cat === 'Material' ? 'selected' : ''}>Material</option>
                <option value="Service" ${cat === 'Service' ? 'selected' : ''}>Service</option>
              </select>
            </td>
            <td style="padding:6px 4px;vertical-align:middle">
              <input type="text" class="form-control form-control-sm bom-desc" placeholder="${isDev ? 'e.g. Fiber Router, Extender, ONU' : (isMat ? 'e.g. Fiber Cable 100m, Patch Cord' : 'e.g. Installation Fee, Splicing')}" value="${escapeHtml(desc)}" oninput="recalcNrcBoMTotal()" style="padding:5px 8px;font-size:0.82rem;background:#fff;border:1px solid #cbd5e1" required>
            </td>
            <td style="padding:6px 4px;vertical-align:middle">
              <input type="text" class="form-control form-control-sm bom-brand" placeholder="FiberHome" value="${escapeHtml(brand)}" oninput="recalcNrcBoMTotal()" style="padding:5px 6px;font-size:0.82rem;background:${isDev ? '#fff' : '#f1f5f9'};color:${isDev ? 'inherit' : '#94a3b8'};border:1px solid #cbd5e1" ${!isDev ? 'disabled' : ''}>
            </td>
            <td style="padding:6px 4px;vertical-align:middle">
              <input type="text" class="form-control form-control-sm bom-model" placeholder="e.g. HG6245D" value="${escapeHtml(model)}" oninput="recalcNrcBoMTotal()" style="padding:5px 6px;font-size:0.82rem;background:${isDev ? '#fff' : '#f1f5f9'};color:${isDev ? 'inherit' : '#94a3b8'};border:1px solid #cbd5e1" ${!isDev ? 'disabled' : ''}>
            </td>
            <td style="padding:6px 4px;vertical-align:middle">
              <input type="text" class="form-control form-control-sm bom-serial" placeholder="SN (if available)" value="${escapeHtml(serial)}" oninput="recalcNrcBoMTotal()" style="padding:5px 6px;font-size:0.82rem;background:${isDev ? '#fff' : '#f1f5f9'};color:${isDev ? 'inherit' : '#94a3b8'};border:1px solid #cbd5e1" ${!isDev ? 'disabled' : ''}>
            </td>
            <td style="padding:6px 4px;vertical-align:middle;width:65px">
              <input type="number" min="1" step="1" class="form-control form-control-sm bom-qty text-center" value="${qty}" oninput="recalcNrcBoMTotal()" style="padding:5px 2px;font-size:0.82rem;background:${(isDev || isMat) ? '#fff' : '#f1f5f9'};color:${(isDev || isMat) ? 'inherit' : '#94a3b8'};border:1px solid #cbd5e1" ${(!isDev && !isMat) ? 'disabled' : ''} required>
            </td>
            <td style="padding:6px 4px;vertical-align:middle;width:135px">
              <div class="input-group input-group-sm" style="margin:0;display:flex">
                <span class="input-group-text" style="font-size:0.75rem;padding:2px 6px;background:#f1f5f9;border:1px solid #cbd5e1;border-right:none">$</span>
                <input type="text" class="form-control form-control-sm bom-price text-end currency-input" data-currency="USD" placeholder="0.00" value="${formatNumber(unitPrice)}" oninput="recalcNrcBoMTotal()" style="padding:5px 6px;font-size:0.82rem;background:#fff;border:1px solid #cbd5e1" required>
              </div>
            </td>
            <td style="padding:6px 4px;vertical-align:middle;text-align:right;font-weight:700;font-size:0.85rem;white-space:nowrap;width:130px">
              <span class="bom-line-total" style="color:var(--text-primary)">$${formatNumber(lineTotal)}</span>
            </td>
            <td style="padding:6px 4px;vertical-align:middle;text-align:center;width:36px">
              <button type="button" class="btn btn-sm btn-ghost text-danger" onclick="removeNrcBoMRow(this)" title="Remove item" style="padding:4px 6px;font-size:1.1rem;line-height:1;border:none;cursor:pointer">
                &times;
              </button>
            </td>
          `;

          tbody.appendChild(tr);
          recalcNrcBoMTotal();
        };

        window.removeNrcBoMRow = function(btn) {
          const row = btn.closest('tr');
          if (row) {
            row.remove();
            recalcNrcBoMTotal();
          }
        };

        window.recalcNrcBoMTotal = function() {
          const tbody = document.getElementById('bomTableBody');
          if (!tbody) return;

          const rows = tbody.querySelectorAll('.bom-item-row');
          const emptyRow = document.getElementById('bomEmptyRow');
          if (rows.length === 0) {
            if (emptyRow) emptyRow.style.display = '';
          } else {
            if (emptyRow) emptyRow.style.display = 'none';
          }

          const items = [];
          let grandTotal = 0;

          rows.forEach(r => {
            const cat = r.querySelector('.bom-cat')?.value || 'Device';
            const isDev = (cat === 'Device');
            const isMat = (cat === 'Material');
            const desc = r.querySelector('.bom-desc')?.value.trim() || '';
            const brand = isDev ? (r.querySelector('.bom-brand')?.value.trim() || 'FiberHome') : '';
            const model = isDev ? (r.querySelector('.bom-model')?.value.trim() || '') : '';
            const serial = isDev ? (r.querySelector('.bom-serial')?.value.trim() || '') : '';
            const qtyVal = parseInt(r.querySelector('.bom-qty')?.value, 10);
            const qty = (isDev || isMat) ? (isNaN(qtyVal) || qtyVal < 1 ? 1 : qtyVal) : 1;

            const priceRaw = r.querySelector('.bom-price')?.value || '0';
            const cleanPrice = parseFloat(priceRaw.replace(/[^0-9.]/g, '')) || 0;
            const lineTotal = qty * cleanPrice;
            grandTotal += lineTotal;

            const lineTotalEl = r.querySelector('.bom-line-total');
            if (lineTotalEl) {
              lineTotalEl.textContent = '$' + formatNumber(lineTotal);
            }

            if (desc || cleanPrice > 0) {
              items.push({
                category: cat,
                description: desc,
                brand: brand,
                model: model,
                brand_model: isDev ? trim(brand + ' ' + model) : '',
                serial: serial,
                qty: qty,
                unit_price: cleanPrice,
                total: lineTotal
              });
            }
          });

          function trim(s) { return s.trim(); }

          // Update Grand Total Display
          const grandTotalEl = document.getElementById('bomGrandTotalDisplay');
          if (grandTotalEl) {
            grandTotalEl.textContent = '$' + formatNumber(grandTotal);
          }

          // Update hidden JSON input
          const jsonInput = document.getElementById('nrcBreakdownJson');
          if (jsonInput) {
            jsonInput.value = items.length > 0 ? JSON.stringify(items) : '';
          }

          // Auto-sync with Revised NRC input field
          const revisedNrcInput = document.querySelector('input[name="revised_nrc"]');
          if (revisedNrcInput && items.length > 0) {
            revisedNrcInput.value = formatNumber(grandTotal);
            revisedNrcInput.dispatchEvent(new Event('input', { bubbles: true }));
          }

          // Auto-populate justification if empty or auto-generated
          const justInput = document.querySelector('input[name="nrc_justification"]');
          if (justInput && items.length > 0) {
            const isAuto = !justInput.value || justInput.dataset.autoGen === '1' || justInput.value.startsWith('BoM:');
            if (isAuto) {
              const summaryParts = items.map(it => {
                if (it.category === 'Device') {
                  const devLabel = [it.description, it.brand, it.model].filter(Boolean).join(' ');
                  return `${devLabel} x${it.qty}`;
                } else if (it.category === 'Material') {
                  return `${it.description || 'Material'} x${it.qty}`;
                }
                return `${it.description || 'Service'}`;
              });
              justInput.value = 'BoM: ' + summaryParts.join(', ');
              justInput.dataset.autoGen = '1';
            }
          }
        };

        // Initialize preloaded data or blank state
        document.addEventListener('DOMContentLoaded', function() {
          try {
            const rawJson = document.getElementById('nrcBreakdownJson')?.value;
            if (rawJson) {
              const preloaded = JSON.parse(rawJson);
              if (Array.isArray(preloaded) && preloaded.length > 0) {
                preloaded.forEach(item => addNrcBoMRow(item));
              }
            }
          } catch (e) {
            console.error("Error preloading BoM:", e);
          }
        });
      })();
      </script>

      <div class="form-group" style="margin-top:8px">
        <label>Technical Remarks <span class="required">*</span></label>
        <textarea name="technical_remarks" id="bsa_technical_remarks" class="form-control" rows="3" placeholder="Describe build requirement, distance, infrastructure conditions..." required><?= e($order['bsa_special_conditions'] ?? '') ?></textarea>
      </div>
      <div style="display:flex;gap:12px;margin-top:16px;flex-wrap:wrap">
        <button type="button" class="btn btn-secondary" onclick="previewBsaSubmission()"><?= svgIcon('eye') ?> Preview Feasibility</button>
        <button type="submit" class="btn btn-success"><?= svgIcon('check') ?> Mark Technically Feasible &amp; Proceed to KAM</button>
      </div>
    </form>

    <div class="divider" style="margin:16px 0"></div>

    <form method="POST" action="<?= APP_URL ?>/?page=orders&action=bsa_not_feasible" id="bsaNotFeasibleForm">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
      <div class="form-group">
        <label>Not Feasible Reason <span class="required">*</span></label>
        <textarea name="not_feasible_reason" id="not_feasible_reason_input" class="form-control" rows="2" placeholder="Mandatory reason why this is not technically feasible..."></textarea>
      </div>
      <button type="button" class="btn btn-danger" id="bsaNotFeasibleBtn"><?= svgIcon('x') ?> Technically Not Feasible</button>
    </form>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
      const notFeasibleBtn = document.getElementById('bsaNotFeasibleBtn');
      const notFeasibleForm = document.getElementById('bsaNotFeasibleForm');
      const reasonInput = document.getElementById('not_feasible_reason_input');

      if (notFeasibleBtn && notFeasibleForm) {
        notFeasibleBtn.addEventListener('click', function(e) {
          e.preventDefault();
          const reason = reasonInput ? reasonInput.value.trim() : '';
          if (!reason) {
            neilosAlert('Please enter a mandatory reason why this order is technically not feasible.', 'Reason Required', '⚠️');
            reasonInput?.focus();
            return;
          }

          neilosConfirm(
            'This will notify the partner that this order has been marked as technically not feasible.',
            'Mark as Technically Not Feasible?',
            'Mark as Not Feasible',
            'btn-danger',
            '🚫'
          ).then(function(confirmed) {
            if (confirmed) {
              notFeasibleForm.submit();
            }
          });
        });
      }
    });
    </script>
  </div>
</div>
<?php endif; ?>

<?php // === KAM: COMMERCIAL APPROVAL PANEL === ?>
<?php if ($status === 'Await Commercial Approval' && ($isKAM || $isAdminUser)): ?>
<div class="card" style="margin-bottom:24px;border:2px solid var(--warning)">
  <div class="card-header" style="background:rgba(var(--warning-rgb,255,171,64),.12)">
    <div class="card-title"><?= svgIcon('dollar') ?> KAM Commercial Review</div>
    <div class="card-subtitle">Define customer-specific currency exchange rate (TZS/USD), verify pricing, or propose commercial exception for Management approval.</div>
  </div>
  <div class="card-body">
    <div class="alert alert-info" style="margin-bottom:16px">
      <?= svgIcon('info') ?> <strong>NRC confirmed by BSA:</strong> $<?= number_format((float)($order['revised_nrc'] ?? $order['standard_nrc'] ?? $order['base_nrc_usd']), 2) ?>
      <?php if (!empty($order['management_return_remarks'])): ?>
        <br><strong>⚠️ Management Return Note:</strong> <?= e($order['management_return_remarks']) ?>
      <?php endif; ?>
      <?php if (!empty($order['sof_return_comments'])): ?>
        <br><strong>⚠️ Partner Return Note:</strong> <?= e($order['sof_return_comments']) ?>
      <?php endif; ?>
    </div>

    <form method="POST" action="<?= APP_URL ?>/?page=orders&action=kam_approve" id="kamApproveForm">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="order_id" value="<?= $order['id'] ?>">

      <div class="form-grid form-grid-2" style="margin-bottom:16px">
        <div class="form-group">
          <label>Exchange Rate (TZS per 1 USD) <span class="required">*</span></label>
          <div class="input-group currency-input-group">
            <span class="input-group-text" style="font-weight:700;font-size:0.8rem;background:var(--surface-2)">TZS</span>
            <input type="number" step="0.01" min="1" name="usd_tzs_rate" id="usd_tzs_rate_input" class="form-control" value="<?= htmlspecialchars((string)($order['usd_tzs_rate'] ?? '2600.00')) ?>" placeholder="e.g. 2600.00" required>
          </div>
          <div class="form-hint" style="font-size:0.75rem;color:var(--text-muted);margin-top:4px">Customer-specific conversion rate for this order (forwarded to Management).</div>
        </div>
        <div class="form-group">
          <label>Proposed Exception MRC (USD) <span class="text-muted font-sm">Leave blank for standard</span></label>
          <div class="input-group currency-input-group">
            <span class="input-group-text currency-badge">$</span>
            <input type="text" name="kam_proposed_mrc" id="kam_proposed_mrc_input" class="form-control currency-input" data-currency="USD" value="<?= $order['kam_proposed_mrc'] !== null ? number_format((float)$order['kam_proposed_mrc'], 2) : '' ?>" placeholder="e.g. 15.00">
          </div>
        </div>
      </div>

      <div class="form-group" style="margin-bottom:16px">
        <label>Proposed Exception NRC (USD) <span class="text-muted font-sm">Only if proposing different from BSA's NRC</span></label>
        <div class="input-group currency-input-group">
          <span class="input-group-text currency-badge">$</span>
          <input type="text" name="kam_proposed_nrc" id="kam_proposed_nrc_input" class="form-control currency-input" data-currency="USD" value="<?= $order['kam_proposed_nrc'] !== null ? number_format((float)$order['kam_proposed_nrc'], 2) : '' ?>" placeholder="Leave blank to use BSA confirmed NRC">
        </div>
      </div>

      <div class="form-group" style="margin-bottom:16px">
        <label>Commercial Justification <span class="text-muted font-sm">Mandatory if proposing pricing exception</span></label>
        <input type="text" name="kam_commercial_justification" id="kam_commercial_justification_input" class="form-control" value="<?= e($order['kam_commercial_justification'] ?? '') ?>" placeholder="e.g. Volume discount for 50-site deal approved by sales head">
      </div>

      <div class="form-group" style="margin-bottom:16px">
        <label>General KAM Remarks</label>
        <textarea name="kam_remarks" id="kam_remarks_input" class="form-control" rows="2" placeholder="Optional notes..."><?= e($order['kam_remarks'] ?? '') ?></textarea>
      </div>

      <div style="display:flex;gap:12px;flex-wrap:wrap">
        <button type="button" class="btn btn-secondary" onclick="previewKamSubmission()"><?= svgIcon('eye') ?> Preview Decision</button>
        <button type="submit" class="btn btn-success"><?= svgIcon('check') ?> Submit Commercial Decision</button>
      </div>
      <div class="form-hint" style="margin-top:8px">
        <strong>Note:</strong> Standard pricing moves order directly to <strong>Pending SOF</strong>. Discounted pricing is automatically routed to <strong>Management Approval</strong>.
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php // === MANAGEMENT APPROVAL PANEL (3-Option Decision Model) === ?>
<?php if ($status === 'Management Approval' && ($isMgmt || $isAdminUser)): ?>
<div class="card" style="margin-bottom:24px;border:2px solid var(--danger)">
  <div class="card-header" style="background:rgba(220,53,69,.1)">
    <div class="card-title"><?= svgIcon('users') ?> Management Approval — Pricing Exception Review</div>
    <div class="card-subtitle">Review KAM's pricing exception proposal and make an authoritative determination.</div>
  </div>
  <div class="card-body">
    <div class="grid-2col" style="gap:16px;margin-bottom:16px;padding:12px;background:var(--surface-2);border-radius:6px">
      <div>
        <div style="font-weight:700;margin-bottom:6px">Price Comparison (USD)</div>
        <div style="font-size:0.875rem;line-height:1.6">
          <strong>Currency Exchange Rate:</strong> <span class="font-600" style="color:var(--primary)">TZS <?= number_format((float)($order['usd_tzs_rate'] ?? 2600), 2) ?> / USD</span><br>
          <strong>BSA Confirmed NRC:</strong> $<?= number_format((float)($order['revised_nrc'] ?? $order['standard_nrc'] ?? $order['base_nrc_usd']), 2) ?><br>
          <strong>KAM Proposed NRC:</strong> <span class="text-danger font-600"><?= $order['kam_proposed_nrc'] !== null ? '$' . number_format((float)$order['kam_proposed_nrc'], 2) : '$' . number_format((float)($order['revised_nrc'] ?? $order['standard_nrc'] ?? $order['base_nrc_usd']), 2) ?></span><br>
          <strong>KAM Proposed MRC:</strong> <span class="text-danger font-600"><?= $order['kam_proposed_mrc'] !== null ? '$' . number_format((float)$order['kam_proposed_mrc'], 2) : '$' . number_format((float)($order['standard_mrc'] ?? $order['base_mrc']), 2) ?></span>
        </div>
      </div>
      <div>
        <div style="font-weight:700;margin-bottom:6px">Exception Justification</div>
        <div style="font-size:0.875rem;color:var(--text-secondary)">
          <?= e($order['kam_commercial_justification'] ?: ($order['mrc_justification'] ?: 'No justification provided.')) ?>
        </div>
      </div>
    </div>

    <form method="POST" action="<?= APP_URL ?>/?page=orders&action=management_decide" id="mgmtDecisionForm">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="order_id" value="<?= $order['id'] ?>">

      <div class="form-group" style="margin-bottom:16px">
        <label class="form-label" style="font-weight:700">Select Management Decision <span class="required">*</span></label>
        <div style="display:flex;flex-direction:column;gap:10px;margin-top:6px">
          <!-- Option 1 -->
          <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:12px;border:1px solid var(--border);border-radius:6px;background:var(--surface)">
            <input type="radio" name="management_decision" value="Approve as Requested" required onchange="toggleMgmtFields(this.value)">
            <div>
              <strong>1. Approve as Requested</strong>
              <div style="font-size:0.8rem;color:var(--text-secondary)">Accept KAM's proposed exception pricing and proceed to Pending SOF.</div>
            </div>
          </label>

          <!-- Option 2 & Nested Override Inputs -->
          <div style="border:1px solid var(--border);border-radius:6px;background:var(--surface);overflow:hidden">
            <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:12px;margin:0">
              <input type="radio" name="management_decision" value="Approve with Revised Price" required onchange="toggleMgmtFields(this.value)">
              <div>
                <strong>2. Approve with Revised Price</strong>
                <div style="font-size:0.8rem;color:var(--text-secondary)">Set custom management-approved NRC and/or MRC and proceed to Pending SOF.</div>
              </div>
            </label>
            <div id="mgmtRevisedPriceFields" style="display:none;padding:14px 16px;background:#f0fdf4;border-top:1px solid #86efac">
              <div style="font-weight:700;margin-bottom:8px;color:#166534">Management Final Price Override (USD)</div>
              <div class="grid-2col" style="gap:12px">
                <div class="form-group" style="margin:0">
                  <label>Final NRC (USD)</label>
                  <div class="input-group currency-input-group">
                    <span class="input-group-text currency-badge">$</span>
                    <input type="text" name="management_final_nrc" id="mgmt_final_nrc_input" class="form-control currency-input" data-currency="USD" value="<?= number_format((float)($order['kam_proposed_nrc'] ?? $order['revised_nrc'] ?? $order['standard_nrc'] ?? 0), 2) ?>" placeholder="e.g. 50.00">
                  </div>
                </div>
                <div class="form-group" style="margin:0">
                  <label>Final MRC (USD)</label>
                  <div class="input-group currency-input-group">
                    <span class="input-group-text currency-badge">$</span>
                    <input type="text" name="management_final_mrc" id="mgmt_final_mrc_input" class="form-control currency-input" data-currency="USD" value="<?= number_format((float)($order['kam_proposed_mrc'] ?? $order['standard_mrc'] ?? 0), 2) ?>" placeholder="e.g. 18.00">
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Option 3 & Nested Return Remarks -->
          <div style="border:1px solid var(--border);border-radius:6px;background:var(--surface);overflow:hidden">
            <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:12px;margin:0">
              <input type="radio" name="management_decision" value="Return to KAM" required onchange="toggleMgmtFields(this.value)">
              <div>
                <strong>3. Return to Account Manager (KAM)</strong>
                <div style="font-size:0.8rem;color:var(--text-secondary)">Send back to Commercial stage for revision with mandatory remarks.</div>
              </div>
            </label>
            <div id="mgmtReturnRemarksField" style="display:none;padding:14px 16px;background:#fef2f2;border-top:1px solid #fecaca">
              <div class="form-group" style="margin:0">
                <label style="color:#991b1b;font-weight:700">Return Remarks for KAM <span class="required">*</span></label>
                <textarea name="management_return_remarks" id="mgmt_return_remarks_input" class="form-control" rows="2" placeholder="Explain what the KAM should revise..."></textarea>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="form-group" style="margin-bottom:16px">
        <label>Management Decision Notes</label>
        <textarea name="management_remarks" id="mgmt_decision_notes_input" class="form-control" rows="2" placeholder="Optional audit comments..."><?= e($order['management_remarks'] ?? '') ?></textarea>
      </div>

      <div style="display:flex;gap:12px;flex-wrap:wrap">
        <button type="button" class="btn btn-secondary btn-lg" onclick="previewMgmtSubmission()"><?= svgIcon('eye') ?> Preview Decision</button>
        <button type="submit" class="btn btn-primary btn-lg"><?= svgIcon('check') ?> Confirm Management Decision</button>
      </div>
    </form>

    <script>
    function toggleMgmtFields(val) {
      document.getElementById('mgmtRevisedPriceFields').style.display = (val === 'Approve with Revised Price') ? 'block' : 'none';
      document.getElementById('mgmtReturnRemarksField').style.display = (val === 'Return to KAM') ? 'block' : 'none';
    }
    </script>
  </div>
</div>
<?php endif; ?>

<?php // === PARTNER: PENDING SOF PANEL === ?>
<?php if ($status === 'Pending SOF' && ($isPartner || $isAdminUser)): ?>
<div class="card" style="margin-bottom:24px;border:2px solid var(--primary)">
  <div class="card-header" style="background:rgba(var(--primary-rgb,99,102,241),.1)">
    <div class="card-title"><?= svgIcon('document') ?> Pending SOF — Action Required</div>
    <div class="card-subtitle">Your service is feasible and commercially approved. Please generate, sign, and upload the Service Order Form.</div>
  </div>
  <div class="card-body">
    <?php if ($order['sof_return_comments']): ?>
    <div class="alert alert-warning" style="margin-bottom:16px">
      <?= svgIcon('info') ?> <strong>SOF returned for correction:</strong> <?= e($order['sof_return_comments']) ?>
    </div>
    <?php endif; ?>

    <div style="display:flex;gap:16px;flex-wrap:wrap;align-items:flex-start">
      <div style="flex:1;min-width:280px">
        <div class="card" style="background:var(--surface-2)">
          <div class="card-body" style="padding:16px">
            <div style="font-weight:600;margin-bottom:8px">Step 1 — Generate SOF</div>
            <p style="font-size:.875rem;color:var(--text-secondary);margin-bottom:12px">Download and print your Service Order Form pre-filled with all approved terms.</p>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
              <button type="button" class="btn btn-primary" onclick="viewSystemFile('<?= APP_URL ?>/?page=orders&action=generate_sof&id=<?= $order['id'] ?>', 'SOF_<?= e($order['order_number']) ?>.pdf', '<?= APP_URL ?>/?page=orders&action=generate_sof&id=<?= $order['id'] ?>', {doc_type:'Service Order Form'})"><?= svgIcon('document') ?> Generate &amp; View SOF</button>
              <a href="<?= APP_URL ?>/?page=orders&action=generate_sof&id=<?= $order['id'] ?>" target="_blank" class="btn btn-secondary" title="Open full printable SOF in a new tab"><?= svgIcon('eye') ?> Full Page</a>
            </div>
          </div>
        </div>
      </div>
      <div style="flex:1;min-width:280px">
        <div class="card" style="background:var(--surface-2)">
          <div class="card-body" style="padding:16px">
            <div style="font-weight:600;margin-bottom:8px">Step 2 — Upload Signed SOF (PDF Only)</div>
            <?php if (!empty($order['sof_signed_file'])): ?>
              <div class="alert alert-success" style="padding:10px;margin-bottom:10px;font-size:0.85rem;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
                <div><?= svgIcon('check') ?> Signed SOF uploaded: <strong><?= e($order['sof_signed_filename']) ?></strong></div>
                <?= renderFileActions(['file_url' => $order['sof_signed_file'], 'file_name' => $order['sof_signed_filename'] ?: 'Signed SOF', 'download_url' => APP_URL . '/?page=download&table=orders&column=sof_signed_file&id=' . $order['id']]) ?>
              </div>
              <div style="border-top:1px dashed var(--border);padding-top:10px;margin-top:10px">
                <div style="font-size:0.8rem;font-weight:600;color:var(--text-secondary);margin-bottom:6px">Upload replacement signed SOF (PDF only):</div>
                <form method="POST" action="<?= APP_URL ?>/?page=orders&action=upload_signed_sof" enctype="multipart/form-data" class="order-action-form" data-action-title="Upload Replacement Signed SOF" data-action-role="Partner">
                  <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                  <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                  <div class="form-group" style="margin-bottom:8px">
                    <input type="file" name="signed_sof" class="form-control" accept=".pdf,application/pdf" required>
                  </div>
                  <button type="submit" class="btn btn-success btn-sm"><?= svgIcon('upload', 13) ?> Upload Replacement &amp; Submit Order</button>
                </form>
              </div>
            <?php else: ?>
              <p style="font-size:.875rem;color:var(--text-secondary);margin-bottom:12px">Sign the SOF (stamp + authorized signature) and upload it here (.PDF only).</p>
              <form method="POST" action="<?= APP_URL ?>/?page=orders&action=upload_signed_sof" enctype="multipart/form-data" class="order-action-form" data-action-title="Upload Signed Service Order Form" data-action-role="Partner">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                <div class="form-group" style="margin-bottom:8px">
                  <input type="file" name="signed_sof" class="form-control" accept=".pdf,application/pdf" required>
                </div>
                <button type="submit" class="btn btn-success"><?= svgIcon('upload') ?> Upload Signed SOF &amp; Submit Order</button>
              </form>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <div class="divider" style="margin:20px 0"></div>

    <div>
      <div style="font-weight:600;margin-bottom:10px;color:var(--text-secondary)">Not satisfied with the terms?</div>
      <form method="POST" action="<?= APP_URL ?>/?page=orders&action=return_to_feasibility" class="order-action-form" data-action-title="Return Order to Account Manager" data-action-role="Partner">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
        <div class="form-group" style="margin-bottom:12px">
          <label>Reason &amp; Remarks for Account Manager <span class="required">*</span></label>
          <input type="text" name="return_remarks" class="form-control" placeholder="Describe your concern (e.g. request higher bandwidth discount or revision)..." required>
        </div>
        <button type="submit" class="btn btn-warning"><?= svgIcon('refresh') ?> Return to Account Manager (KAM)</button>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>


<?php // === PARTNER: SOF REVIEW PANEL (partner can still re-upload replacement) === ?>
<?php if ($status === 'SOF Review' && ($isPartner || $isAdminUser)): ?>
<div class="card" style="margin-bottom:24px;border:2px solid var(--warning,#f59e0b)">
  <div class="card-header" style="background:rgba(245,158,11,.08)">
    <div class="card-title"><?= svgIcon('document') ?> SOF Under Review</div>
    <div class="card-subtitle">Your signed SOF has been submitted and is under review by Neilos. If you need to update the file, you can upload a replacement below (PDF only).</div>
  </div>
  <div class="card-body">
    <?php if (!empty($order['sof_signed_file'])): ?>
    <div class="alert alert-success" style="padding:10px;margin-bottom:14px;font-size:0.85rem;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
      <div><?= svgIcon('check') ?> Signed SOF submitted: <strong><?= e($order['sof_signed_filename']) ?></strong></div>
      <?= renderFileActions(['file_url' => $order['sof_signed_file'], 'file_name' => $order['sof_signed_filename'] ?: 'Signed SOF', 'download_url' => APP_URL . '/?page=download&table=orders&column=sof_signed_file&id=' . $order['id']]) ?>
    </div>
    <div style="border-top:1px dashed var(--border);padding-top:10px;margin-top:10px">
      <div style="font-size:0.8rem;font-weight:600;color:var(--text-secondary);margin-bottom:6px">Upload replacement signed SOF (.PDF only):</div>
      <form method="POST" action="<?= APP_URL ?>/?page=orders&action=upload_signed_sof" enctype="multipart/form-data" class="order-action-form" data-action-title="Upload Replacement Signed SOF" data-action-role="Partner">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
        <div class="form-group" style="margin-bottom:8px">
          <input type="file" name="signed_sof" class="form-control" accept=".pdf,application/pdf" required>
        </div>
        <button type="submit" class="btn btn-success btn-sm"><?= svgIcon('upload', 13) ?> Upload Replacement Signed SOF</button>
      </form>
    </div>
    <?php else: ?>
    <p style="font-size:.875rem;color:var(--text-secondary)">No signed SOF found. Please contact your account manager.</p>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>


<?php // === SOF REVIEW PANEL (KAM & Management Only) === ?>
<?php if ($status === 'SOF Review' && !$isPartner): ?>
  <?php if ($isKAM || $isMgmt || $isAdminUser): ?>
  <div class="card" style="margin-bottom:24px;border:2px solid var(--primary)">
    <div class="card-header"><div class="card-title"><?= svgIcon('edit') ?> SOF Review &amp; Countersignature</div></div>
    <div class="card-body">
      <?php if ($order['sof_signed_file']): ?>
      <div class="alert alert-success" style="margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
        <div><?= svgIcon('check') ?> Signed SOF uploaded by partner: <strong><?= e($order['sof_signed_filename']) ?></strong></div>
        <?= renderFileActions(['file_url' => $order['sof_signed_file'], 'file_name' => $order['sof_signed_filename'] ?: 'Signed SOF', 'download_url' => APP_URL . '/?page=download&table=orders&column=sof_signed_file&id=' . $order['id']]) ?>
      </div>
      <?php endif; ?>

      <div class="form-grid form-grid-2" style="margin-bottom:16px">
        <div>
          <div style="font-weight:600;margin-bottom:8px">Step 1 — Upload Countersigned SOF (PDF Only)</div>
          <p style="font-size:.875rem;color:var(--text-secondary);margin-bottom:12px">Upload the Neilos-countersigned copy. This becomes the official contractual document (.PDF only).</p>
          <?php if (!$order['countersigned_sof_file']): ?>
          <form method="POST" action="<?= APP_URL ?>/?page=orders&action=upload_countersigned_sof" enctype="multipart/form-data" class="order-action-form" data-action-title="Upload Countersigned SOF" data-action-role="KAM / Management">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
            <div class="form-group" style="margin-bottom:8px">
              <input type="file" name="countersigned_sof" class="form-control" accept=".pdf,application/pdf" required>
            </div>
            <button type="submit" class="btn btn-primary"><?= svgIcon('upload') ?> Upload Countersigned SOF</button>
          </form>
          <?php else: ?>
          <div class="alert alert-success" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
            <div><?= svgIcon('check') ?> Countersigned SOF uploaded: <strong><?= e($order['countersigned_sof_filename']) ?></strong> on <?= fmtDate($order['countersigned_sof_at']) ?></div>
            <?= renderFileActions(['file_url' => $order['countersigned_sof_file'], 'file_name' => $order['countersigned_sof_filename'] ?: 'Countersigned SOF', 'download_url' => APP_URL . '/?page=download&table=orders&column=countersigned_sof_file&id=' . $order['id']]) ?>
          </div>
          <?php endif; ?>
        </div>
        <div>
          <div style="font-weight:600;margin-bottom:8px">Step 2 — Proceed to Project</div>
          <p style="font-size:.875rem;color:var(--text-secondary);margin-bottom:12px">Only available after countersigned SOF is uploaded. This releases the order to Project/Installation.</p>
          <form method="POST" action="<?= APP_URL ?>/?page=orders&action=proceed_to_project" class="order-action-form" data-action-title="Proceed to Project Execution" data-action-role="KAM / Management">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
            <button type="submit" class="btn btn-success" <?= !$order['countersigned_sof_file'] ? 'disabled title="Upload countersigned SOF first"' : '' ?>>
              <?= svgIcon('project') ?> Proceed to Project
            </button>
          </form>
        </div>
      </div>

      <div class="divider" style="margin:16px 0"></div>

      <form method="POST" action="<?= APP_URL ?>/?page=orders&action=return_sof" class="order-action-form" data-action-title="Return SOF for Partner Correction" data-action-role="KAM / Management">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
        <div class="form-group">
          <label>Return SOF for Correction — Comments <span class="required">*</span></label>
          <textarea name="sof_return_comments" class="form-control" rows="2" placeholder="Describe what the partner needs to correct..." required></textarea>
        </div>
        <button type="submit" class="btn btn-warning"><?= svgIcon('refresh') ?> Return SOF to Partner</button>
      </form>
    </div>
  </div>
  <?php else: ?>
  <div class="card" style="margin-bottom:24px">
    <div class="card-header"><div class="card-title"><?= svgIcon('document') ?> SOF Review &amp; Countersignature</div></div>
    <div class="card-body">
      <div class="alert alert-info" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
        <div><?= svgIcon('info') ?> Signed SOF submitted by partner. Awaiting review and countersignature by <strong>KAM</strong> or <strong>Management</strong>.</div>
        <?php if ($order['sof_signed_file']): ?>
          <?= renderFileActions(['file_url' => $order['sof_signed_file'], 'file_name' => $order['sof_signed_filename'] ?: 'Signed SOF', 'download_url' => APP_URL . '/?page=download&table=orders&column=sof_signed_file&id=' . $order['id']]) ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endif; ?>
<?php endif; ?>

<?php // === INSTALLATION PANEL === ?>
<?php 
$additionalCostEvidences = array_filter($evidence ?? [], function($ev) {
    return (stripos($ev['evidence_type'] ?? '', 'Additional Cost') !== false);
});
?>
<?php if ($status === 'Installation'): ?>
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <div class="card-title"><?= svgIcon('project') ?> Installation</div>
    <div class="card-subtitle">Project is in progress. Contractor will update and submit evidence.</div>
  </div>
  <div class="card-body">
    <?php if (!$isPartner && ($isPM || $isAdminUser)): ?>
    <?php if ($assignment): ?>
    <div class="alert alert-info" style="margin-bottom:16px">
      Assigned to <strong><?= e($assignment['contractor_name']) ?></strong>
      <?php if (!empty($assignment['contractor_team_name']) || !empty($order['contractor_team_name'])): ?>
        (Team: <strong>👷 <?= e($assignment['contractor_team_name'] ?: $order['contractor_team_name']) ?></strong>)
      <?php elseif ($assignment['contractor_user_name']): ?>
        (<?= e($assignment['contractor_user_name']) ?>)
      <?php endif; ?>
      · Status: <span class="badge badge-primary"><?= e($assignment['status']) ?></span>
      <?php if ($assignment['target_date']): ?> · Due: <?= fmtDate($assignment['target_date']) ?><?php endif; ?>
    </div>
    <?php else: ?>
    <div class="alert alert-warning" style="margin-bottom:16px"><?= svgIcon('info') ?> No contractor assigned yet.</div>
    <form method="POST" action="<?= APP_URL ?>/?page=orders&action=assign_contractor" data-no-lookup="true">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
      <div class="form-grid form-grid-3">
        <div class="form-group">
          <label>Assign Contractor <span class="required">*</span></label>
          <select name="contractor_partner_id" class="form-control" data-no-lookup="true" required>
            <option value="">Select contractor...</option>
            <?php foreach ($contractorList as $c): ?>
            <option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Installation Target Date <span class="required">*</span></label>
          <input type="date" name="target_date" class="form-control" required>
        </div>
        <div class="form-group">
          <label>Work Order Notes</label>
          <input type="text" name="work_order_notes" class="form-control" placeholder="Any special instructions...">
        </div>
      </div>
      <button type="submit" class="btn btn-primary"><?= svgIcon('users') ?> Assign Contractor</button>
    <?php endif; ?>

    <!-- Contractor Additional Cost Claims / Forms Alert -->
    <?php if (!empty($additionalCostEvidences)): ?>
    <div style="margin-top:20px;border:2px solid #f59e0b;background:#fffbeb;border-radius:var(--radius-md);overflow:hidden">
      <div style="background:#fef3c7;padding:12px 18px;border-bottom:1px solid #fde68a;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
        <div style="display:flex;align-items:center;gap:8px;font-weight:700;color:#92400e;font-size:0.92rem">
          <span>📄</span> Contractor Additional Cost Form(s) Uploaded
          <span class="badge" style="background:#f59e0b;color:#fff;font-size:0.75rem"><?= count($additionalCostEvidences) ?> Form(s)</span>
        </div>
        <span style="font-size:0.78rem;font-weight:600;color:#b45309">Review Required by PM</span>
      </div>
      <div style="padding:14px 18px">
        <div style="display:flex;flex-direction:column;gap:10px">
          <?php foreach ($additionalCostEvidences as $ace): ?>
          <div style="background:#fff;border:1px solid #fde68a;border-radius:6px;padding:12px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
            <div style="flex:1;min-width:220px">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                <span class="badge" style="background:#fef3c7;color:#92400e;border:1px solid #fde68a;font-weight:700;font-size:0.75rem">Additional Cost Claim</span>
                <?php if (!empty($ace['cost_amount'])): ?>
                  <span class="badge" style="background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;font-weight:800;font-size:0.82rem">$<?= number_format((float)$ace['cost_amount'], 2) ?></span>
                <?php endif; ?>
              </div>
              <?php if (!empty($ace['notes'])): ?>
                <div style="font-size:0.86rem;color:var(--text-primary);font-weight:500;margin-bottom:4px"><?= e($ace['notes']) ?></div>
              <?php endif; ?>
              <div style="font-size:0.75rem;color:var(--text-muted)">
                Submitted by <strong><?= e($ace['full_name'] ?: 'Contractor') ?></strong> on <?= fmtDateTime($ace['uploaded_at']) ?>
                <?php if (!empty($ace['pickup_location'])): ?>
                  · 📍 Site: <?= e($ace['pickup_location']) ?>
                <?php endif; ?>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <?php if (!empty($ace['file_path'])): ?>
                <?= renderFileActions([
                  'file_url' => $ace['file_path'],
                  'file_name' => $ace['file_name'] ?: 'Additional Cost Form',
                  'download_url' => APP_URL . '/?page=download&table=contractor_evidence&id=' . $ace['id']
                ]) ?>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- PM Supplemental Project Updates & Challenges -->
    <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border)">
      <div class="card-subtitle" style="font-weight:700;color:var(--primary);margin-bottom:12px"><?= svgIcon('upload') ?> Project Manager — Installation Challenges &amp; Site Photos</div>
      <form method="POST" action="<?= APP_URL ?>/?page=contractor&action=upload_evidence" enctype="multipart/form-data" style="display:flex;flex-direction:column;gap:12px">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
        <input type="hidden" name="assignment_id" value="<?= $assignment['id'] ?? 0 ?>">
        <input type="hidden" name="redirect_to" value="<?= APP_URL ?>/?page=order_detail&id=<?= $order['id'] ?>">
        
        <div class="form-group" style="margin:0">
          <label class="font-sm" style="font-weight:600">Pickup Location <span class="text-muted" style="font-weight:normal">(The place in which installation was done)</span></label>
          <div style="position:relative">
            <span style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--text-secondary)">📍</span>
            <input type="text" name="pickup_location" class="form-control" style="padding-left:32px" value="<?= e($order['pickup_location'] ?? '') ?>" placeholder="Enter physical place / site address where installation was done...">
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;align-items:end">
          <div class="form-group" style="margin:0">
            <label class="font-sm">Evidence Type / Category</label>
            <select name="evidence_type" class="form-control" required>
              <option value="Site Photo">1. Site Photo</option>
              <option value="Signal Test">2. Signal Test</option>
              <option value="Serial Number">3. Serial Number</option>
              <option value="Speed Test">4. Speed Test</option>
              <option value="Ping Test">5. Ping Test</option>
              <option value="UAT">6. UAT</option>
              <option value="Additional Cost Form">7. Additional Cost Form</option>
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label class="font-sm">Notes / Challenge Details</label>
            <input type="text" name="notes" class="form-control" placeholder="Describe progress, challenge, or photo details...">
          </div>
          <div class="form-group" style="margin:0">
            <label class="font-sm">Upload Photo(s) / Document</label>
            <input type="file" name="evidence_files[]" class="form-control" accept=".jpg,.jpeg,.png,.pdf,.docx,.xlsx" multiple>
          </div>
        </div>
        <button type="submit" class="btn btn-secondary btn-sm" style="align-self: flex-start; margin-top: 4px">
          <?= svgIcon('upload') ?> Upload Supplemental Evidence / Notes
        </button>
      </form>

      <!-- Uploaded Installation Evidence & Photos Gallery -->
      <div style="margin-top:20px;padding-top:14px;border-top:1px dashed var(--border)">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
          <div style="font-weight:700;font-size:0.9rem;color:var(--text-primary);display:flex;align-items:center;gap:6px">
            <?= svgIcon('image') ?> Uploaded Installation Evidence &amp; Photos 
            <span class="badge badge-primary" style="font-size:0.75rem"><?= count($evidence) ?></span>
          </div>
        </div>
        <?= renderEvidenceGallery($evidence, [
          'can_delete'    => (!$isOrderClosed && ($isPM || $isAdminUser || $isBSA)),
          'order_id'      => $order['id'],
          'assignment_id' => $assignment['id'] ?? 0,
          'show_empty'    => true,
          'redirect_to'   => APP_URL . '/?page=order_detail&id=' . $order['id']
        ]) ?>
      </div>
    </div>

    <!-- PM Complete Installation / Move to Testing -->
    <div style="margin-top:20px;padding:16px 20px;border-top:1px solid var(--border);background:var(--surface-2);border-radius:var(--radius-sm)">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
        <div>
          <div style="font-weight:700;font-size:0.95rem;color:var(--text-primary)">
            <?= svgIcon('check') ?> Submit Job as Complete
          </div>
          <div style="font-size:0.84rem;color:var(--text-secondary);margin-top:2px">
            Installation work is finished. Move the order to <strong>Testing — Internal Review</strong> for PM/BSA testing approval.
          </div>
        </div>
        <form method="POST" action="<?= APP_URL ?>/?page=orders&action=submit_installation_complete" data-confirm="Submit job as complete? This will transition the order to Testing — Internal Review." style="margin:0">
          <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
          <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
          <input type="hidden" name="pickup_location" value="<?= e($order['pickup_location'] ?? '') ?>">
          <button type="submit" class="btn btn-success">
            <?= svgIcon('check') ?> Submit Job as Complete — Move to Testing
          </button>
        </form>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($isPartner): ?>
    <div class="alert alert-info">
      <?= svgIcon('info') ?> Your order is currently with our installation team. You will be notified once installation is complete and ready for your UAT acceptance.
    </div>
    <?php endif; ?>

    <?php if ($order['uat_return_reason']): ?>
    <div class="alert alert-warning" style="margin-top:12px">
      <strong>Returned from UAT:</strong> <?= e($order['uat_return_reason']) ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php // === TESTING PANEL (PM/BSA review) === ?>
<?php if ($status === 'Testing' && !$isPartner && !$isContractor): ?>
<div class="card" style="margin-bottom:24px;border:2px solid var(--primary)">
  <div class="card-header" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
    <div>
      <div class="card-title"><?= svgIcon('check') ?> Testing — Internal Review</div>
      <div class="card-subtitle">Contractor has submitted work. Review site photos &amp; evidence before sending to partner for UAT.</div>
    </div>
    <span class="badge badge-primary" style="padding:4px 10px;font-size:0.8rem">PM Review Stage</span>
  </div>
  <div class="card-body">
    
    <!-- Contractor Additional Cost Claims / Forms Alert in Testing -->
    <?php if (!empty($additionalCostEvidences)): ?>
    <div style="margin-bottom:20px;border:2px solid #f59e0b;background:#fffbeb;border-radius:var(--radius-md);overflow:hidden">
      <div style="background:#fef3c7;padding:12px 18px;border-bottom:1px solid #fde68a;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
        <div style="display:flex;align-items:center;gap:8px;font-weight:700;color:#92400e;font-size:0.92rem">
          <span>📄</span> Contractor Additional Cost Form(s) Uploaded
          <span class="badge" style="background:#f59e0b;color:#fff;font-size:0.75rem"><?= count($additionalCostEvidences) ?> Form(s)</span>
        </div>
        <span style="font-size:0.78rem;font-weight:600;color:#b45309">Requires PM Review</span>
      </div>
      <div style="padding:14px 18px">
        <div style="display:flex;flex-direction:column;gap:10px">
          <?php foreach ($additionalCostEvidences as $ace): ?>
          <div style="background:#fff;border:1px solid #fde68a;border-radius:6px;padding:12px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
            <div style="flex:1;min-width:220px">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                <span class="badge" style="background:#fef3c7;color:#92400e;border:1px solid #fde68a;font-weight:700;font-size:0.75rem">Additional Cost Claim</span>
                <?php if (!empty($ace['cost_amount'])): ?>
                  <span class="badge" style="background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;font-weight:800;font-size:0.82rem">$<?= number_format((float)$ace['cost_amount'], 2) ?></span>
                <?php endif; ?>
              </div>
              <?php if (!empty($ace['notes'])): ?>
                <div style="font-size:0.86rem;color:var(--text-primary);font-weight:500;margin-bottom:4px"><?= e($ace['notes']) ?></div>
              <?php endif; ?>
              <div style="font-size:0.75rem;color:var(--text-muted)">
                Submitted by <strong><?= e($ace['full_name'] ?: 'Contractor') ?></strong> on <?= fmtDateTime($ace['uploaded_at']) ?>
                <?php if (!empty($ace['pickup_location'])): ?>
                  · 📍 Site: <?= e($ace['pickup_location']) ?>
                <?php endif; ?>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <?php if (!empty($ace['file_path'])): ?>
                <?= renderFileActions([
                  'file_url' => $ace['file_path'],
                  'file_name' => $ace['file_name'] ?: 'Additional Cost Form',
                  'download_url' => APP_URL . '/?page=download&table=contractor_evidence&id=' . $ace['id']
                ]) ?>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Uploaded Installation Evidence & Photos Gallery -->
    <div style="margin-bottom:20px">
      <div style="font-weight:700;font-size:0.9rem;color:var(--text-primary);margin-bottom:8px;display:flex;align-items:center;gap:6px">
        <?= svgIcon('image') ?> Installation Evidence &amp; Site Photos
        <span class="badge badge-primary" style="font-size:0.75rem"><?= count($evidence) ?></span>
      </div>
      <?= renderEvidenceGallery($evidence, [
        'can_delete'    => (!$isOrderClosed && ($isPM || $isAdminUser || $isBSA)),
        'order_id'      => $order['id'],
        'assignment_id' => $assignment['id'] ?? 0,
        'show_empty'    => true,
        'redirect_to'   => APP_URL . '/?page=order_detail&id=' . $order['id']
      ]) ?>
    </div>

    <!-- PM Review & Confirm Pickup Location -->
    <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px 18px;margin-bottom:20px">
      <div style="font-weight:700;font-size:0.88rem;color:var(--text-primary);margin-bottom:6px;display:flex;align-items:center;gap:6px">
        <span>📍</span> Confirm Pickup / Installation Site Location (Review with Site Photos)
      </div>
      <div style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:10px">
        Verify the physical place / room / pole where installation was completed against the uploaded photos:
      </div>
      <form method="POST" action="<?= APP_URL ?>/?page=orders&action=update_pickup_location" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
        <div style="flex:1;min-width:260px;position:relative">
          <span style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--text-secondary)">📍</span>
          <input type="text" name="pickup_location" id="testing_pickup_location_input" class="form-control" style="padding-left:32px" value="<?= e($order['pickup_location'] ?? '') ?>" placeholder="Enter confirmed physical place / site address where installation was done..." oninput="document.getElementById('approve_testing_pickup_loc').value = this.value;">
        </div>
        <button type="submit" class="btn btn-secondary btn-sm" style="white-space:nowrap">
          <?= svgIcon('save', 14) ?> Save Pickup Location
        </button>
      </form>
    </div>

    <div style="display:flex;gap:12px;flex-wrap:wrap">
      <form method="POST" action="<?= APP_URL ?>/?page=orders&action=approve_testing">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
        <input type="hidden" name="pickup_location" id="approve_testing_pickup_loc" value="<?= e($order['pickup_location'] ?? '') ?>">
        <button type="submit" class="btn btn-success"><?= svgIcon('check') ?> Approve Testing — Move to UAT</button>
      </form>
      <button class="btn btn-warning" data-modal-open="returnContractorModal"><?= svgIcon('refresh') ?> Return to Contractor</button>
    </div>
  </div>
</div>

<div class="modal-backdrop" id="returnContractorModal">
  <div class="modal">
    <div class="modal-header"><div class="modal-title">Return to Contractor</div><button class="modal-close" data-modal-close>&times;</button></div>
    <form method="POST" action="<?= APP_URL ?>/?page=orders&action=return_to_contractor">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
      <div class="modal-body">
        <div class="form-group">
          <label>Comments for Contractor <span class="required">*</span></label>
          <textarea name="return_comments" class="form-control" rows="4" placeholder="What needs to be corrected or re-submitted?" required></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
        <button type="submit" class="btn btn-warning"><?= svgIcon('refresh') ?> Return to Contractor</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php // === UAT PANEL (Partner) === ?>
<?php if ($status === 'UAT'): ?>
<div class="card" style="margin-bottom:24px;border:2px solid var(--success)">
  <div class="card-header" style="background:rgba(var(--success-rgb,34,197,94),.1)">
    <div class="card-title"><?= svgIcon('check') ?> UAT — User Acceptance Testing</div>
    <div class="card-subtitle"><?= $isPartner ? 'Please review the installation evidence and accept or return the service.' : 'Awaiting partner UAT acceptance.' ?></div>
  </div>
  <div class="card-body">
    <?php if ($order['uat_notified_at']): ?>
    <div class="alert alert-info" style="margin-bottom:16px">
      <?= svgIcon('clock') ?> Partner notified: <?= fmtDateTime($order['uat_notified_at']) ?>
      <?php if ($order['uat_deadline']): ?>
      · Deadline: <?= fmtDateTime($order['uat_deadline']) ?>
      <strong> · <?= strtotime($order['uat_deadline']) > time() ? round((strtotime($order['uat_deadline']) - time()) / 3600) . ' hrs remaining' : '⚠️ EXPIRED — Auto-accept will trigger' ?></strong>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ($isPartner || $isAdminUser): ?>
    <div style="display:flex;gap:16px;flex-wrap:wrap">
      <div style="flex:1;min-width:240px">
        <form method="POST" action="<?= APP_URL ?>/?page=orders&action=uat_accept">
          <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
          <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
          <div style="background:rgba(var(--success-rgb,34,197,94),.08);border:1px solid var(--success);border-radius:var(--radius);padding:20px">
            <div style="font-weight:600;font-size:.95rem;margin-bottom:8px">✅ Accept Service</div>
            <p style="font-size:.85rem;color:var(--text-secondary);margin-bottom:12px">Service is working correctly. Accept and close the order. Billing start date will be set to today.</p>
            <button type="submit" class="btn btn-success"><?= svgIcon('check') ?> Accept Service — Close Order</button>
          </div>
        </form>
      </div>
      <div style="flex:1;min-width:240px">
        <form method="POST" action="<?= APP_URL ?>/?page=orders&action=return_to_installation">
          <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
          <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
          <div style="background:rgba(220,53,69,.06);border:1px solid var(--danger);border-radius:var(--radius);padding:20px">
            <div style="font-weight:600;font-size:.95rem;margin-bottom:8px">🔄 Return to Installation</div>
            <p style="font-size:.85rem;color:var(--text-secondary);margin-bottom:12px">Service requires correction. Please describe the issue.</p>
            <div class="form-group" style="margin-bottom:10px">
              <textarea name="return_reason" class="form-control" rows="3" placeholder="Describe what needs to be fixed..." required></textarea>
            </div>
            <button type="submit" class="btn btn-danger"><?= svgIcon('refresh') ?> Return to Installation</button>
          </div>
        </form>
      </div>
    </div>
    <?php else: ?>
    <div class="alert alert-info">Partner is reviewing installation. Awaiting acceptance or return.</div>
    <?php endif; ?>

    <?php if (!empty($evidence)): ?>
    <div class="divider" style="margin:20px 0"></div>
    <div style="font-weight:700;font-size:0.9rem;margin-bottom:8px;display:flex;align-items:center;gap:6px">
      <?= svgIcon('image') ?> Installation Evidence &amp; Test Results
      <span class="badge badge-primary" style="font-size:0.75rem"><?= count($evidence) ?></span>
    </div>
    <?= renderEvidenceGallery($evidence, [
      'can_delete'    => false,
      'order_id'      => $order['id'],
      'assignment_id' => $assignment['id'] ?? 0,
      'show_empty'    => false,
      'redirect_to'   => APP_URL . '/?page=order_detail&id=' . $order['id']
    ]) ?>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php // === CLOSED PANEL === ?>
<?php if ($status === 'Closed'): ?>
<div class="card" style="margin-bottom:24px;border:2px solid var(--success)">
  <div class="card-header" style="background:rgba(var(--success-rgb,34,197,94),.1)">
    <div class="card-title"><?= svgIcon('check') ?> Order Closed</div>
  </div>
  <div class="card-body">
    <div class="form-grid form-grid-4">
      <div class="form-group"><label>Installation Date</label><div class="font-600 text-primary"><?= fmtDate($order['installation_date'] ?? ($assignment['completed_at'] ?? ($order['activation_date'] ?? ($order['closed_date'] ?? null)))) ?></div></div>
      <div class="form-group"><label>Closed Date</label><div class="font-600 text-success"><?= fmtDate($order['closed_date']) ?></div></div>
      <div class="form-group"><label>Billing Start Date</label><div class="font-600 text-success"><?= fmtDate($order['billing_start_date']) ?></div></div>
      <div class="form-group"><label>Circuit ID</label><div class="font-600 font-mono text-primary"><?= e($order['circuit_id'] ?: ('CKT-' . $order['order_number'])) ?></div></div>
    </div>

    <?php if (!empty($evidence)): ?>
    <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border)">
      <div style="font-weight:700;font-size:0.9rem;color:var(--text-primary);margin-bottom:8px;display:flex;align-items:center;gap:6px">
        <?= svgIcon('image') ?> Completed Installation Photos &amp; Test Evidence
        <span class="badge badge-success" style="font-size:0.75rem"><?= count($evidence) ?></span>
      </div>
      <?= renderEvidenceGallery($evidence, [
        'can_delete'    => false,
        'order_id'      => $order['id'],
        'assignment_id' => $assignment['id'] ?? 0,
        'show_empty'    => false,
        'redirect_to'   => APP_URL . '/?page=order_detail&id=' . $order['id']
      ]) ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php // ============================================================
// COLLAPSIBLE ACCORDION SECTIONS: Timeline, Documents, Evidence, Contractor Updates, Returns, Price Audit
// (By default closed / collapsible to save vertical screen space)
// ============================================================ ?>
<div class="order-collapsible-sections" style="display:flex;flex-direction:column;gap:12px;margin-bottom:24px">

  <!-- 1. Documents Section -->
  <div class="card order-accordion-card" style="margin-bottom:0;border:1px solid var(--border);border-radius:var(--radius-md);overflow:hidden;box-shadow:var(--shadow-sm)">
    <div class="order-accordion-header" onclick="toggleOrderSection('order_section_documents')" style="cursor:pointer;padding:14px 20px;background:var(--surface-2);display:flex;align-items:center;justify-content:space-between;user-select:none;transition:background 0.2s ease">
      <div style="font-weight:700;font-size:0.95rem;color:var(--text-primary);display:flex;align-items:center;gap:10px">
        <?= svgIcon('document', 18) ?>
        <span>Order Documents &amp; SOF</span>
        <span class="badge badge-primary" style="font-size:0.75rem"><?= count($docs) ?> Files</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px">
        <span class="text-muted font-sm" style="font-size:0.75rem">Click to expand</span>
        <span id="chevron_order_section_documents" style="transition:transform 0.25s ease;display:inline-block;font-size:0.85rem">▼</span>
      </div>
    </div>
    <div id="order_section_documents" class="order-accordion-body" style="display:none;border-top:1px solid var(--border)">
      <div class="table-responsive">
        <table class="data-table">
          <thead><tr><th>File</th><th>Type</th><th>Size</th><th>Uploaded By</th><th>Date</th><th></th></tr></thead>
          <tbody>
            <?php if (empty($docs)): ?>
            <tr><td colspan="6"><div class="empty-state"><div class="empty-state-title">No documents uploaded</div></div></td></tr>
            <?php else: ?>
            <?php foreach ($docs as $d): ?>
            <tr>
              <td class="font-600"><?= e($d['file_name']) ?></td>
              <td>
                <?php
                $isCountersigned = (($d['doc_type'] ?? '') === 'countersigned_sof' || $d['document_type'] === 'Countersigned SOF');
                $isSigned = (($d['doc_type'] ?? '') === 'sof' || $d['document_type'] === 'Signed SOF');
                $badgeClass = $isCountersigned ? 'badge-success' : ($isSigned ? 'badge-primary' : 'badge-secondary');
                ?>
                <span class="badge <?= $badgeClass ?>"><?= e($d['document_type']) ?></span>
              </td>
              <td class="font-sm"><?= formatBytes($d['file_size']) ?></td>
              <td class="font-sm"><?= e($d['full_name'] ?: '—') ?></td>
              <td class="text-muted font-sm"><?= fmtDate($d['uploaded_at']) ?></td>
              <td><?= renderFileActions(['file_url' => $d['file_path'], 'file_name' => $d['file_name'] ?: 'Document', 'download_url' => APP_URL . '/?page=download&table=order_documents&id=' . $d['id']]) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- 3. Evidence & Installation Photos Section -->
  <?php if (!empty($evidence)): ?>
  <div class="card order-accordion-card" style="margin-bottom:0;border:1px solid var(--border);border-radius:var(--radius-md);overflow:hidden;box-shadow:var(--shadow-sm)">
    <div class="order-accordion-header" onclick="toggleOrderSection('order_section_evidence')" style="cursor:pointer;padding:14px 20px;background:var(--surface-2);display:flex;align-items:center;justify-content:space-between;user-select:none;transition:background 0.2s ease">
      <div style="font-weight:700;font-size:0.95rem;color:var(--text-primary);display:flex;align-items:center;gap:10px">
        <?= svgIcon('image', 18) ?>
        <span>Installation Evidence &amp; Photos</span>
        <span class="badge badge-success" style="font-size:0.75rem"><?= count($evidence) ?> Photos/Files</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px">
        <span class="text-muted font-sm" style="font-size:0.75rem">Click to expand</span>
        <span id="chevron_order_section_evidence" style="transition:transform 0.25s ease;display:inline-block;font-size:0.85rem">▼</span>
      </div>
    </div>
    <div id="order_section_evidence" class="order-accordion-body" style="display:none;border-top:1px solid var(--border)">
      <div class="card-body" style="padding:20px">
        <?= renderEvidenceGallery($evidence, [
          'can_delete'    => (!$isOrderClosed && ($isPM || $isAdminUser || $isBSA)),
          'order_id'      => $order['id'],
          'assignment_id' => $assignment['id'] ?? 0,
          'show_empty'    => true,
          'redirect_to'   => APP_URL . '/?page=order_detail&id=' . $order['id']
        ]) ?>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- 4. Contractor Progress Updates Section -->
  <?php if (!empty($progressUpdates) && !$isPartner): ?>
  <div class="card order-accordion-card" style="margin-bottom:0;border:1px solid var(--border);border-radius:var(--radius-md);overflow:hidden;box-shadow:var(--shadow-sm)">
    <div class="order-accordion-header" onclick="toggleOrderSection('order_section_progress')" style="cursor:pointer;padding:14px 20px;background:var(--surface-2);display:flex;align-items:center;justify-content:space-between;user-select:none;transition:background 0.2s ease">
      <div style="font-weight:700;font-size:0.95rem;color:var(--text-primary);display:flex;align-items:center;gap:10px">
        <?= svgIcon('users', 18) ?>
        <span>Contractor Field Updates &amp; Blockers</span>
        <span class="badge badge-secondary" style="font-size:0.75rem"><?= count($progressUpdates) ?> Updates</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px">
        <span class="text-muted font-sm" style="font-size:0.75rem">Click to expand</span>
        <span id="chevron_order_section_progress" style="transition:transform 0.25s ease;display:inline-block;font-size:0.85rem">▼</span>
      </div>
    </div>
    <div id="order_section_progress" class="order-accordion-body" style="display:none;border-top:1px solid var(--border)">
      <div class="card-body" style="padding:20px">
        <div class="timeline">
          <?php foreach ($progressUpdates as $pu): ?>
          <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-time"><?= fmtDateTime($pu['created_at']) ?> by <?= e($pu['full_name'] ?: '—') ?></div>
            <div class="timeline-label"><span class="badge badge-secondary"><?= e($pu['progress_status']) ?></span><?php if ($pu['delay_reason']): ?> <span class="badge badge-warning"><?= e($pu['delay_reason']) ?></span><?php endif; ?></div>
            <div class="timeline-note"><?= e($pu['notes']) ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- 5. Return Audit Trail Section -->
  <?php if (!empty($orderReturns) && !$isPartner): ?>
  <div class="card order-accordion-card" style="margin-bottom:0;border:1px solid var(--border);border-radius:var(--radius-md);overflow:hidden;box-shadow:var(--shadow-sm)">
    <div class="order-accordion-header" onclick="toggleOrderSection('order_section_returns')" style="cursor:pointer;padding:14px 20px;background:var(--surface-2);display:flex;align-items:center;justify-content:space-between;user-select:none;transition:background 0.2s ease">
      <div style="font-weight:700;font-size:0.95rem;color:var(--text-primary);display:flex;align-items:center;gap:10px">
        <?= svgIcon('refresh', 18) ?>
        <span>Return &amp; Correction Audit Trail</span>
        <span class="badge badge-warning" style="font-size:0.75rem"><?= count($orderReturns) ?> Returns</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px">
        <span class="text-muted font-sm" style="font-size:0.75rem">Click to expand</span>
        <span id="chevron_order_section_returns" style="transition:transform 0.25s ease;display:inline-block;font-size:0.85rem">▼</span>
      </div>
    </div>
    <div id="order_section_returns" class="order-accordion-body" style="display:none;border-top:1px solid var(--border)">
      <div class="table-responsive">
        <table class="data-table">
          <thead><tr><th>Date</th><th>By</th><th>From</th><th>To</th><th>Routed To</th><th>Reason</th><th>Remarks</th></tr></thead>
          <tbody>
            <?php foreach ($orderReturns as $r): ?>
            <tr>
              <td class="font-sm"><?= fmtDate($r['returned_at']) ?></td>
              <td class="font-sm"><?= e($r['full_name'] ?: '—') ?></td>
              <td><span class="badge <?= orderStatusClass($r['from_status']) ?>"><?= e($r['from_status']) ?></span></td>
              <td><span class="badge <?= orderStatusClass($r['to_status']) ?>"><?= e($r['to_status']) ?></span></td>
              <td><span class="badge badge-secondary"><?= e($r['routed_to']) ?></span></td>
              <td><?= e($r['return_reason']) ?></td>
              <td><?= e($r['return_remarks'] ?: '—') ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- 6. Commercial Pricing Modification Audit Trail Section -->
  <?php if (!empty($priceAudit) && !$isPartner): ?>
  <div class="card order-accordion-card" style="margin-bottom:0;border:1px solid var(--border);border-radius:var(--radius-md);overflow:hidden;box-shadow:var(--shadow-sm)">
    <div class="order-accordion-header" onclick="toggleOrderSection('order_section_price_audit')" style="cursor:pointer;padding:14px 20px;background:var(--surface-2);display:flex;align-items:center;justify-content:space-between;user-select:none;transition:background 0.2s ease">
      <div style="font-weight:700;font-size:0.95rem;color:var(--text-primary);display:flex;align-items:center;gap:10px">
        <?= svgIcon('dollar', 18) ?>
        <span>Commercial Pricing Modification Audit Trail</span>
        <span class="badge badge-secondary" style="font-size:0.75rem"><?= count($priceAudit) ?> Revisions</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px">
        <span class="text-muted font-sm" style="font-size:0.75rem">Click to expand</span>
        <span id="chevron_order_section_price_audit" style="transition:transform 0.25s ease;display:inline-block;font-size:0.85rem">▼</span>
      </div>
    </div>
    <div id="order_section_price_audit" class="order-accordion-body" style="display:none;border-top:1px solid var(--border)">
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Date &amp; Time</th>
              <th>Field Modified</th>
              <th>Previous Value</th>
              <th>New Value</th>
              <th>Modified By</th>
              <th>Lifecycle Stage</th>
              <th>Justification / Reason</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($priceAudit as $pa): ?>
            <tr>
              <td class="font-sm" style="white-space:nowrap"><?= fmtDateTime($pa['changed_at']) ?></td>
              <td><strong><?= e(priceFieldLabel($pa['field_name'])) ?></strong></td>
              <td class="font-sm text-muted"><?= $pa['old_value'] !== null ? '$' . number_format((float)$pa['old_value'], 2) : '—' ?></td>
              <td class="font-sm font-600" style="color:var(--primary)"><?= $pa['new_value'] !== null ? '$' . number_format((float)$pa['new_value'], 2) : '—' ?></td>
              <td class="font-sm"><?= e($pa['changed_by_name'] ?: 'System') ?></td>
              <td><span class="badge badge-secondary"><?= e($pa['stage']) ?></span></td>
              <td style="max-width:300px;font-size:0.85rem;color:var(--text-secondary)"><?= e($pa['justification'] ?: '—') ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <?php endif; ?>

</div>

<script>
function toggleOrderSection(sectionId) {
  const body = document.getElementById(sectionId);
  const chevron = document.getElementById('chevron_' + sectionId);
  if (!body) return;
  const isHidden = (body.style.display === 'none' || !body.style.display);
  body.style.display = isHidden ? 'block' : 'none';
  if (chevron) {
    chevron.style.transform = isHidden ? 'rotate(180deg)' : 'rotate(0deg)';
  }
}
</script>

<?php // Edit Closed Order Modal (Admin and Management only with mandatory audit reason) ?>
<?php if (($isAdminUser || $isMgmt) && $status === 'Closed'): ?>
<div class="modal-backdrop" id="editClosedOrderModal">
  <div class="modal" style="max-width:720px;width:95%">
    <div class="modal-header">
      <div style="display:flex;align-items:center;gap:8px">
        <div class="modal-title">Edit Closed Order — <?= e($order['order_number']) ?></div>
        <span class="badge badge-warning" style="font-size:0.75rem">Audit Reason Required</span>
      </div>
      <button class="modal-close" data-modal-close>&times;</button>
    </div>
    <form method="POST" action="<?= APP_URL ?>/?page=orders&action=edit_closed_order">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
      <div class="modal-body">
        <div class="alert alert-warning" style="margin-bottom:16px;font-size:0.85rem">
          <strong>⚠️ Audit Compliance Notice:</strong> Modifying a closed order will permanently log your identity, timestamp, and audit reason in the system audit trail.
        </div>

        <div class="form-grid form-grid-2">
          <div class="form-group">
            <label>Customer Name <span class="text-danger">*</span></label>
            <input type="text" name="customer_name" class="form-control" value="<?= e($order['customer_name']) ?>" required>
          </div>
          <div class="form-group">
            <label>Contact Person Name</label>
            <input type="text" name="customer_contact_name" class="form-control" value="<?= e($order['customer_contact_name']) ?>">
          </div>
          <div class="form-group">
            <label>Contact Phone</label>
            <input type="text" name="customer_contact_phone" class="form-control" value="<?= e($order['customer_contact_phone']) ?>">
          </div>
          <div class="form-group">
            <label>Contact Email</label>
            <input type="email" name="customer_contact_email" class="form-control" value="<?= e($order['customer_contact_email']) ?>">
          </div>
          <div class="form-group">
            <label>Location / Address</label>
            <input type="text" name="customer_location" class="form-control" value="<?= e($order['customer_location']) ?>">
          </div>
          <div class="form-group">
            <label>Pickup Location <span class="text-muted font-sm">(Place where installation was done)</span></label>
            <div style="position:relative">
              <span style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--text-secondary)">📍</span>
              <input type="text" name="pickup_location" class="form-control" style="padding-left:32px" value="<?= e($order['pickup_location'] ?? '') ?>" placeholder="e.g. Building A, Floor 3, Server Room 402">
            </div>
          </div>
          <div class="form-group">
            <label>Building Name</label>
            <input type="text" name="building_name" class="form-control" value="<?= e($order['building_name']) ?>">
          </div>
          <div class="form-group">
            <label>GPS Coordinates</label>
            <input type="text" name="gps_coordinates" class="form-control" value="<?= e($order['gps_coordinates']) ?>">
          </div>
          <div class="form-group">
            <label>Bandwidth / Package</label>
            <input type="text" name="bandwidth" class="form-control" value="<?= e($order['bandwidth'] ?: $order['fttx_package']) ?>">
          </div>
          <div class="form-group">
            <label>Circuit ID</label>
            <input type="text" name="circuit_id" class="form-control" value="<?= e($order['circuit_id']) ?>">
          </div>
          <div class="form-group">
            <label>Billing Start Date</label>
            <input type="date" name="billing_start_date" class="form-control" value="<?= e($order['billing_start_date'] ?? '') ?>">
            <div class="text-muted font-sm" style="margin-top:2px">The effective date from which billing begins.</div>
          </div>
          <div class="form-group">
            <label>Order Status (Active / Inactive)</label>
            <select name="is_active" class="form-control">
              <option value="1" <?= (!isset($order['is_active']) || (int)$order['is_active'] === 1) ? 'selected' : '' ?>>Active (Billing / In-Service)</option>
              <option value="0" <?= (isset($order['is_active']) && (int)$order['is_active'] === 0) ? 'selected' : '' ?>>Inactive (Suspended / Deactivated)</option>
            </select>
            <div class="text-muted font-sm" style="margin-top:2px">Toggle service between Active and Inactive state.</div>
          </div>
        </div>

        <div class="form-group" style="margin-top:12px">
          <label>Special Requirements / Service Notes</label>
          <textarea name="special_requirements" class="form-control" rows="2"><?= e($order['special_requirements']) ?></textarea>
        </div>

        <div class="form-group" style="margin-top:16px;padding:12px 16px;background:var(--surface-2);border-radius:6px;border:1px solid var(--border)">
          <label style="color:var(--text-primary);font-weight:700">Audit Reason for Edit <span class="text-danger">*</span></label>
          <div class="text-muted font-sm" style="margin-bottom:6px">Explain why this closed order is being edited (mandatory for audit compliance).</div>
          <textarea name="audit_reason" class="form-control" rows="3" required placeholder="State operational/business reason for modifying this closed order..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
        <button type="submit" class="btn btn-warning">Save Changes (Audit Logged)</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php // Admin / Management Status Override Modal ?>
<?php if ($isAdminUser || $isMgmt): ?>
<div class="modal-backdrop" id="statusModal">
  <div class="modal">
    <div class="modal-header"><div class="modal-title">Status Override</div><button class="modal-close" data-modal-close>&times;</button></div>
    <form method="POST" action="<?= APP_URL ?>/?page=orders&action=update_status">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
      <div class="modal-body">
        <?php if ($status === 'Closed'): ?>
        <div class="alert alert-warning" style="margin-bottom:14px;font-size:0.85rem">
          <strong>⚠️ Notice:</strong> This order is currently <strong>Closed</strong>. An audit reason is mandatory for any status change.
        </div>
        <?php endif; ?>

        <div class="form-group">
          <label>New Status</label>
          <select name="new_status" class="form-control" required>
            <?php foreach ($allStatuses as $st): ?>
            <option value="<?= e($st) ?>" <?= $status === $st ? 'selected' : '' ?>><?= e($st) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group" style="margin-top:12px">
          <label>Service Type Override (Optional)</label>
          <select name="new_service_type" class="form-control">
            <option value="">— Keep Current (<?= e($order['service_type']) ?>) —</option>
            <?php 
              $allModalServiceTypes = function_exists('getActiveServiceTypes') ? getActiveServiceTypes($db) : ['FTTH', 'FTTB', 'DIA', 'Layer 2 ( last mile)', 'BIA (Broadband Internet Access)', 'Remote Hands Only'];
              if (!in_array('DIA', $allModalServiceTypes)) $allModalServiceTypes[] = 'DIA';
              foreach ($allModalServiceTypes as $stOpt):
            ?>
            <option value="<?= e($stOpt) ?>"><?= e($stOpt) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group" style="margin-top:12px">
          <label>Audit Reason / Note <?= $status === 'Closed' ? '<span class="text-danger">*</span>' : '' ?></label>
          <textarea name="note" class="form-control" rows="3" placeholder="Reason for status change..." <?= $status === 'Closed' ? 'required' : '' ?>></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
        <button type="submit" class="btn btn-primary">Save Status Change</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- ============================================================
     ROLE-BASED ACTION PREVIEW MODAL
     (Allows BSA, KAM, Partner, PM, Management to review changes before submitting)
============================================================ -->
<div class="modal-backdrop" id="orderActionPreviewModal" style="display:none;z-index:999999">
  <div class="modal" style="max-width:760px;width:95%;border-radius:var(--radius-lg,12px);box-shadow:var(--shadow-lg);background:var(--surface,#fff);overflow:hidden;border:1px solid var(--border)">
    <div class="modal-header" style="background:var(--accent-pale,#f1f5f9);padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
      <div style="display:flex;align-items:center;gap:12px">
        <div style="width:38px;height:38px;border-radius:10px;background:rgba(15,76,129,0.12);color:var(--accent,#0f4c81);display:flex;align-items:center;justify-content:center;font-size:1.25rem" id="actionPreviewModalIcon">
          🔍
        </div>
        <div>
          <div style="display:flex;align-items:center;gap:8px">
            <h3 class="modal-title" id="actionPreviewModalTitle" style="font-size:1.05rem;font-weight:700;color:var(--text-primary);margin:0">Action Preview &amp; Verification</h3>
            <span class="badge badge-primary" id="actionPreviewModalRoleBadge" style="font-size:0.72rem;padding:2px 8px">Review</span>
          </div>
          <div class="font-sm text-muted" id="actionPreviewModalSubtitle">Order #<?= e($order['order_number']) ?> · <?= e($order['customer_name']) ?> (<?= e($order['service_type']) ?>)</div>
        </div>
      </div>
      <button type="button" class="modal-close" onclick="closeActionPreviewModal()" style="font-size:1.4rem;background:none;border:none;cursor:pointer;color:var(--text-muted)">&times;</button>
    </div>
    
    <div class="modal-body" id="actionPreviewModalBody" style="padding:20px;max-height:68vh;overflow-y:auto">
      <!-- Dynamic role-specific breakdown rendered here -->
    </div>

    <div class="modal-footer" style="padding:14px 20px;border-top:1px solid var(--border);background:var(--surface-2,#f8fafc);display:flex;align-items:center;justify-content:space-between;gap:10px">
      <button type="button" class="btn btn-secondary" onclick="closeActionPreviewModal()">
        ← Back to Edit
      </button>
      <button type="button" class="btn btn-success" id="actionPreviewConfirmBtn" onclick="confirmActionPreviewSubmission()">
        <?= svgIcon('check') ?> <span id="actionPreviewConfirmBtnText">Confirm &amp; Proceed</span>
      </button>
    </div>
  </div>
</div>

<script>
(function() {
  let pendingSubmissionForm = null;

  window.openActionPreviewModal = function(config) {
    const modal = document.getElementById('orderActionPreviewModal');
    if (!modal) return;

    pendingSubmissionForm = config.form || null;

    document.getElementById('actionPreviewModalIcon').innerHTML = config.icon || '🔍';
    document.getElementById('actionPreviewModalTitle').textContent = config.title || 'Action Preview';
    document.getElementById('actionPreviewModalRoleBadge').textContent = config.role || 'Review';
    if (config.subtitle) {
      document.getElementById('actionPreviewModalSubtitle').textContent = config.subtitle;
    }
    document.getElementById('actionPreviewConfirmBtnText').textContent = config.confirmText || 'Confirm & Proceed';
    document.getElementById('actionPreviewModalBody').innerHTML = config.html || '';

    modal.classList.add('open');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  };

  window.closeActionPreviewModal = function() {
    const modal = document.getElementById('orderActionPreviewModal');
    if (modal) {
      modal.classList.remove('open');
      modal.style.display = 'none';
      document.body.style.overflow = '';
    }
    pendingSubmissionForm = null;
  };

  window.confirmActionPreviewSubmission = function() {
    if (pendingSubmissionForm) {
      const form = pendingSubmissionForm;
      form.dataset.previewConfirmed = '1';
      closeActionPreviewModal();
      form.submit();
    } else {
      closeActionPreviewModal();
    }
  };

  // 1. BSA Feasibility Preview
  window.previewBsaSubmission = function() {
    const form = document.getElementById('bsaFeasibilityForm');
    if (!form) return;

    const remarks = document.getElementById('bsa_technical_remarks')?.value.trim();
    if (!remarks) {
      neilosAlert('Please enter technical remarks describing infrastructure requirements.', 'Remarks Required', '⚠️');
      document.getElementById('bsa_technical_remarks')?.focus();
      return;
    }

    const revisedNrc = form.querySelector('input[name="revised_nrc"]')?.value.trim();
    const justification = form.querySelector('input[name="nrc_justification"]')?.value.trim();
    const rawJson = document.getElementById('nrcBreakdownJson')?.value;
    let bomList = [];
    try {
      if (rawJson) bomList = JSON.parse(rawJson);
    } catch(e) {}

    let bomRowsHtml = '';
    let bomTotal = 0;
    if (Array.isArray(bomList) && bomList.length > 0) {
      bomList.forEach(item => {
        const cat = item.category || 'Device';
        const isDev = (cat === 'Device');
        const isMat = (cat === 'Material');
        const badgeCls = isDev ? 'badge-primary' : (isMat ? 'badge-info' : 'badge-secondary');
        const badgeStyle = isMat ? 'style="background:#0284c7;color:#fff"' : '';
        const qty = item.qty || 1;
        const price = parseFloat(item.unit_price) || 0;
        const lineTot = parseFloat(item.total) || (qty * price);
        bomTotal += lineTot;

        const devDetails = isDev ? [item.brand, item.model, item.serial ? `SN: ${item.serial}` : ''].filter(Boolean).join(' · ') : '';

        bomRowsHtml += `
          <tr style="border-bottom:1px solid var(--border)">
            <td style="padding:6px 8px">
              <span class="badge ${badgeCls}" ${badgeStyle} style="font-size:0.68rem;padding:2px 6px">${cat}</span>
              <strong style="margin-left:4px">${escapeHtml(item.description || 'Item')}</strong>
              ${devDetails ? `<div class="font-sm text-muted" style="font-size:0.75rem">${escapeHtml(devDetails)}</div>` : ''}
            </td>
            <td style="padding:6px 8px;text-align:center">${qty}</td>
            <td style="padding:6px 8px;text-align:right">$${price.toFixed(2)}</td>
            <td style="padding:6px 8px;text-align:right;font-weight:600">$${lineTot.toFixed(2)}</td>
          </tr>
        `;
      });
    }

    const html = `
      <div style="display:flex;flex-direction:column;gap:16px">
        <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:8px;padding:14px 16px">
          <div style="font-weight:700;font-size:0.9rem;margin-bottom:8px;color:var(--text-primary)">
            📐 Feasibility Summary &amp; Proposed NRC
          </div>
          <div style="display:flex;justify-content:space-between;margin-bottom:6px">
            <span style="color:var(--text-secondary)">Standard Service NRC:</span>
            <span style="font-weight:600">$<?= number_format((float)($order['standard_nrc'] ?? $order['base_nrc_usd']), 2) ?></span>
          </div>
          <div style="display:flex;justify-content:space-between">
            <span style="color:var(--text-secondary)">BSA Confirmed / Revised NRC:</span>
            <span style="font-weight:700;color:var(--accent);font-size:1.05rem">$${revisedNrc ? revisedNrc : '<?= number_format((float)($order['standard_nrc'] ?? $order['base_nrc_usd']), 2) ?>'}</span>
          </div>
          ${justification ? `<div style="margin-top:8px;font-size:0.83rem;color:var(--text-muted)"><strong>Justification:</strong> ${escapeHtml(justification)}</div>` : ''}
        </div>

        ${bomRowsHtml ? `
        <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:8px;padding:12px 14px">
          <div style="font-weight:700;font-size:0.85rem;margin-bottom:6px;display:flex;justify-content:space-between">
            <span>Bill of Materials (BoM) Items</span>
            <span class="badge badge-primary">${bomList.length} Items</span>
          </div>
          <table style="width:100%;font-size:0.82rem;border-collapse:collapse">
            <thead>
              <tr style="background:var(--surface-1);color:var(--text-muted);border-bottom:1px solid var(--border);text-align:left">
                <th style="padding:6px 8px">Item / Material / Service</th>
                <th style="padding:6px 8px;text-align:center;width:45px">Qty</th>
                <th style="padding:6px 8px;text-align:right">Unit Price</th>
                <th style="padding:6px 8px;text-align:right">Total</th>
              </tr>
            </thead>
            <tbody>${bomRowsHtml}</tbody>
          </table>
        </div>` : ''}

        <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:8px;padding:12px 16px">
          <div style="font-weight:700;font-size:0.85rem;color:#334155;margin-bottom:4px">Technical Remarks &amp; Special Conditions:</div>
          <div style="font-size:0.875rem;color:#0f172a;white-space:pre-wrap">${escapeHtml(remarks)}</div>
        </div>

        <div class="alert alert-info" style="margin:0;font-size:0.83rem">
          ℹ️ Submitting will mark this order as <strong>Technically Feasible</strong> and route it to the <strong>Account Manager (KAM)</strong> for commercial review.
        </div>
      </div>
    `;

    openActionPreviewModal({
      form: form,
      title: 'BSA Feasibility Review — Final Verification',
      role: 'BSA Architect',
      icon: '📐',
      confirmText: 'Mark Feasible & Proceed to KAM',
      html: html
    });
  };

  // 2. KAM Commercial Review Preview
  window.previewKamSubmission = function() {
    const form = document.getElementById('kamApproveForm');
    if (!form) return;

    const usdTzsRate  = document.getElementById('usd_tzs_rate_input')?.value.trim() || '2600.00';
    const proposedMrc = document.getElementById('kam_proposed_mrc_input')?.value.trim();
    const proposedNrc = document.getElementById('kam_proposed_nrc_input')?.value.trim();
    const justification = document.getElementById('kam_commercial_justification_input')?.value.trim();
    const remarks = document.getElementById('kam_remarks_input')?.value.trim();

    const isException = (proposedMrc !== '' || proposedNrc !== '');
    if (isException && !justification) {
      neilosAlert('Commercial justification is mandatory when proposing exception pricing.', 'Justification Required', '⚠️');
      document.getElementById('kam_commercial_justification_input')?.focus();
      return;
    }

    const html = `
      <div style="display:flex;flex-direction:column;gap:16px">
        <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:8px;padding:14px 16px">
          <div style="font-weight:700;font-size:0.9rem;margin-bottom:10px;color:var(--text-primary)">
            💼 Commercial Pricing Summary
          </div>
          <table style="width:100%;font-size:0.875rem;border-collapse:collapse">
            <tr style="border-bottom:1px solid var(--border)">
              <td style="padding:6px 0;color:var(--text-secondary)">Exchange Rate (TZS/USD)</td>
              <td style="padding:6px 0;text-align:right;font-weight:700;color:var(--primary)">TZS ${escapeHtml(usdTzsRate)} / USD</td>
            </tr>
            <tr style="border-bottom:1px solid var(--border)">
              <td style="padding:6px 0;color:var(--text-secondary)">Standard MRC (Price Book)</td>
              <td style="padding:6px 0;text-align:right;font-weight:600">$<?= number_format((float)($order['standard_mrc'] ?? $order['base_mrc']), 2) ?></td>
            </tr>
            <tr style="border-bottom:1px solid var(--border)">
              <td style="padding:6px 0;color:var(--text-secondary)">KAM Proposed MRC</td>
              <td style="padding:6px 0;text-align:right;font-weight:700;color:${proposedMrc ? 'var(--accent)' : 'inherit'}">${proposedMrc ? '$' + proposedMrc : 'Standard Rate'}</td>
            </tr>
            <tr style="border-bottom:1px solid var(--border)">
              <td style="padding:6px 0;color:var(--text-secondary)">BSA Confirmed NRC</td>
              <td style="padding:6px 0;text-align:right;font-weight:600">$<?= number_format((float)($order['revised_nrc'] ?? $order['standard_nrc'] ?? $order['base_nrc_usd']), 2) ?></td>
            </tr>
            <tr>
              <td style="padding:6px 0;color:var(--text-secondary)">KAM Proposed NRC Exception</td>
              <td style="padding:6px 0;text-align:right;font-weight:700;color:${proposedNrc ? 'var(--accent)' : 'inherit'}">${proposedNrc ? '$' + proposedNrc : 'Standard / BSA Confirmed'}</td>
            </tr>
          </table>
        </div>

        ${justification ? `
        <div style="background:#fffbeb;border:1px solid #fef3c7;border-radius:8px;padding:12px 16px">
          <div style="font-weight:700;font-size:0.85rem;color:#92400e;margin-bottom:4px">Commercial Justification:</div>
          <div style="font-size:0.875rem;color:#78350f">${escapeHtml(justification)}</div>
        </div>` : ''}

        ${remarks ? `
        <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:8px;padding:12px 16px">
          <div style="font-weight:700;font-size:0.85rem;color:var(--text-primary);margin-bottom:4px">KAM Remarks:</div>
          <div style="font-size:0.875rem;color:var(--text-secondary)">${escapeHtml(remarks)}</div>
        </div>` : ''}

        <div class="alert ${isException ? 'alert-warning' : 'alert-success'}" style="margin:0;font-size:0.83rem">
          ${isException ? '⚠️ Discount / exception proposed: This order will be routed to <strong>Management Approval</strong>.' : '✅ Standard terms confirmed: Order will move directly to <strong>Pending SOF</strong> for Partner generation and signing.'}
        </div>
      </div>
    `;

    openActionPreviewModal({
      form: form,
      title: 'KAM Commercial Decision — Final Verification',
      role: 'Account Manager (KAM)',
      icon: '💼',
      confirmText: 'Submit Commercial Decision',
      html: html
    });
  };

  // 3. Management Decision Preview
  window.previewMgmtSubmission = function() {
    const form = document.getElementById('mgmtDecisionForm');
    if (!form) return;

    const decision = form.querySelector('input[name="management_decision"]:checked')?.value;
    if (!decision) {
      neilosAlert('Please select a management decision option.', 'Decision Required', '⚠️');
      return;
    }

    const returnRemarks = document.getElementById('mgmt_return_remarks_input')?.value.trim();
    if (decision === 'Return to KAM' && !returnRemarks) {
      neilosAlert('Return remarks are mandatory when returning an order to KAM.', 'Remarks Required', '⚠️');
      document.getElementById('mgmt_return_remarks_input')?.focus();
      return;
    }

    const finalNrc = document.getElementById('mgmt_final_nrc_input')?.value.trim();
    const finalMrc = document.getElementById('mgmt_final_mrc_input')?.value.trim();
    const notes = document.getElementById('mgmt_decision_notes_input')?.value.trim();

    const html = `
      <div style="display:flex;flex-direction:column;gap:16px">
        <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:8px;padding:14px 16px">
          <div style="font-weight:700;font-size:0.9rem;margin-bottom:10px;color:var(--text-primary)">
            🏛️ Management Determination
          </div>
          <div style="font-size:1.05rem;font-weight:800;color:var(--primary);margin-bottom:8px">
            ${escapeHtml(decision)}
          </div>
          ${decision === 'Approve with Revised Price' ? `
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px;padding-top:10px;border-top:1px solid var(--border)">
            <div><strong>Final Approved NRC:</strong> <span style="font-weight:700;color:#166534">$${finalNrc || '0.00'}</span></div>
            <div><strong>Final Approved MRC:</strong> <span style="font-weight:700;color:#166534">$${finalMrc || '0.00'}</span></div>
          </div>` : ''}
        </div>

        ${decision === 'Return to KAM' && returnRemarks ? `
        <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:12px 16px">
          <div style="font-weight:700;font-size:0.85rem;color:#991b1b;margin-bottom:4px">Return Remarks for KAM:</div>
          <div style="font-size:0.875rem;color:#7f1d1d">${escapeHtml(returnRemarks)}</div>
        </div>` : ''}

        ${notes ? `
        <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:8px;padding:12px 16px">
          <div style="font-weight:700;font-size:0.85rem;color:var(--text-primary);margin-bottom:4px">Audit Notes:</div>
          <div style="font-size:0.875rem;color:var(--text-secondary)">${escapeHtml(notes)}</div>
        </div>` : ''}

        <div class="alert alert-info" style="margin:0;font-size:0.83rem">
          ℹ️ Your authoritative determination will be logged in the price audit trail and stakeholders will be notified.
        </div>
      </div>
    `;

    openActionPreviewModal({
      form: form,
      title: 'Management Determination — Final Verification',
      role: 'Management Review',
      icon: '🏛️',
      confirmText: 'Confirm Management Decision',
      html: html
    });
  };

  // Intercept all forms marked with .order-action-form
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('form.order-action-form').forEach(form => {
      form.addEventListener('submit', function(e) {
        // If already confirmed inside preview modal, skip intercept
        if (form.dataset.previewConfirmed === '1') {
          return true;
        }

        e.preventDefault();
        const actionTitle = form.dataset.actionTitle || 'Confirm Order Action';
        const actionRole = form.dataset.actionRole || 'Order Workflow';

        // Check for file inputs
        const fileInputs = form.querySelectorAll('input[type="file"]');
        let fileDetailsHtml = '';
        fileInputs.forEach(fi => {
          if (fi.files && fi.files.length > 0) {
            fileDetailsHtml += '<div style="margin-top:8px;font-size:0.85rem"><strong>Selected File(s):</strong><ul style="margin:4px 0 0 16px">';
            for (let i = 0; i < fi.files.length; i++) {
              const file = fi.files[i];
              fileDetailsHtml += `<li><code>${escapeHtml(file.name)}</code> (${(file.size / 1024).toFixed(1)} KB)</li>`;
            }
            fileDetailsHtml += '</ul></div>';
          }
        });

        // Check for text inputs or textareas
        const textInputs = form.querySelectorAll('input[type="text"], textarea, select');
        let fieldListHtml = '';
        textInputs.forEach(inp => {
          if (inp.name && !inp.name.includes('csrf_token') && !inp.name.includes('order_id') && inp.value) {
            const label = inp.closest('.form-group')?.querySelector('label')?.textContent.replace('*', '').trim() || inp.name;
            fieldListHtml += `
              <div style="margin-bottom:8px">
                <span style="color:var(--text-secondary);font-size:0.82rem">${escapeHtml(label)}:</span>
                <div style="font-weight:600;font-size:0.88rem;color:var(--text-primary)">${escapeHtml(inp.value)}</div>
              </div>
            `;
          }
        });

        const html = `
          <div style="display:flex;flex-direction:column;gap:14px">
            <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:8px;padding:14px 16px">
              <div style="font-weight:700;font-size:0.9rem;margin-bottom:10px;color:var(--text-primary)">
                📝 Submission Details
              </div>
              ${fieldListHtml || '<div style="font-size:0.85rem;color:var(--text-secondary)">No text parameters to review.</div>'}
              ${fileDetailsHtml}
            </div>
            <div class="alert alert-info" style="margin:0;font-size:0.83rem">
              ℹ️ Please verify that all information entered is accurate before proceeding.
            </div>
          </div>
        `;

        openActionPreviewModal({
          form: form,
          title: actionTitle,
          role: actionRole,
          icon: '📝',
          confirmText: 'Confirm & Submit',
          html: html
        });
      });
    });
  });

  function escapeHtml(text) {
    if (!text) return '';
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
})();
</script>