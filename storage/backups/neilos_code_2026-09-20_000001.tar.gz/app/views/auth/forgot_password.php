<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Forgot Password — Neilos Partner Portal</title>
  <meta name="description" content="Reset your Neilos Partner Portal account password">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Sora:wght@600;700;800&display=swap">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/portal.css?v=<?= time() ?>">
  <link rel="icon" type="image/png" href="<?= APP_URL ?>/favicon.ico?v=2">
  <script>document.documentElement.setAttribute('data-theme','light');</script>
</head>
<body>
<div class="login-page">
  <div class="login-card">
    <div class="login-logo">
      <img src="<?= APP_URL ?>/assets/img/logo.png?v=4" alt="Neilos" class="login-logo-img">
      <div class="login-subtitle">Reset Account Password</div>
    </div>

    <?php $flash = getFlash(); if ($flash): ?>
    <div class="alert alert-<?= e($flash['type']) ?>">
      <span><?= e($flash['message']) ?></span>
    </div>
    <?php endif; ?>

    <?php if (!empty($forgotError)): ?>
    <div class="alert alert-danger">
      <span><?= e($forgotError) ?></span>
    </div>
    <?php endif; ?>

    <p style="font-size:0.88rem;color:var(--text-secondary);margin-bottom:20px;line-height:1.5">
      Enter your registered email address below. We'll send you a secure link to reset your password.
    </p>

    <form class="login-form" method="POST" action="<?= APP_URL ?>/?page=forgot_password">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

      <div class="form-group">
        <label for="email">Email Address <span class="required">*</span></label>
        <input type="email" id="email" name="email" class="form-control" required
               value="<?= e($_POST['email'] ?? '') ?>" placeholder="name@company.com"
               autocomplete="email" autofocus>
      </div>

      <button type="submit" class="btn btn-primary w-100 btn-lg" style="margin-top:10px">
        Send Password Reset Link
      </button>
    </form>

    <div style="text-align:center;margin-top:24px;font-size:0.86rem">
      <a href="<?= APP_URL ?>/?page=login" style="color:var(--primary);text-decoration:none;font-weight:600">
        &larr; Back to Sign In
      </a>
    </div>
  </div>
</div>
</body>
</html>
