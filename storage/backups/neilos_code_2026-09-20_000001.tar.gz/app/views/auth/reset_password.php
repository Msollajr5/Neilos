<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Set New Password — Neilos Partner Portal</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Sora:wght@600;700;800&display=swap">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/portal.css?v=<?= time() ?>">
  <link rel="icon" type="image/png" href="<?= APP_URL ?>/favicon.ico?v=2">
  <script>document.documentElement.setAttribute('data-theme','light');</script>
</head>
<body>
<div class="login-page">
  <div class="login-card">
    <div class="login-logo">
      <img src="<?= APP_URL ?>/assets/img/logo.png?v=4" alt="Neilos" class="login-logo-img">
      <div class="login-subtitle">Set New Password</div>
    </div>

    <?php if (!empty($resetErrors)): ?>
    <div class="alert alert-danger" style="margin-bottom:18px">
      <ul style="margin:0;padding-left:18px">
        <?php foreach ($resetErrors as $err): ?>
          <li><?= e($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
    <?php endif; ?>

    <?php if (!empty($tokenValid)): ?>
    <form class="login-form" method="POST" action="<?= APP_URL ?>/?page=reset_password&token=<?= e($token) ?>">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

      <div class="form-group">
        <label for="new_password">New Password <span class="required">*</span></label>
        <input type="password" id="new_password" name="new_password" class="form-control" required
               placeholder="At least 8 chars (upper, lower, digit, special)" autocomplete="new-password">
      </div>

      <div class="form-group">
        <label for="confirm_password">Confirm New Password <span class="required">*</span></label>
        <input type="password" id="confirm_password" name="confirm_password" class="form-control" required
               placeholder="Re-type new password" autocomplete="new-password">
      </div>

      <div style="background:var(--surface-2);padding:10px 14px;border-radius:var(--radius-sm);font-size:0.78rem;color:var(--text-secondary);margin-bottom:18px;line-height:1.4">
        <strong>Password Requirements:</strong><br>
        &bull; Minimum 8 characters<br>
        &bull; At least one uppercase letter (A–Z)<br>
        &bull; At least one lowercase letter (a–z)<br>
        &bull; At least one digit (0–9)<br>
        &bull; At least one special character (!@#$%^&amp;* etc.)
      </div>

      <button type="submit" class="btn btn-primary w-100 btn-lg">
        Update Password &amp; Sign In
      </button>
    </form>
    <?php else: ?>
    <div class="alert alert-danger">
      <span><?= e($invalidTokenMessage ?? 'This password reset link is invalid or has expired.') ?></span>
    </div>
    <div style="text-align:center;margin-top:20px">
      <a href="<?= APP_URL ?>/?page=forgot_password" class="btn btn-primary">
        Request New Reset Link
      </a>
    </div>
    <?php endif; ?>

    <div style="text-align:center;margin-top:24px;font-size:0.86rem">
      <a href="<?= APP_URL ?>/?page=login" style="color:var(--primary);text-decoration:none;font-weight:600">
        &larr; Back to Sign In
      </a>
    </div>
  </div>
</div>
</body>
</html>
