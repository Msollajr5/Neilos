-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: neilos_portal
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `active_services`
--

DROP TABLE IF EXISTS `active_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `active_services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_id` varchar(100) NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `partner_id` int(10) unsigned NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `circuit_id` varchar(100) DEFAULT NULL,
  `bandwidth_capacity` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `building_name` varchar(200) DEFAULT NULL,
  `kam_id` int(10) unsigned DEFAULT NULL,
  `activation_date` date DEFAULT NULL,
  `billing_start_date` date DEFAULT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Active',
  `monitoring_status` varchar(100) DEFAULT 'Unknown',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_id` (`service_id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_partner` (`partner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `active_services`
--

LOCK TABLES `active_services` WRITE;
/*!40000 ALTER TABLE `active_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `active_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `module` varchar(100) NOT NULL DEFAULT '',
  `record_id` int(10) unsigned DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_module` (`module`),
  KEY `idx_record` (`record_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (2,1,'Auto-created partner record \'SEACOM TANZANIA LIMITED\' for Partner user','partners',1,NULL,NULL,'192.168.221.24','2026-09-17 15:38:01'),(3,1,'Created user SEACOM TANZANIA LIMITED (seacom)','users',52,NULL,NULL,'192.168.221.24','2026-09-17 15:38:01'),(4,52,'Login','users',52,NULL,NULL,'192.168.221.98','2026-09-17 15:48:06'),(5,52,'Password changed (90-day policy rotation)','users',52,NULL,NULL,'192.168.221.98','2026-09-17 15:48:30'),(6,1,'Deleted user John KAM (Commercials) (kam_john)','users',2,NULL,NULL,'192.168.221.24','2026-09-17 15:54:34'),(7,1,'Deleted user Sarah BSA (Engineering) (bsa_sarah)','users',3,NULL,NULL,'192.168.221.24','2026-09-17 15:54:41'),(8,1,'Deleted user Project Manager (Operations) (pm)','users',11,NULL,NULL,'192.168.221.24','2026-09-17 15:54:55'),(9,1,'Auto-created partner record \'SPRINT TANZANIA LIMITED\' for Partner user','partners',2,NULL,NULL,'192.168.221.24','2026-09-17 15:57:04'),(10,1,'Created user SPRINT TANZANIA LIMITED (sprint)','users',53,NULL,NULL,'192.168.221.24','2026-09-17 15:57:04');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractor_assignments`
--

DROP TABLE IF EXISTS `contractor_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractor_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `contractor_partner_id` int(10) unsigned NOT NULL COMMENT 'partners.id where kyc_type=Contractor',
  `contractor_user_id` int(10) unsigned DEFAULT NULL COMMENT 'Specific contractor user assigned',
  `contractor_team_id` int(11) DEFAULT NULL,
  `contractor_team_name` varchar(150) DEFAULT NULL,
  `assigned_by` int(10) unsigned NOT NULL COMMENT 'Project Manager user id',
  `assigned_at` datetime DEFAULT current_timestamp(),
  `target_date` date DEFAULT NULL,
  `work_order_notes` text DEFAULT NULL,
  `pickup_location` varchar(255) DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Assigned',
  `accepted_by` int(10) unsigned DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `completion_remarks` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contractor_user_id` (`contractor_user_id`),
  KEY `assigned_by` (`assigned_by`),
  KEY `accepted_by` (`accepted_by`),
  KEY `idx_order` (`order_id`),
  KEY `idx_contractor` (`contractor_partner_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `contractor_assignments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contractor_assignments_ibfk_2` FOREIGN KEY (`contractor_partner_id`) REFERENCES `partners` (`id`),
  CONSTRAINT `contractor_assignments_ibfk_3` FOREIGN KEY (`contractor_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `contractor_assignments_ibfk_4` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`),
  CONSTRAINT `contractor_assignments_ibfk_5` FOREIGN KEY (`accepted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractor_assignments`
--

LOCK TABLES `contractor_assignments` WRITE;
/*!40000 ALTER TABLE `contractor_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `contractor_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractor_evidence`
--

DROP TABLE IF EXISTS `contractor_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractor_evidence` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `evidence_type` varchar(100) NOT NULL,
  `serial_number` varchar(200) DEFAULT NULL COMMENT 'For ONT/ONU serial number',
  `pickup_location` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `cost_amount` decimal(14,2) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `uploaded_by` int(10) unsigned NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  `is_mandatory` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_order` (`order_id`),
  CONSTRAINT `contractor_evidence_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `contractor_assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contractor_evidence_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contractor_evidence_ibfk_3` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractor_evidence`
--

LOCK TABLES `contractor_evidence` WRITE;
/*!40000 ALTER TABLE `contractor_evidence` DISABLE KEYS */;
/*!40000 ALTER TABLE `contractor_evidence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractor_progress_updates`
--

DROP TABLE IF EXISTS `contractor_progress_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractor_progress_updates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `updated_by` int(10) unsigned NOT NULL,
  `progress_status` varchar(100) NOT NULL DEFAULT 'In Progress',
  `is_blocker` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'If 1, this update is a blocker — SLA pauses',
  `is_resumed` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'If 1, installation resumed — SLA resumes',
  `delay_reason` enum('Customer Unavailable','Access Denied','Weather','Missing Materials','Technical Issue','Other') DEFAULT NULL,
  `notes` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_order` (`order_id`),
  CONSTRAINT `contractor_progress_updates_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `contractor_assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contractor_progress_updates_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contractor_progress_updates_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractor_progress_updates`
--

LOCK TABLES `contractor_progress_updates` WRITE;
/*!40000 ALTER TABLE `contractor_progress_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `contractor_progress_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractor_teams`
--

DROP TABLE IF EXISTS `contractor_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractor_teams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contractor_partner_id` int(10) unsigned NOT NULL,
  `team_name` varchar(200) NOT NULL,
  `team_leader_id` int(10) unsigned DEFAULT NULL,
  `leader_name` varchar(200) DEFAULT NULL,
  `leader_phone` varchar(50) DEFAULT NULL,
  `coverage_region` varchar(150) DEFAULT NULL,
  `status` enum('Pending','Approved','Inactive') NOT NULL DEFAULT 'Pending',
  `created_by` int(10) unsigned DEFAULT NULL,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_partner` (`contractor_partner_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractor_teams`
--

LOCK TABLES `contractor_teams` WRITE;
/*!40000 ALTER TABLE `contractor_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `contractor_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractor_technicians`
--

DROP TABLE IF EXISTS `contractor_technicians`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractor_technicians` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contractor_partner_id` int(10) unsigned NOT NULL,
  `team_id` int(10) unsigned DEFAULT NULL,
  `full_name` varchar(200) NOT NULL,
  `nida_number` varchar(50) NOT NULL,
  `gender` enum('Male','Female') NOT NULL DEFAULT 'Male',
  `phone` varchar(50) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `photo_path` varchar(500) DEFAULT NULL,
  `nida_photo_path` varchar(500) DEFAULT NULL,
  `skill_level` varchar(100) DEFAULT 'Technician',
  `status` enum('Pending','Approved','Inactive','Rejected') NOT NULL DEFAULT 'Pending',
  `rejection_reason` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_partner` (`contractor_partner_id`),
  KEY `idx_team` (`team_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractor_technicians`
--

LOCK TABLES `contractor_technicians` WRITE;
/*!40000 ALTER TABLE `contractor_technicians` DISABLE KEYS */;
/*!40000 ALTER TABLE `contractor_technicians` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evidence_checklist_config`
--

DROP TABLE IF EXISTS `evidence_checklist_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evidence_checklist_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_type` varchar(100) NOT NULL,
  `evidence_type` varchar(100) NOT NULL,
  `is_mandatory` tinyint(1) DEFAULT 1,
  `is_noc_conditional` tinyint(1) DEFAULT 0 COMMENT 'If 1, only required when noc_ip_configured=1',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_service_evidence` (`service_type`,`evidence_type`)
) ENGINE=InnoDB AUTO_INCREMENT=7221239 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evidence_checklist_config`
--

LOCK TABLES `evidence_checklist_config` WRITE;
/*!40000 ALTER TABLE `evidence_checklist_config` DISABLE KEYS */;
INSERT INTO `evidence_checklist_config` VALUES (1,'FTTH','Site Photo',1,0,'2026-09-15 16:01:31'),(2,'FTTH','Signal Test',1,0,'2026-09-15 16:01:31'),(3,'FTTH','Serial Number',1,0,'2026-09-15 16:01:31'),(4,'FTTH','Speed Test',1,0,'2026-09-15 16:01:31'),(5,'FTTH','Ping Test',1,0,'2026-09-15 16:01:31'),(6,'FTTH','UAT',1,0,'2026-09-15 16:01:31'),(7,'FTTB','Site Photo',1,0,'2026-09-15 16:01:31'),(8,'FTTB','Signal Test',1,0,'2026-09-15 16:01:31'),(9,'FTTB','Serial Number',1,0,'2026-09-15 16:01:31'),(10,'FTTB','Speed Test',1,0,'2026-09-15 16:01:31'),(11,'FTTB','Ping Test',1,0,'2026-09-15 16:01:31'),(12,'FTTB','UAT',1,0,'2026-09-15 16:01:31'),(13,'FTTE','Site Photo',1,0,'2026-09-15 16:01:31'),(14,'FTTE','Signal Test',1,0,'2026-09-15 16:01:31'),(15,'FTTE','Serial Number',1,0,'2026-09-15 16:01:31'),(16,'FTTE','Speed Test',1,0,'2026-09-15 16:01:31'),(17,'FTTE','Ping Test',1,0,'2026-09-15 16:01:31'),(18,'FTTE','UAT',1,0,'2026-09-15 16:01:31'),(19,'DIA','Site Photo',1,0,'2026-09-15 16:01:31'),(20,'DIA','Signal Test',1,0,'2026-09-15 16:01:31'),(21,'DIA','Serial Number',1,0,'2026-09-15 16:01:31'),(22,'DIA','Speed Test',1,0,'2026-09-15 16:01:31'),(23,'DIA','Ping Test',1,0,'2026-09-15 16:01:31'),(24,'DIA','UAT',1,0,'2026-09-15 16:01:31'),(25,'BIA (Broadband Internet Access)','Site Photo',1,0,'2026-09-15 16:01:31'),(26,'BIA (Broadband Internet Access)','Signal Test',1,0,'2026-09-15 16:01:31'),(27,'BIA (Broadband Internet Access)','Serial Number',1,0,'2026-09-15 16:01:31'),(28,'BIA (Broadband Internet Access)','Speed Test',1,0,'2026-09-15 16:01:31'),(29,'BIA (Broadband Internet Access)','Ping Test',1,0,'2026-09-15 16:01:31'),(30,'BIA (Broadband Internet Access)','UAT',1,0,'2026-09-15 16:01:31'),(31,'Dedicated Layer 2','Site Photo',1,0,'2026-09-15 16:01:31'),(32,'Dedicated Layer 2','Signal Test',1,0,'2026-09-15 16:01:31'),(33,'Dedicated Layer 2','Serial Number',1,0,'2026-09-15 16:01:31'),(34,'Dedicated Layer 2','Speed Test',1,0,'2026-09-15 16:01:31'),(35,'Dedicated Layer 2','Ping Test',1,0,'2026-09-15 16:01:31'),(36,'Dedicated Layer 2','UAT',1,0,'2026-09-15 16:01:31'),(37,'Layer 2 ( last mile)','Site Photo',1,0,'2026-09-15 16:01:31'),(38,'Layer 2 ( last mile)','Signal Test',1,0,'2026-09-15 16:01:31'),(39,'Layer 2 ( last mile)','Serial Number',1,0,'2026-09-15 16:01:31'),(40,'Layer 2 ( last mile)','Speed Test',1,0,'2026-09-15 16:01:31'),(41,'Layer 2 ( last mile)','Ping Test',1,0,'2026-09-15 16:01:31'),(42,'Layer 2 ( last mile)','UAT',1,0,'2026-09-15 16:01:31'),(43,'Remote Hands Only','Site Photo',1,0,'2026-09-15 16:01:31'),(44,'Remote Hands Only','Signal Test',1,0,'2026-09-15 16:01:31'),(45,'Remote Hands Only','Serial Number',1,0,'2026-09-15 16:01:31'),(46,'Remote Hands Only','Speed Test',1,0,'2026-09-15 16:01:31'),(47,'Remote Hands Only','Ping Test',1,0,'2026-09-15 16:01:31'),(48,'Remote Hands Only','UAT',1,0,'2026-09-15 16:01:31'),(49,'Other','Site Photo',1,0,'2026-09-15 16:01:31'),(50,'Other','Signal Test',1,0,'2026-09-15 16:01:31'),(51,'Other','Serial Number',1,0,'2026-09-15 16:01:31'),(52,'Other','Speed Test',1,0,'2026-09-15 16:01:31'),(53,'Other','Ping Test',1,0,'2026-09-15 16:01:31'),(54,'Other','UAT',1,0,'2026-09-15 16:01:31'),(71,'BIA','Site Photo',1,0,'2026-09-15 16:01:32'),(73,'BIA','Signal Test',1,0,'2026-09-15 16:01:32'),(74,'BIA','Speed Test',1,0,'2026-09-15 16:01:32'),(5543,'BIA','Serial Number',1,0,'2026-09-15 16:02:13'),(5544,'BIA','Ping Test',1,0,'2026-09-15 16:02:13'),(5545,'BIA','UAT',1,0,'2026-09-15 16:02:13');
/*!40000 ALTER TABLE `evidence_checklist_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftth_bulk_uploads`
--

DROP TABLE IF EXISTS `ftth_bulk_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftth_bulk_uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uploaded_by` int(10) unsigned NOT NULL,
  `original_file` varchar(255) NOT NULL,
  `total_rows` int(11) NOT NULL DEFAULT 0,
  `success_rows` int(11) NOT NULL DEFAULT 0,
  `error_rows` int(11) NOT NULL DEFAULT 0,
  `errors_json` longtext DEFAULT NULL,
  `created_orders` longtext DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `idx_uploaded_at` (`uploaded_at`),
  CONSTRAINT `ftth_bulk_uploads_ibfk_1` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftth_bulk_uploads`
--

LOCK TABLES `ftth_bulk_uploads` WRITE;
/*!40000 ALTER TABLE `ftth_bulk_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `ftth_bulk_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `partner_id` int(10) unsigned NOT NULL,
  `invoice_type` enum('NRC','MRC','NRC_MRC','Usage') NOT NULL DEFAULT 'NRC_MRC',
  `amount_usd` decimal(12,2) NOT NULL,
  `vat_usd` decimal(12,2) NOT NULL,
  `total_usd` decimal(12,2) NOT NULL,
  `amount_tzs` decimal(14,2) NOT NULL,
  `vat_tzs` decimal(14,2) NOT NULL,
  `total_tzs` decimal(14,2) NOT NULL,
  `exchange_rate` decimal(10,4) NOT NULL DEFAULT 2550.0000,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `due_date` date NOT NULL,
  `status` enum('Draft','Issued','Paid','Partially Paid','Overdue','Cancelled') NOT NULL DEFAULT 'Draft',
  `pdf_path` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `order_id` (`order_id`),
  KEY `partner_id` (`partner_id`),
  KEY `idx_invoice_number` (`invoice_number`),
  KEY `idx_status` (`status`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kyc_documents`
--

DROP TABLE IF EXISTS `kyc_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kyc_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `application_id` int(10) unsigned NOT NULL,
  `doc_type` enum('certificate_of_incorporation','tin_certificate','vrn_certificate','business_license','tax_clearance','bank_proof','id_copy','other') NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `application_id` (`application_id`),
  CONSTRAINT `kyc_documents_ibfk_1` FOREIGN KEY (`application_id`) REFERENCES `partner_kyc_applications` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kyc_documents`
--

LOCK TABLES `kyc_documents` WRITE;
/*!40000 ALTER TABLE `kyc_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `kyc_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kyc_history`
--

DROP TABLE IF EXISTS `kyc_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kyc_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kyc_id` int(10) unsigned NOT NULL,
  `action_by` int(10) unsigned DEFAULT NULL,
  `action_role` varchar(50) NOT NULL,
  `from_status` varchar(50) DEFAULT NULL,
  `to_status` varchar(50) NOT NULL,
  `action_title` varchar(200) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_kyc` (`kyc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kyc_history`
--

LOCK TABLES `kyc_history` WRITE;
/*!40000 ALTER TABLE `kyc_history` DISABLE KEYS */;
INSERT INTO `kyc_history` VALUES (1,1,1,'System Admin',NULL,'Draft','KYC Created by System Admin',NULL,'2026-09-17 15:52:48'),(2,1,1,'System Admin','Draft','Submitted for Approval','KYC Submitted for Approval',NULL,'2026-09-17 15:52:48');
/*!40000 ALTER TABLE `kyc_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neilos_company_info`
--

DROP TABLE IF EXISTS `neilos_company_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neilos_company_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) NOT NULL DEFAULT 'Neilos Network Ltd',
  `trading_name` varchar(200) DEFAULT NULL,
  `registration_number` varchar(100) DEFAULT NULL,
  `tin` varchar(100) DEFAULT NULL,
  `vat_vrn` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city_region` varchar(100) DEFAULT 'Dar es Salaam',
  `country` varchar(100) DEFAULT 'Tanzania',
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `website` varchar(200) DEFAULT NULL,
  `default_currency` varchar(10) NOT NULL DEFAULT 'TZS',
  `authorized_signatory` varchar(200) DEFAULT NULL,
  `signatory_title` varchar(100) DEFAULT NULL,
  `finance_contact` varchar(200) DEFAULT NULL,
  `finance_email` varchar(200) DEFAULT NULL,
  `tech_contact` varchar(200) DEFAULT NULL,
  `tech_email` varchar(200) DEFAULT NULL,
  `logo_path` varchar(500) DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `neilos_company_info_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neilos_company_info`
--

LOCK TABLES `neilos_company_info` WRITE;
/*!40000 ALTER TABLE `neilos_company_info` DISABLE KEYS */;
INSERT INTO `neilos_company_info` VALUES (1,'Neilos Network Ltd','Neilos','REG-100890','TIN-001234567','4551','ILALA','Dar es Salaam','Tanzania','+255623700877','manager@neilosnetwork.co.tz','https://neilosnetwork.co.tz','USD','Mr Moses Palela','Managing Director','Irene','irene@neilosnetwork.co.tz','Noc','noc@neilosnetwork.co.tz',NULL,1,'2026-08-24 11:10:42','2026-09-16 10:22:36');
/*!40000 ALTER TABLE `neilos_company_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_queue`
--

DROP TABLE IF EXISTS `notification_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `channel` enum('Email','SMS','WhatsApp') NOT NULL DEFAULT 'Email',
  `recipient` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `context_type` varchar(50) DEFAULT NULL,
  `context_id` int(10) unsigned DEFAULT NULL,
  `status` enum('Queued','Sent','Failed') NOT NULL DEFAULT 'Queued',
  `attempts` int(11) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_queue`
--

LOCK TABLES `notification_queue` WRITE;
/*!40000 ALTER TABLE `notification_queue` DISABLE KEYS */;
INSERT INTO `notification_queue` VALUES (1,'Email','janeth.kiwelu@seacom.co.tz','KYC Application Submitted for Review — SEACOM TANZANIA LIMITED','Your KYC application has been submitted for approval. Please log into the portal to review and approve/reject.','kyc',1,'Queued',0,NULL,NULL,'2026-09-17 15:52:48'),(2,'Email','admin@neilos.co.tz','KYC Application Submitted — SEACOM TANZANIA LIMITED','KYC Application #1 for SEACOM TANZANIA LIMITED has been submitted for approval.','kyc',1,'Queued',0,NULL,NULL,'2026-09-17 15:52:48'),(3,'Email','management@neilos.co.tz','KYC Application Submitted — SEACOM TANZANIA LIMITED','KYC Application #1 for SEACOM TANZANIA LIMITED has been submitted for approval.','kyc',1,'Queued',0,NULL,NULL,'2026-09-17 15:52:48');
/*!40000 ALTER TABLE `notification_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(500) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_read` (`user_id`,`is_read`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_documents`
--

DROP TABLE IF EXISTS `order_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `doc_type` enum('sof','feasibility_report','diagram','uat_signoff','completion_certificate','invoice','evidence','countersigned_sof','other') NOT NULL DEFAULT 'other',
  `evidence_category` varchar(100) DEFAULT NULL COMMENT 'Links to evidence checklist type for multi-file support',
  `is_partner_visible` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'If 1, partner can see this doc',
  `document_type` varchar(100) DEFAULT NULL COMMENT 'Legacy friendly name',
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `uploaded_by` int(10) unsigned NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `idx_order_doc` (`order_id`,`doc_type`),
  CONSTRAINT `order_documents_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_documents_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_documents`
--

LOCK TABLES `order_documents` WRITE;
/*!40000 ALTER TABLE `order_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_returns`
--

DROP TABLE IF EXISTS `order_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_returns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `returned_by` int(10) unsigned NOT NULL,
  `returned_at` datetime DEFAULT current_timestamp(),
  `from_status` varchar(100) NOT NULL,
  `to_status` varchar(100) NOT NULL,
  `return_reason` varchar(200) NOT NULL,
  `return_remarks` text DEFAULT NULL,
  `routed_to` enum('BSA','KAM','Project Manager','Contractor','Partner') NOT NULL,
  `old_nrc` decimal(12,2) DEFAULT NULL,
  `new_nrc` decimal(12,2) DEFAULT NULL,
  `old_mrc` decimal(12,2) DEFAULT NULL,
  `new_mrc` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `returned_by` (`returned_by`),
  KEY `idx_order` (`order_id`),
  CONSTRAINT `order_returns_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_returns_ibfk_2` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_returns`
--

LOCK TABLES `order_returns` WRITE;
/*!40000 ALTER TABLE `order_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_timeline`
--

DROP TABLE IF EXISTS `order_timeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_timeline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `status` varchar(100) NOT NULL,
  `note` text DEFAULT NULL,
  `changed_by` int(10) unsigned DEFAULT NULL,
  `changed_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `changed_by` (`changed_by`),
  KEY `idx_order_status` (`order_id`,`status`),
  KEY `idx_changed_at` (`changed_at`),
  CONSTRAINT `order_timeline_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_timeline_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_timeline`
--

LOCK TABLES `order_timeline` WRITE;
/*!40000 ALTER TABLE `order_timeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_timeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `sof_number` varchar(50) DEFAULT NULL COMMENT 'SO-prefixed reference generated at SOF print',
  `partner_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `service_id` varchar(100) DEFAULT NULL,
  `capacity` int(10) unsigned DEFAULT 0,
  `capacity_unit` varchar(20) DEFAULT 'Mbps',
  `pop_location` varchar(200) DEFAULT NULL,
  `customer_name` varchar(200) NOT NULL,
  `customer_contact_name` varchar(200) DEFAULT NULL,
  `customer_contact_phone` varchar(50) DEFAULT NULL,
  `customer_contact_email` varchar(200) DEFAULT NULL,
  `customer_location` varchar(255) DEFAULT NULL,
  `pickup_location` varchar(255) DEFAULT NULL,
  `building_name` varchar(200) DEFAULT NULL,
  `floor_number` varchar(50) DEFAULT NULL,
  `apartment_number` varchar(50) DEFAULT NULL,
  `end_user_address` text DEFAULT NULL,
  `city_region` varchar(100) DEFAULT NULL,
  `gps_coordinates` varchar(100) DEFAULT NULL,
  `site_category` varchar(100) DEFAULT NULL,
  `interface_type` varchar(50) DEFAULT 'SFP',
  `connector_type` varchar(50) DEFAULT 'LC',
  `media_type` varchar(50) DEFAULT 'Single-mode Fiber',
  `power_type` varchar(50) DEFAULT 'AC 220V',
  `rack_space` varchar(50) DEFAULT NULL,
  `nrc_usd` decimal(12,2) NOT NULL DEFAULT 0.00,
  `mrc_usd` decimal(12,2) NOT NULL DEFAULT 0.00,
  `vat_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_mrc_incl_vat` decimal(12,2) NOT NULL DEFAULT 0.00,
  `standard_mrc` decimal(12,2) DEFAULT NULL,
  `revised_mrc` decimal(12,2) DEFAULT NULL,
  `mrc_justification` text DEFAULT NULL,
  `kam_approved_at` datetime DEFAULT NULL,
  `kam_approved_by` int(10) unsigned DEFAULT NULL,
  `kam_proposed_nrc` decimal(14,2) DEFAULT NULL COMMENT 'KAM exception NRC proposal',
  `kam_proposed_mrc` decimal(14,2) DEFAULT NULL COMMENT 'KAM exception MRC proposal',
  `kam_commercial_justification` text DEFAULT NULL COMMENT 'Mandatory when KAM proposes exception',
  `kam_remarks` text DEFAULT NULL COMMENT 'Optional remarks from KAM',
  `management_approved_at` datetime DEFAULT NULL,
  `management_approved_by` int(10) unsigned DEFAULT NULL,
  `management_approved_price` decimal(12,2) DEFAULT NULL,
  `management_final_nrc` decimal(14,2) DEFAULT NULL COMMENT 'Management final NRC when using Approve with Revised Price',
  `management_final_mrc` decimal(14,2) DEFAULT NULL COMMENT 'Management final MRC when using Approve with Revised Price',
  `management_decision` enum('Approve as Requested','Approve with Revised Price','Keep Standard Price','Return to KAM') DEFAULT NULL,
  `management_remarks` text DEFAULT NULL,
  `management_return_remarks` text DEFAULT NULL COMMENT 'Remarks when Management returns to KAM',
  `management_remarks_visible` tinyint(1) DEFAULT 0,
  `sof_generated_at` datetime DEFAULT NULL,
  `sof_uploaded_at` datetime DEFAULT NULL,
  `sof_signed_file` varchar(500) DEFAULT NULL,
  `sof_signed_filename` varchar(255) DEFAULT NULL,
  `countersigned_sof_at` datetime DEFAULT NULL,
  `countersigned_sof_file` varchar(500) DEFAULT NULL,
  `countersigned_sof_filename` varchar(255) DEFAULT NULL,
  `countersigned_sof_by` int(10) unsigned DEFAULT NULL,
  `sof_return_comments` text DEFAULT NULL,
  `return_reason` varchar(100) DEFAULT NULL,
  `return_remarks` text DEFAULT NULL,
  `return_route` enum('BSA','KAM') DEFAULT NULL,
  `returned_by` int(10) unsigned DEFAULT NULL,
  `returned_at` datetime DEFAULT NULL,
  `service_type` varchar(100) NOT NULL DEFAULT 'FTTH',
  `fttx_package` varchar(100) DEFAULT NULL,
  `bandwidth` varchar(100) DEFAULT NULL,
  `nni_location` varchar(200) DEFAULT NULL,
  `aggregate_capacity` varchar(100) DEFAULT NULL,
  `contract_term` varchar(50) DEFAULT NULL,
  `special_requirements` text DEFAULT NULL,
  `usd_tzs_rate` decimal(12,4) DEFAULT 2600.0000,
  `base_nrc_usd` decimal(14,2) DEFAULT 0.00,
  `remote_hands_nrc_usd` decimal(14,2) DEFAULT 0.00,
  `nrc_subtotal_usd` decimal(14,2) DEFAULT 0.00,
  `vat_on_nrc` decimal(14,2) DEFAULT 0.00,
  `total_nrc_incl_vat` decimal(14,2) DEFAULT 0.00,
  `base_mrc` decimal(14,2) DEFAULT 0.00,
  `mrc_currency` varchar(10) DEFAULT 'TZS',
  `discount_pct` decimal(5,2) DEFAULT 0.00,
  `discount_amount` decimal(14,2) DEFAULT 0.00,
  `vat_on_mrc` decimal(14,2) DEFAULT 0.00,
  `created_by` int(10) unsigned DEFAULT NULL,
  `assigned_kam_name` varchar(100) DEFAULT NULL,
  `kam_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Feasibility Review',
  `bsa_reviewed_by` int(10) unsigned DEFAULT NULL,
  `bsa_reviewed_at` datetime DEFAULT NULL,
  `bsa_feasi_approved` tinyint(1) DEFAULT NULL,
  `bsa_remarks` text DEFAULT NULL,
  `bsa_assigned_engineer` varchar(150) DEFAULT NULL,
  `bsa_target_completion_date` date DEFAULT NULL,
  `bsa_special_conditions` text DEFAULT NULL,
  `bsa_technical_result` enum('Technically Feasible','Technically Not Feasible') DEFAULT NULL,
  `bsa_not_feasible_reason` text DEFAULT NULL,
  `standard_nrc` decimal(12,2) DEFAULT 60.00,
  `revised_nrc` decimal(12,2) DEFAULT NULL,
  `nrc_justification` text DEFAULT NULL,
  `nrc_breakdown` longtext DEFAULT NULL,
  `bsa_approved_at` datetime DEFAULT NULL,
  `bsa_approved_by` int(10) unsigned DEFAULT NULL,
  `bsa_revision_note` text DEFAULT NULL,
  `kam_reviewed_by` int(10) unsigned DEFAULT NULL,
  `kam_reviewed_at` datetime DEFAULT NULL,
  `commercial_discount_pct` decimal(5,2) DEFAULT 0.00,
  `closed_date` date DEFAULT NULL,
  `installation_date` date DEFAULT NULL,
  `billing_start_date` date DEFAULT NULL,
  `billing_start_adjusted_by` int(10) unsigned DEFAULT NULL,
  `billing_start_adjusted_at` datetime DEFAULT NULL,
  `uat_submitted_at` datetime DEFAULT NULL,
  `uat_accepted_at` datetime DEFAULT NULL,
  `uat_accepted_by` int(10) unsigned DEFAULT NULL,
  `uat_rejected_at` datetime DEFAULT NULL,
  `uat_rejection_reason` text DEFAULT NULL,
  `uat_return_reason` text DEFAULT NULL,
  `uat_signoff_file` varchar(500) DEFAULT NULL,
  `billing_trigger_date` date DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `sla_paused` tinyint(1) NOT NULL DEFAULT 0,
  `sla_paused_at` datetime DEFAULT NULL,
  `sla_paused_hours` decimal(8,2) NOT NULL DEFAULT 0.00 COMMENT 'Accumulated paused hours',
  `noc_ip_configured` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'PM flag: NOC has completed IP configuration',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `sla_pause_reason` text DEFAULT NULL,
  `circuit_id` varchar(100) DEFAULT NULL,
  `uat_notified_at` datetime DEFAULT NULL,
  `uat_deadline` datetime DEFAULT NULL,
  `activation_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `contractor_team_id` int(11) DEFAULT NULL,
  `contractor_team_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `user_id` (`user_id`),
  KEY `service_id` (`service_id`),
  KEY `bsa_reviewed_by` (`bsa_reviewed_by`),
  KEY `bsa_approved_by` (`bsa_approved_by`),
  KEY `kam_reviewed_by` (`kam_reviewed_by`),
  KEY `kam_approved_by` (`kam_approved_by`),
  KEY `management_approved_by` (`management_approved_by`),
  KEY `countersigned_sof_by` (`countersigned_sof_by`),
  KEY `returned_by` (`returned_by`),
  KEY `uat_accepted_by` (`uat_accepted_by`),
  KEY `billing_start_adjusted_by` (`billing_start_adjusted_by`),
  KEY `idx_order_number` (`order_number`),
  KEY `idx_status` (`status`),
  KEY `idx_partner` (`partner_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`),
  CONSTRAINT `orders_ibfk_10` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_11` FOREIGN KEY (`uat_accepted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_12` FOREIGN KEY (`billing_start_adjusted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `orders_ibfk_4` FOREIGN KEY (`bsa_reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_5` FOREIGN KEY (`bsa_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_6` FOREIGN KEY (`kam_reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_7` FOREIGN KEY (`kam_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_8` FOREIGN KEY (`management_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_9` FOREIGN KEY (`countersigned_sof_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partner_kyc_applications`
--

DROP TABLE IF EXISTS `partner_kyc_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_kyc_applications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `partner_id` int(10) unsigned NOT NULL,
  `kyc_type` enum('Partner','Contractor') NOT NULL DEFAULT 'Partner',
  `registered_name` varchar(255) DEFAULT NULL,
  `trading_name` varchar(200) DEFAULT NULL,
  `registration_number` varchar(100) DEFAULT NULL,
  `tin` varchar(50) DEFAULT NULL,
  `vat_vrn` varchar(100) DEFAULT NULL,
  `customer_category` varchar(100) DEFAULT NULL,
  `industry_sector` varchar(100) DEFAULT NULL,
  `nature_of_business` text DEFAULT NULL,
  `office_address` text DEFAULT NULL,
  `city_region` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'Tanzania',
  `website` varchar(200) DEFAULT NULL,
  `main_contact_name` varchar(200) DEFAULT NULL,
  `main_contact_phone` varchar(50) DEFAULT NULL,
  `main_contact_email` varchar(200) DEFAULT NULL,
  `ops_contact_name` varchar(200) DEFAULT NULL,
  `ops_contact_phone` varchar(50) DEFAULT NULL,
  `ops_contact_email` varchar(200) DEFAULT NULL,
  `tech_supervisor_name` varchar(200) DEFAULT NULL,
  `tech_supervisor_phone` varchar(50) DEFAULT NULL,
  `tech_supervisor_email` varchar(200) DEFAULT NULL,
  `escalation_contact_name` varchar(200) DEFAULT NULL,
  `escalation_contact_phone` varchar(50) DEFAULT NULL,
  `escalation_contact_email` varchar(200) DEFAULT NULL,
  `bank_name` varchar(200) DEFAULT NULL,
  `bank_branch` varchar(200) DEFAULT NULL,
  `bank_account_name` varchar(200) DEFAULT NULL,
  `bank_account_number` varchar(100) DEFAULT NULL,
  `bank_payment_terms` varchar(200) DEFAULT NULL,
  `cap_ftth_install` tinyint(1) DEFAULT 0,
  `cap_sme_install` tinyint(1) DEFAULT 0,
  `cap_enterprise_install` tinyint(1) DEFAULT 0,
  `cap_site_survey` tinyint(1) DEFAULT 0,
  `cap_maintenance` tinyint(1) DEFAULT 0,
  `cap_remote_support` tinyint(1) DEFAULT 0,
  `service_regions` text DEFAULT NULL,
  `business_license` varchar(500) DEFAULT NULL,
  `hse_certificate` varchar(500) DEFAULT NULL,
  `trca_certificate` varchar(500) DEFAULT NULL,
  `custom_fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'IT-added custom fields' CHECK (json_valid(`custom_fields`)),
  `status` varchar(50) NOT NULL DEFAULT 'Draft',
  `rejection_reason` text DEFAULT NULL,
  `changes_requested_note` text DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `address` text DEFAULT NULL,
  `signatory2_name` varchar(200) DEFAULT NULL,
  `signatory2_email` varchar(200) DEFAULT NULL,
  `signatory2_phone` varchar(50) DEFAULT NULL,
  `billing_contact_name` varchar(200) DEFAULT NULL,
  `billing_contact_email` varchar(200) DEFAULT NULL,
  `billing_contact_phone` varchar(50) DEFAULT NULL,
  `contractor_agreement` varchar(500) DEFAULT NULL,
  `signed_sla_file` varchar(500) DEFAULT NULL,
  `safety_esg_file` varchar(500) DEFAULT NULL,
  `confidentiality_nda_file` varchar(500) DEFAULT NULL,
  `service_regions_file` varchar(500) DEFAULT NULL,
  `sla_accepted` tinyint(1) DEFAULT 0,
  `sla_accepted_at` datetime DEFAULT NULL,
  `safety_esg_accepted` tinyint(1) DEFAULT 0,
  `safety_esg_accepted_at` datetime DEFAULT NULL,
  `confidentiality_accepted` tinyint(1) DEFAULT 0,
  `confidentiality_accepted_at` datetime DEFAULT NULL,
  `accepted_by` int(10) unsigned DEFAULT NULL,
  `auth_signatory_name` varchar(200) DEFAULT NULL,
  `auth_signatory_email` varchar(200) DEFAULT NULL,
  `auth_signatory_mobile` varchar(50) DEFAULT NULL,
  `review_notes` text DEFAULT NULL,
  `partner_tin_certificate` varchar(500) DEFAULT NULL,
  `partner_vrn_certificate` varchar(500) DEFAULT NULL,
  `partner_incorporation_cert` varchar(500) DEFAULT NULL,
  `partner_tcra_certificate` varchar(500) DEFAULT NULL,
  `partner_tax_clearance` varchar(500) DEFAULT NULL,
  `partner_business_licence` varchar(500) DEFAULT NULL,
  `auth_signatory_title` varchar(150) DEFAULT NULL,
  `signatory2_title` varchar(150) DEFAULT NULL,
  `tech_supervisor_title` varchar(150) DEFAULT NULL,
  `billing_contact_title` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `partner_id` (`partner_id`),
  KEY `reviewed_by` (`reviewed_by`),
  KEY `idx_status` (`status`),
  KEY `idx_kyc_type` (`kyc_type`),
  CONSTRAINT `partner_kyc_applications_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `partner_kyc_applications_ibfk_2` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner_kyc_applications`
--

LOCK TABLES `partner_kyc_applications` WRITE;
/*!40000 ALTER TABLE `partner_kyc_applications` DISABLE KEYS */;
INSERT INTO `partner_kyc_applications` VALUES (1,1,'Partner','SEACOM TANZANIA LIMITED',NULL,'','',NULL,NULL,NULL,NULL,'Plot No. 1962, Toure Drive Road ','Dar es Salaam','Tanzania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Godfrey Nengo','0721777399','Godfrey.nengo@seacom.com',NULL,NULL,NULL,'','','','','30 Days',0,0,0,0,0,0,NULL,NULL,NULL,NULL,'[]','Submitted for Approval',NULL,NULL,'2026-09-17 15:52:48',NULL,NULL,'2026-09-17 15:52:48','2026-09-17 15:52:48',NULL,'Janeth Kiwelu','janeth.kiwelu@seacom.co.tz','0748502231','Stewart Maxmillian ','stewart.maxmillian@seacom.co.tz','0684188140 ',NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,'Anna Kahama - Rupia ','Kahama-rupia@seacom.co.tz','+255 78 717 7077 ',NULL,'uploads/kyc/1/2640870014dc7877fd0b1bb3d456f6d5.pdf','uploads/kyc/1/8fa2cef108cb91c03cff5d1b29421f5b.pdf','uploads/kyc/1/f85b78e2782bb9b365f8a4684deeea57.pdf','uploads/kyc/1/673400f53a8afa7f747cac1a51b98a38.pdf','uploads/kyc/1/29a636f279e3307d560fc13d7bacde5c.pdf','uploads/kyc/1/7e0b1dbde982ca85e8e5cc59a6d0dc09.pdf','Director','','Solutions Architect ','Senior Accountant ');
/*!40000 ALTER TABLE `partner_kyc_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partners`
--

DROP TABLE IF EXISTS `partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `trading_name` varchar(200) DEFAULT NULL,
  `partner_type` enum('ISP','Reseller','VAR','Enterprise','Government','Contractor','Other') NOT NULL DEFAULT 'Other',
  `partner_category` varchar(50) NOT NULL DEFAULT 'Partner',
  `kyc_type` enum('Partner','Contractor') NOT NULL DEFAULT 'Partner',
  `customer_category` varchar(100) DEFAULT NULL,
  `industry_sector` varchar(100) DEFAULT NULL,
  `nature_of_business` text DEFAULT NULL,
  `registration_number` varchar(100) DEFAULT NULL,
  `tin` varchar(100) DEFAULT NULL,
  `vat_vrn` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `contact_person_name` varchar(200) DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `contact_email` varchar(200) DEFAULT NULL,
  `city_region` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'Tanzania',
  `kam_id` int(10) unsigned DEFAULT NULL,
  `assigned_kam_name` varchar(100) DEFAULT NULL,
  `status` enum('Active','Inactive','Suspended') NOT NULL DEFAULT 'Active',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_kyc_type` (`kyc_type`),
  KEY `idx_kam` (`kam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partners`
--

LOCK TABLES `partners` WRITE;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
INSERT INTO `partners` VALUES (1,'SEACOM TANZANIA LIMITED','SEACOM TANZANIA LIMITED','ISP','Partner','Partner',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tanzania',NULL,NULL,'Active','2026-09-17 15:38:01','2026-09-17 15:38:01'),(2,'SPRINT TANZANIA LIMITED','SPRINT TANZANIA LIMITED','ISP','Partner','Partner',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tanzania',NULL,NULL,'Active','2026-09-17 15:57:04','2026-09-17 15:57:04');
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_change_audit`
--

DROP TABLE IF EXISTS `price_change_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price_change_audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `field_name` varchar(100) NOT NULL,
  `old_value` decimal(14,2) DEFAULT NULL,
  `new_value` decimal(14,2) DEFAULT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'TZS',
  `changed_by` int(10) unsigned NOT NULL,
  `stage` varchar(100) NOT NULL,
  `justification` text DEFAULT NULL,
  `changed_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `changed_by` (`changed_by`),
  KEY `idx_order` (`order_id`),
  KEY `idx_changed_at` (`changed_at`),
  CONSTRAINT `price_change_audit_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `price_change_audit_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_change_audit`
--

LOCK TABLES `price_change_audit` WRITE;
/*!40000 ALTER TABLE `price_change_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_change_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_pricing_packages`
--

DROP TABLE IF EXISTS `service_pricing_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_pricing_packages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_type` varchar(50) NOT NULL,
  `package_code` varchar(100) NOT NULL,
  `package_name` varchar(150) NOT NULL,
  `speed_mbps` int(11) DEFAULT NULL,
  `mrc_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `nrc_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(10) NOT NULL DEFAULT 'TZS',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_svc` (`service_type`),
  KEY `idx_pkg` (`package_code`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_pricing_packages`
--

LOCK TABLES `service_pricing_packages` WRITE;
/*!40000 ALTER TABLE `service_pricing_packages` DISABLE KEYS */;
INSERT INTO `service_pricing_packages` VALUES (10,'FTTB','FTTB-30','30 Mbps (FTTB)',30,99000.00,140000.00,'USD',1,10,'2026-09-11 16:28:15','2026-09-16 14:49:29'),(11,'FTTB','FTTB-40','40 Mbps (FTTB)',40,27500.00,140000.00,'USD',1,11,'2026-09-11 16:28:15','2026-09-16 14:49:29'),(12,'FTTB','FTTB-50','50 Mbps (FTTB)',50,33000.00,140000.00,'USD',1,12,'2026-09-11 16:28:15','2026-09-16 14:49:29'),(13,'FTTB','FTTB-60','60 Mbps (FTTB)',60,39500.00,140000.00,'USD',1,13,'2026-09-11 16:28:15','2026-09-16 14:49:29'),(14,'FTTB','FTTB-70','70 Mbps (FTTB)',70,46000.00,140000.00,'USD',1,14,'2026-09-11 16:28:15','2026-09-16 14:49:29'),(15,'FTTB','FTTB-80','80 Mbps (FTTB)',80,52500.00,140000.00,'USD',1,15,'2026-09-11 16:28:15','2026-09-16 14:49:29'),(16,'FTTB','FTTB-90','90 Mbps (FTTB)',90,59000.00,140000.00,'USD',1,16,'2026-09-11 16:28:15','2026-09-16 14:49:29'),(17,'FTTB','FTTB-100','100 Mbps (FTTB)',100,65500.00,140000.00,'USD',1,17,'2026-09-11 16:28:15','2026-09-16 14:49:29'),(18,'Layer 2 ( last mile)','L2-100','<= 100 Mbps',100,110000.00,250000.00,'USD',1,18,'2026-09-11 16:28:15','2026-09-16 14:49:29'),(19,'Layer 2 ( last mile)','L2-1000','> 100 Mbps',1000,220000.00,250000.00,'USD',1,19,'2026-09-11 16:28:15','2026-09-16 14:49:29'),(20,'FTTH','FTTH-20','20 Mbps',20,10.40,60.00,'USD',1,1,'2026-09-15 06:05:38','2026-09-16 14:49:29'),(21,'FTTH','FTTH-30','30 Mbps',30,12.48,60.00,'USD',1,2,'2026-09-15 06:05:38','2026-09-16 14:49:29'),(22,'FTTH','FTTH-40','40 Mbps',40,13.52,60.00,'USD',1,3,'2026-09-15 06:05:38','2026-09-16 14:49:29'),(23,'FTTH','FTTH-50','50 Mbps',50,16.22,60.00,'USD',1,4,'2026-09-15 06:05:38','2026-09-16 14:49:29'),(24,'FTTH','FTTH-60','60 Mbps',60,19.47,60.00,'USD',1,5,'2026-09-15 06:05:38','2026-09-16 14:49:29'),(25,'FTTH','FTTH-80','80 Mbps',80,23.36,60.00,'USD',1,6,'2026-09-15 06:05:38','2026-09-16 14:49:29'),(26,'FTTH','FTTH-100','100 Mbps',100,28.04,60.00,'USD',1,7,'2026-09-15 06:05:38','2026-09-16 14:49:29');
/*!40000 ALTER TABLE `service_pricing_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_types`
--

DROP TABLE IF EXISTS `service_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `short_code` varchar(10) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `pricing_model` varchar(50) NOT NULL DEFAULT 'package',
  `default_nrc` decimal(15,2) NOT NULL DEFAULT 0.00,
  `default_mrc` decimal(15,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_types`
--

LOCK TABLES `service_types` WRITE;
/*!40000 ALTER TABLE `service_types` DISABLE KEYS */;
INSERT INTO `service_types` VALUES (1,'FTTH','FTH','FTTH','Fibre to the Home (Shared Broadband)','package',60.00,10.40,1,1,'2026-09-11 16:28:15','2026-09-17 13:22:48'),(2,'FTTB','FTB','FTTB','Fibre to the Building (Shared Business Broadband)','package',0.00,0.00,1,2,'2026-09-11 16:28:15','2026-09-17 13:22:48'),(3,'Layer 2 ( last mile)','L2','Layer 2 ( last mile)','Dedicated Layer 2 Ethernet Last Mile','capacity',0.00,0.00,1,3,'2026-09-11 16:28:15','2026-09-17 13:22:48'),(4,'BIA (Broadband Internet Access)','BIA','BIA (Broadband Internet Access)','Broadband Internet Access','custom',0.00,0.00,1,4,'2026-09-11 16:28:15','2026-09-17 13:22:48'),(5,'DIA','DIA','DIA','Dedicated Internet Access (Dedicated Bandwidth)','custom',100.00,0.00,1,5,'2026-09-11 16:28:15','2026-09-17 13:22:48'),(6,'Remote Hands Only','RHO','Remote Hands Only','Remote Hands On-Site Technical Assistance','fixed',0.00,0.00,1,6,'2026-09-11 16:28:15','2026-09-17 13:22:48');
/*!40000 ALTER TABLE `service_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `code` varchar(50) NOT NULL,
  `category` enum('Internet','Ethernet','IP Transit','Colocation','Cloud','Voice','Managed Services') NOT NULL,
  `description` text DEFAULT NULL,
  `unit` varchar(50) DEFAULT 'Mbps',
  `base_nrc` decimal(12,2) NOT NULL DEFAULT 0.00,
  `base_mrc` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,'Dedicated Internet Access (DIA)','DIA-STD','Internet','High-speed, symmetrical, uncontended DIA with guaranteed SLA.','Mbps',300.00,15.00,1,'2026-08-24 11:10:42'),(2,'Layer 2 Ethernet Point-to-Point','EPL-STD','Ethernet','Point-to-point Layer 2 Ethernet connection over optical fiber.','Mbps',250.00,12.00,1,'2026-08-24 11:10:42'),(3,'Colocation Rack Space (Full Rack)','COLO-FULL','Colocation','Full 42U rack space with dual A+B power feeds and precision cooling.','Rack',500.00,800.00,1,'2026-08-24 11:10:42'),(4,'IP Transit Service','IPT-STD','IP Transit','BGP IP Transit with multiple Tier-1 upstream paths.','Mbps',200.00,8.00,1,'2026-08-24 11:10:42'),(5,'FTTH Wholesale Fiber Connection','FTTH-WHOLESALE','Internet','Wholesale last-mile FTTH connection for ISPs and Resellers.','Mbps',60.00,8.00,1,'2026-08-24 11:10:42');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla_config`
--

DROP TABLE IF EXISTS `sla_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sla_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sla_name` varchar(200) NOT NULL,
  `sla_type` varchar(100) NOT NULL COMMENT 'stage, site_type, service_type',
  `target_hours` int(11) NOT NULL COMMENT 'Working hours',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla_config`
--

LOCK TABLES `sla_config` WRITE;
/*!40000 ALTER TABLE `sla_config` DISABLE KEYS */;
INSERT INTO `sla_config` VALUES (1,'Feasibility Acknowledgement','stage',8,'BSA must acknowledge within 1 working day',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(2,'In Coverage Installation','site_type',16,'Standard serviceable location - 2 working days',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(3,'Apartment without MDU','site_type',24,'MDU readiness required - 3 working days',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(4,'Extension above 200m','site_type',40,'Extension work required - 5 working days',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(5,'Pole + Extension','site_type',56,'Pole and extension required - 7 working days',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(6,'Testing Review after Completion','stage',8,'PM/BSA reviews same day or next working day',1,'2026-08-24 11:10:42','2026-08-24 11:10:42'),(7,'Partner UAT Response','stage',48,'48 hours for partner UAT acceptance',1,'2026-08-24 11:10:42','2026-08-24 11:10:42');
/*!40000 ALTER TABLE `sla_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_events`
--

DROP TABLE IF EXISTS `system_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_type` varchar(100) NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `assignment_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `payload` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_created` (`created_at`),
  KEY `idx_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_events`
--

LOCK TABLES `system_events` WRITE;
/*!40000 ALTER TABLE `system_events` DISABLE KEYS */;
INSERT INTO `system_events` VALUES (1,'kyc_status_updated',NULL,NULL,1,'{\"event_type\":\"kyc_status_updated\",\"order_id\":null,\"timestamp\":\"2026-09-17 15:52:48\",\"data\":{\"kyc_id\":1,\"status\":\"Submitted for Approval\"}}','2026-09-17 15:52:48');
/*!40000 ALTER TABLE `system_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=574250 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'usd_exchange_rate','2650.00',1,'2026-09-15 09:27:11','2026-08-29 23:14:58');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `partner_id` int(10) unsigned DEFAULT NULL COMMENT 'NULL = admin/internal user',
  `full_name` varchar(200) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `password_changed_at` datetime DEFAULT current_timestamp(),
  `mobile` varchar(30) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'Partner',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `permissions` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `is_first_login` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `otp_secret` varchar(32) DEFAULT NULL,
  `otp_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `otp_verified` tinyint(1) NOT NULL DEFAULT 0,
  `profile_picture` varchar(500) DEFAULT NULL,
  `status` enum('Active','Inactive','Suspended') NOT NULL DEFAULT 'Active',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `partner_id` (`partner_id`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,'System Administrator','admin','admin@neilosnetwork.co.tz','$2y$10$D3lRnGBfLfxDVE4uOvK1tO.546C.n/NnFtMevnyXAVlQKV1SmrjOq','2026-09-17 13:09:39','+255711000008','System Admin',1,NULL,NULL,0,'2026-09-17 15:32:16',NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-09-17 15:32:16'),(10,NULL,'Operations Manager (Management)','manager','manager@neilosnetwork.co.tz','$2y$10$E9fLFRNwtNJRaAbQiQlMoe/FII/FxRrwhJcECG3cloU/s5kZJtdSC','2026-09-15 08:59:25','+255711000004','Management',1,NULL,NULL,0,'2026-08-24 21:02:56',NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-09-15 08:59:25'),(12,NULL,'Finance & Billing Manager','billing','billing@neilosnetwork.co.tz','$2y$10$E9fLFRNwtNJRaAbQiQlMoe/FII/FxRrwhJcECG3cloU/s5kZJtdSC','2026-09-15 08:59:25','+255711000007','Billing',1,NULL,NULL,0,NULL,NULL,0,1,NULL,'Active','2026-08-24 11:10:42','2026-09-15 08:59:25'),(15,NULL,'MHINA KIHIYO','Mhina','mhina.kihiyo@savannafibre.co.tz','$2y$10$wacJ3LzOGhQ7hr9Sv9xJtODLWQdktxEbFhpVSYhHvrrElVi1PNfZ6','2026-09-09 12:42:15','0717449340','System Admin',1,NULL,1,0,'2026-09-17 15:28:52',NULL,0,0,NULL,'Active','2026-08-31 17:07:20','2026-09-17 15:28:52'),(16,NULL,'Aida Robert','arobert','aida.robert@neilosnetwork.co.tz','$2y$10$woZ4aiaNqX/CAoW8zrJAn.u2Ps7WttJtUqIBU1bIPMj6/LeUa/BrW','2026-09-09 12:42:15','0785670498','KAM',1,NULL,1,0,'2026-09-17 13:10:01',NULL,0,0,NULL,'Active','2026-09-01 16:10:16','2026-09-17 13:10:01'),(20,NULL,'EDWIN CHAMU','echamu','comfortmnyinga@gmail.com','$2y$10$FHxXY7XK5I3AqfGqdifdBOp3GShbA8.m7nsMwN1.AnJe7hCDsrPmW','2026-09-09 12:42:15','0786670680','BSA',1,NULL,1,0,'2026-09-17 13:05:39',NULL,0,1,NULL,'Active','2026-09-03 10:24:57','2026-09-17 15:54:41'),(52,1,'SEACOM TANZANIA LIMITED','seacom','janeth.kiwelu@seacom.co.tz','$2y$10$rNT9kYnXt89dOun0N8w7qeqxKD.wnZIfzZRmijnXn2VgLsSvv6qmm','2026-09-17 15:48:30','0748502231','Partner',1,NULL,1,0,'2026-09-17 15:48:06',NULL,0,1,NULL,'Active','2026-09-17 15:38:01','2026-09-17 15:48:30'),(53,2,'SPRINT TANZANIA LIMITED','sprint','Irene@sprinttz.co.tz','$2y$10$zhXzRruMY3FXTAgfERQtD.Gtamjmj3XnHvLtHOfs2729.h.9wBKTy','2026-09-17 15:57:04','0797333063','Partner',1,NULL,1,1,NULL,NULL,0,0,NULL,'Active','2026-09-17 15:57:04','2026-09-17 15:57:04');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 16:00:01
