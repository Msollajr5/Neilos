<?php
// ============================================================
// Neilos Partner Portal — Partner Detail & KYC View
// ============================================================
$kycStatus = $kycApp['status'] ?? null;
$kycBadgeClass = match($kycStatus) {
    'Approved' => 'badge-success',
    'Submitted for Approval', 'Pending Approval', 'Submitted' => 'badge-warning',
    'Rejected' => 'badge-danger',
    'Draft' => 'badge-secondary',
    default => 'badge-secondary'
};
?>
<div class="page-header">
  <div class="page-header-left">
    <div class="page-title"><?= e($partner['name']) ?></div>
    <div class="page-subtitle"><?= e($partner['partner_type']) ?> · <?= e($partner['status']) ?> · Created <?= fmtDate($partner['created_at']) ?></div>
  </div>
  <div class="page-header-actions">
    <a href="<?= APP_URL ?>/?page=partners" class="btn btn-secondary"><?= svgIcon('list') ?> All Partners</a>
    <a href="<?= APP_URL ?>/?page=partners&action=edit&id=<?= $partner['id'] ?>" class="btn btn-primary"><?= svgIcon('edit') ?> Edit Partner</a>
    <?php if ($kycApp): ?>
      <a href="<?= APP_URL ?>/?page=kyc&action=<?= $kycApp['status'] === 'Approved' ? 'view' : 'edit' ?>&id=<?= $kycApp['id'] ?>" class="btn btn-secondary">
        <?= svgIcon('document') ?> <?= $kycApp['status'] === 'Approved' ? 'View Full KYC' : 'Edit KYC Application' ?>
      </a>
    <?php else: ?>
      <a href="<?= APP_URL ?>/?page=kyc&action=new&partner_id=<?= $partner['id'] ?>" class="btn btn-secondary">
        <?= svgIcon('plus') ?> Apply for KYC
      </a>
    <?php endif; ?>
    <?php if (isAdmin() || hasRole('Management')): ?>
    <form method="POST" action="<?= APP_URL ?>/?page=partners&action=delete" style="display:inline" data-confirm="Permanently delete partner <?= e($partner['name']) ?>?">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <input type="hidden" name="id" value="<?= $partner['id'] ?>">
      <button type="submit" class="btn btn-danger"><?= svgIcon('trash') ?> Delete Partner</button>
    </form>
    <?php endif; ?>
  </div>
</div>

<!-- 4-Card Stats Grid -->
<div class="stats-grid mb-24" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));gap:16px">
  <div class="card">
    <div class="card-body" style="text-align:center;padding:20px">
      <div style="font-size:2rem;font-weight:700;color:var(--primary)"><?= $userCount ?></div>
      <div style="font-size:.85rem;color:var(--text-secondary);margin-top:4px">Linked Users</div>
    </div>
  </div>
  <div class="card">
    <div class="card-body" style="text-align:center;padding:20px">
      <div style="font-size:2rem;font-weight:700;color:var(--primary)"><?= $orderCount ?></div>
      <div style="font-size:.85rem;color:var(--text-secondary);margin-top:4px">Service Orders</div>
    </div>
  </div>
  <div class="card">
    <div class="card-body" style="text-align:center;padding:20px">
      <div style="font-size:1.8rem;font-weight:700;color:var(--primary)"><?= e($partner['partner_type']) ?></div>
      <div style="font-size:.85rem;color:var(--text-secondary);margin-top:4px">Partner Type</div>
    </div>
  </div>
  <div class="card" style="cursor:pointer" onclick="switchPartnerTab('kyc')">
    <div class="card-body" style="text-align:center;padding:20px">
      <div style="margin-top:2px">
        <?php if ($kycApp): ?>
          <span class="badge <?= $kycBadgeClass ?>" style="font-size:1rem;padding:6px 14px">
            <?= e($kycApp['status']) ?>
          </span>
        <?php else: ?>
          <span class="badge badge-secondary" style="font-size:0.95rem;padding:6px 14px;opacity:0.8">
            Not Applied
          </span>
        <?php endif; ?>
      </div>
      <div style="font-size:.85rem;color:var(--text-secondary);margin-top:10px">
        KYC Compliance Status
      </div>
    </div>
  </div>
</div>

<!-- Tab Navigation Bar -->
<div class="partner-tabs-nav" style="display:flex;gap:10px;border-bottom:2px solid var(--border);margin-bottom:24px">
  <button type="button" class="partner-tab-btn active" id="tabBtnOverview" onclick="switchPartnerTab('overview')">
    <?= svgIcon('building', 16) ?> General &amp; Location
  </button>
  <button type="button" class="partner-tab-btn" id="tabBtnKyc" onclick="switchPartnerTab('kyc')">
    <?= svgIcon('document', 16) ?> KYC Details
    <?php if ($kycApp): ?>
      <span class="badge <?= $kycBadgeClass ?>" style="font-size:0.75rem;margin-left:6px">
        <?= e($kycApp['status']) ?>
      </span>
    <?php else: ?>
      <span class="badge badge-secondary" style="font-size:0.75rem;margin-left:6px;opacity:0.75">Not Applied</span>
    <?php endif; ?>
  </button>
</div>

<!-- TAB 1: OVERVIEW & LOCATION -->
<div id="partnerTabOverview">
  <div class="grid-2col mb-24">
    <div class="card">
      <div class="card-header"><div class="card-title">General Information</div></div>
      <div class="card-body">
        <div class="form-grid form-grid-2">
          <div class="form-group"><label>Partner Name</label><div class="font-600"><?= e($partner['name']) ?></div></div>
          <div class="form-group"><label>Trading Name</label><div><?= e($partner['trading_name'] ?: '—') ?></div></div>
          <div class="form-group"><label>Partner Type</label><div><span class="badge badge-primary"><?= e($partner['partner_type']) ?></span></div></div>
          <div class="form-group"><label>Assigned KAM</label><div class="font-600" style="color:var(--primary)"><?= e($partner['assigned_kam_name'] ?: 'Not Assigned') ?></div></div>
          <div class="form-group"><label>Status</label><div>
            <?php if ($partner['status'] === 'Active'): ?>
            <span class="badge badge-success">Active</span>
            <?php elseif ($partner['status'] === 'Inactive'): ?>
            <span class="badge badge-secondary">Inactive</span>
            <?php else: ?>
            <span class="badge badge-danger">Suspended</span>
            <?php endif; ?>
          </div></div>
          <div class="form-group"><label>Registration Number</label><div><?= e($partner['registration_number'] ?: '—') ?></div></div>
          <div class="form-group"><label>TIN</label><div><?= e($partner['tin'] ?: '—') ?></div></div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><div class="card-title">Location</div></div>
      <div class="card-body">
        <div class="form-grid form-grid-2">
          <div class="form-group"><label>Address</label><div><?= e($partner['address'] ?: '—') ?></div></div>
          <div class="form-group"><label>City / Region</label><div><?= e($partner['city_region'] ?: '—') ?></div></div>
          <div class="form-group"><label>Country</label><div><?= e($partner['country']) ?></div></div>
        </div>
      </div>
    </div>
  </div>

  <?php if ($partner['created_at'] !== $partner['updated_at']): ?>
  <div class="card">
    <div class="card-body" style="padding:14px 18px;font-size:.82rem;color:var(--text-muted)">
      Created <?= fmtDateTime($partner['created_at']) ?> · Last updated <?= fmtDateTime($partner['updated_at']) ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<!-- TAB 2: KYC DETAILS -->
<div id="partnerTabKyc" style="display:none">
  <?php if ($kycApp): ?>
    <!-- KYC Header & Action Bar -->
    <div class="card mb-24" style="border:1px solid var(--border);border-radius:var(--radius-lg);padding:18px 22px;background:var(--surface-1);box-shadow:var(--shadow-sm)">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px">
        <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
          <span class="badge <?= $kycBadgeClass ?>" style="font-size:0.92rem;padding:6px 14px;font-weight:700">
            <?= e($kycApp['status']) ?>
          </span>
          <span style="font-size:0.9rem;color:var(--text-secondary)">
            Application: <strong style="color:var(--text-primary)">#KYC-<?= $kycApp['id'] ?></strong>
          </span>
          <span style="font-size:0.9rem;color:var(--text-secondary)">
            Type: <span class="badge badge-info" style="font-size:0.75rem"><?= e($kycApp['kyc_type'] ?: 'Partner') ?></span>
          </span>
          <?php if (!empty($kycApp['submitted_at'])): ?>
          <span style="font-size:0.9rem;color:var(--text-secondary)">
            Submitted: <strong style="color:var(--text-primary)"><?= fmtDate($kycApp['submitted_at']) ?></strong>
          </span>
          <?php endif; ?>
          <?php if (!empty($kycApp['reviewer_name'])): ?>
          <span style="font-size:0.9rem;color:var(--text-secondary)">
            Reviewer: <strong style="color:var(--text-primary)"><?= e($kycApp['reviewer_name']) ?></strong>
          </span>
          <?php endif; ?>
        </div>

        <div>
          <a href="<?= APP_URL ?>/?page=kyc&action=<?= $kycApp['status'] === 'Approved' ? 'view' : 'edit' ?>&id=<?= $kycApp['id'] ?>" class="btn btn-primary" style="display:inline-flex;align-items:center;gap:6px">
            <?= svgIcon('edit', 14) ?> <?= $kycApp['status'] === 'Approved' ? 'View Full KYC Form' : 'Edit / Manage KYC Application' ?>
          </a>
        </div>
      </div>

      <?php if ($kycApp['status'] === 'Rejected' && !empty($kycApp['rejection_reason'])): ?>
      <div style="margin-top:16px;padding:12px 16px;background:#fef2f2;border:1px solid #fca5a5;border-radius:var(--radius-md);color:#991b1b;font-size:0.9rem">
        <strong>⚠️ Rejection Reason:</strong> <?= e($kycApp['rejection_reason']) ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- 1. Registered Company Details -->
    <div class="card mb-24">
      <div class="card-header" style="background:var(--surface-2)">
        <div class="card-title" style="font-weight:700"><?= svgIcon('building', 15) ?> Company &amp; Registration Details</div>
      </div>
      <div class="card-body">
        <div class="form-grid form-grid-3" style="margin-bottom:16px">
          <div class="form-group"><label>Registered Legal Name</label><div class="font-600"><?= e($kycApp['registered_name'] ?: ($partner['name'] ?? '—')) ?></div></div>
          <div class="form-group"><label>Registration Number</label><div class="font-mono font-600"><?= e($kycApp['registration_number'] ?: '—') ?></div></div>
          <div class="form-group"><label>TIN</label><div class="font-mono font-600"><?= e($kycApp['tin'] ?: '—') ?></div></div>
        </div>
        <div class="form-grid form-grid-3" style="margin-bottom:16px">
          <div class="form-group"><label>VAT / VRN</label><div class="font-mono"><?= e($kycApp['vat_vrn'] ?: '—') ?></div></div>
          <div class="form-group"><label>City / Region</label><div><?= e($kycApp['city_region'] ?: ($partner['city_region'] ?: '—')) ?></div></div>
          <div class="form-group"><label>Country</label><div><?= e($kycApp['country'] ?: ($partner['country'] ?: 'Tanzania')) ?></div></div>
        </div>
        <div class="form-group">
          <label>Physical Office Address</label>
          <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px 14px;font-size:0.9rem">
            <?= e($kycApp['office_address'] ?: ($partner['address'] ?: '—')) ?>
          </div>
        </div>
      </div>
    </div>

    <!-- 2. Contacts & Authorized Signatories -->
    <div class="card mb-24">
      <div class="card-header" style="background:var(--surface-2)">
        <div class="card-title" style="font-weight:700"><?= svgIcon('users', 15) ?> Contacts &amp; Authorized Signatories</div>
      </div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(240px, 1fr));gap:16px">
          <!-- Signatory 1 -->
          <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px 16px">
            <div style="font-size:0.8rem;font-weight:700;color:var(--accent);text-transform:uppercase;margin-bottom:8px">Signatory 1 (Primary)</div>
            <div style="font-weight:600;font-size:0.95rem;margin-bottom:4px"><?= e($kycApp['auth_signatory_name'] ?: '—') ?></div>
            <div style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:2px">✉ <?= e($kycApp['auth_signatory_email'] ?: '—') ?></div>
            <div style="font-size:0.85rem;color:var(--text-secondary)">☎ <?= e($kycApp['auth_signatory_mobile'] ?: '—') ?></div>
          </div>

          <!-- Signatory 2 -->
          <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px 16px">
            <div style="font-size:0.8rem;font-weight:700;color:var(--accent);text-transform:uppercase;margin-bottom:8px">Signatory 2 / Operations</div>
            <div style="font-weight:600;font-size:0.95rem;margin-bottom:4px"><?= e($kycApp['signatory2_name'] ?: '—') ?></div>
            <div style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:2px">✉ <?= e($kycApp['signatory2_email'] ?: '—') ?></div>
            <div style="font-size:0.85rem;color:var(--text-secondary)">☎ <?= e($kycApp['signatory2_phone'] ?: '—') ?></div>
          </div>

          <!-- Technical Contact -->
          <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px 16px">
            <div style="font-size:0.8rem;font-weight:700;color:var(--accent);text-transform:uppercase;margin-bottom:8px">Technical Supervisor</div>
            <div style="font-weight:600;font-size:0.95rem;margin-bottom:4px"><?= e($kycApp['tech_supervisor_name'] ?: '—') ?></div>
            <div style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:2px">✉ <?= e($kycApp['tech_supervisor_email'] ?: '—') ?></div>
            <div style="font-size:0.85rem;color:var(--text-secondary)">☎ <?= e($kycApp['tech_supervisor_phone'] ?: '—') ?></div>
          </div>

          <!-- Billing Contact -->
          <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);padding:14px 16px">
            <div style="font-size:0.8rem;font-weight:700;color:var(--accent);text-transform:uppercase;margin-bottom:8px">Billing / Escalation</div>
            <div style="font-weight:600;font-size:0.95rem;margin-bottom:4px"><?= e($kycApp['billing_contact_name'] ?: '—') ?></div>
            <div style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:2px">✉ <?= e($kycApp['billing_contact_email'] ?: '—') ?></div>
            <div style="font-size:0.85rem;color:var(--text-secondary)">☎ <?= e($kycApp['billing_contact_phone'] ?: '—') ?></div>
          </div>
        </div>
      </div>
    </div>

    <!-- 3. Bank & Payment Details -->
    <div class="card mb-24">
      <div class="card-header" style="background:var(--surface-2)">
        <div class="card-title" style="font-weight:700"><?= svgIcon('bank', 15) ?> Bank &amp; Settlement Details</div>
      </div>
      <div class="card-body">
        <div class="form-grid form-grid-3" style="margin-bottom:16px">
          <div class="form-group"><label>Bank Name</label><div class="font-600"><?= e($kycApp['bank_name'] ?: '—') ?></div></div>
          <div class="form-group"><label>Branch</label><div><?= e($kycApp['bank_branch'] ?: '—') ?></div></div>
          <div class="form-group"><label>Payment Terms</label><div><span class="badge badge-secondary"><?= e($kycApp['bank_payment_terms'] ?: '30 Days') ?></span></div></div>
        </div>
        <div class="form-grid form-grid-2">
          <div class="form-group"><label>Account Name</label><div class="font-600"><?= e($kycApp['bank_account_name'] ?: '—') ?></div></div>
          <div class="form-group"><label>Account Number</label><div class="font-mono font-600"><?= e($kycApp['bank_account_number'] ?: '—') ?></div></div>
        </div>
      </div>
    </div>

    <!-- 4. Uploaded Compliance Documents -->
    <div class="card mb-24">
      <div class="card-header" style="background:var(--surface-2)">
        <div class="card-title" style="font-weight:700"><?= svgIcon('document', 15) ?> Compliance Documents</div>
      </div>
      <div class="card-body" style="padding:0">
        <?php
        $partnerDocs = [
            'partner_tin_certificate'    => '1. TIN Certificate',
            'partner_vrn_certificate'    => '2. VRN Certificate',
            'partner_incorporation_cert' => '3. Certificate of Incorporation',
            'partner_tcra_certificate'   => '4. TCRA Certificate',
            'partner_tax_clearance'      => '5. Tax Clearance Certificate',
            'partner_business_licence'   => '6. Business Licence Certificate',
        ];
        ?>
        <table class="data-table" style="width:100%;border-collapse:collapse">
          <thead>
            <tr>
              <th style="padding:12px 18px">Required Document</th>
              <th style="padding:12px 18px">File Status</th>
              <th style="padding:12px 18px;text-align:right">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($partnerDocs as $docKey => $docTitle): ?>
            <?php
              $filePath = $kycApp[$docKey] ?? '';
              $hasFile = !empty($filePath);
              $fileName = basename($filePath);
              $downloadUrl = APP_URL . "/?page=download&table=partner_kyc_applications&column={$docKey}&id={$kycApp['id']}";

              $fileExistsOnDisk = false;
              if ($hasFile) {
                  $rel = ltrim(str_replace('\\', '/', $filePath), '/');
                  $checkPath = PUBLIC_DIR . '/' . $rel;
                  if (!is_file($checkPath)) $checkPath = dirname(APP_DIR) . '/public/' . $rel;
                  if (!is_file($checkPath)) $checkPath = dirname(APP_DIR) . '/' . $rel;
                  $fileExistsOnDisk = is_file($checkPath);
              }
            ?>
            <tr style="border-bottom:1px solid var(--border)">
              <td style="padding:12px 18px;font-weight:600">
                <?= e($docTitle) ?>
              </td>
              <td style="padding:12px 18px">
                <?php if ($hasFile && $fileExistsOnDisk): ?>
                  <span class="badge badge-success" style="display:inline-flex;align-items:center;gap:4px">✓ Uploaded</span>
                <?php elseif ($hasFile && !$fileExistsOnDisk): ?>
                  <span class="badge badge-warning" style="display:inline-flex;align-items:center;gap:4px">⚠️ Missing on Disk</span>
                <?php else: ?>
                  <span class="badge badge-secondary" style="opacity:0.75">Not Uploaded</span>
                <?php endif; ?>
              </td>
              <td style="padding:12px 18px;text-align:right">
                <?php if ($hasFile): ?>
                  <button type="button" class="btn btn-secondary btn-sm" onclick="viewSystemFile('<?= e($filePath) ?>', '<?= e($fileName) ?>', '<?= e($downloadUrl) ?>')" style="padding:4px 10px;font-size:0.8rem">
                    <?= svgIcon('eye', 13) ?> View
                  </button>
                  <a href="<?= e($downloadUrl) ?>" class="btn btn-secondary btn-sm" style="padding:4px 10px;font-size:0.8rem;text-decoration:none">
                    <?= svgIcon('download', 13) ?> Download
                  </a>
                <?php else: ?>
                  <span class="text-muted" style="font-size:0.82rem">—</span>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- 5. Audit Trail & History -->
    <?php if (!empty($kycHistory)): ?>
    <div class="card mb-24">
      <div class="card-header" style="background:var(--surface-2)">
        <div class="card-title" style="font-weight:700">📜 KYC Audit History</div>
      </div>
      <div class="card-body" style="padding:0">
        <table class="data-table" style="font-size:0.84rem">
          <thead>
            <tr>
              <th>Date / Time</th>
              <th>Action</th>
              <th>Actor</th>
              <th>Status Transition</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($kycHistory as $h): ?>
            <tr>
              <td class="font-mono text-muted"><?= fmtDateTime($h['created_at']) ?></td>
              <td class="font-600"><?= e($h['action_title']) ?></td>
              <td><?= e($h['actor_name'] ?: 'System') ?> (<?= e($h['action_role']) ?>)</td>
              <td>
                <span class="badge <?= $h['to_status'] === 'Approved' ? 'badge-success' : ($h['to_status'] === 'Rejected' ? 'badge-danger' : 'badge-warning') ?>">
                  <?= e($h['to_status']) ?>
                </span>
              </td>
              <td><?= e($h['details'] ?: '—') ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>

  <?php else: ?>
    <!-- Empty State: No KYC on file -->
    <div class="card" style="padding:48px 24px;text-align:center;border:1px dashed var(--border);border-radius:var(--radius-lg);background:var(--surface-1)">
      <div style="width:64px;height:64px;margin:0 auto 16px;border-radius:50%;background:rgba(15,76,129,0.08);color:var(--accent);display:flex;align-items:center;justify-content:center;font-size:28px">
        📋
      </div>
      <h3 style="font-size:1.15rem;font-weight:700;margin-bottom:8px;color:var(--text-primary)">No KYC Application on File</h3>
      <p style="font-size:0.9rem;color:var(--text-muted);max-width:480px;margin:0 auto 20px;line-height:1.5">
        A compliance KYC application has not been submitted for <strong><?= e($partner['name']) ?></strong> yet.
        You can initiate and complete their KYC application now.
      </p>
      <a href="<?= APP_URL ?>/?page=kyc&action=new&partner_id=<?= $partner['id'] ?>" class="btn btn-primary" style="display:inline-flex;align-items:center;gap:8px">
        <?= svgIcon('plus', 16) ?> Start KYC Application for <?= e($partner['name']) ?>
      </a>
    </div>
  <?php endif; ?>
</div>

<style>
.partner-tab-btn {
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  margin-bottom: -2px;
  padding: 10px 18px;
  font-size: 0.92rem;
  font-weight: 600;
  color: var(--text-muted);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s ease;
}
.partner-tab-btn:hover {
  color: var(--text-primary);
  background: var(--surface-2);
  border-radius: var(--radius-sm) var(--radius-sm) 0 0;
}
.partner-tab-btn.active {
  color: var(--accent);
  border-bottom-color: var(--accent);
  font-weight: 700;
}
</style>

<script>
function switchPartnerTab(tab) {
  const overviewPane = document.getElementById('partnerTabOverview');
  const kycPane = document.getElementById('partnerTabKyc');
  const btnOverview = document.getElementById('tabBtnOverview');
  const btnKyc = document.getElementById('tabBtnKyc');

  if (tab === 'kyc') {
    if (overviewPane) overviewPane.style.display = 'none';
    if (kycPane) kycPane.style.display = 'block';
    if (btnOverview) btnOverview.classList.remove('active');
    if (btnKyc) btnKyc.classList.add('active');
    history.replaceState(null, null, '#kyc');
  } else {
    if (overviewPane) overviewPane.style.display = 'block';
    if (kycPane) kycPane.style.display = 'none';
    if (btnOverview) btnOverview.classList.add('active');
    if (btnKyc) btnKyc.classList.remove('active');
    history.replaceState(null, null, '#overview');
  }
}

// Auto open KYC tab if URL has #kyc or ?tab=kyc
document.addEventListener('DOMContentLoaded', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const hash = window.location.hash;
  if (hash === '#kyc' || urlParams.get('tab') === 'kyc') {
    switchPartnerTab('kyc');
  }
});
</script>
