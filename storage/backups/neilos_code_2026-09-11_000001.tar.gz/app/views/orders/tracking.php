<?php
// ============================================================
// Neilos Partner Portal — Order Tracking (Ongoing & Closed Tabs)
// ============================================================
$activeTab = $activeTab ?? 'ongoing';
$ongoingCount = $ongoingCount ?? 0;
$closedCount = $closedCount ?? 0;
$totalOrdersCount = $totalOrdersCount ?? ($ongoingCount + $closedCount);
$activeLiveCount = $activeLiveCount ?? 0;
$ongoingStatuses = $ongoingStatuses ?? ['Feasibility Review','Await Commercial Approval','Management Approval','Pending SOF','SOF Review','Installation','Testing','UAT'];
$closedStatuses  = ['Closed','Not Feasible','Cancelled'];
?>
<div class="page-header" style="margin-bottom:20px">
  <div class="page-header-left">
    <h1 class="page-title">Order Tracking</h1>
    <div class="page-subtitle">
      <?= $total ?> <?= $activeTab === 'closed' ? 'closed' : 'ongoing' ?> order(s) found &middot; <?= $activeTab === 'closed' ? 'Completed &amp; Live Services' : 'Delivery &amp; Fulfillment Pipeline' ?>
    </div>
  </div>
  <div class="page-header-actions">
    <a href="<?= APP_URL ?>/?page=new_order" class="btn btn-primary"><?= svgIcon('plus') ?> New Order</a>
    <a href="?<?= http_build_query(array_merge($_GET, ['page' => 'orders', 'tab' => $activeTab, 'export' => 'csv'])) ?>" class="btn btn-secondary"><?= svgIcon('download') ?> Export CSV</a>
  </div>
</div>

<!-- 1. KPI Summary Cards Grid -->
<div class="stats-grid mb-24" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:16px;margin-bottom:20px">
  <!-- Total Orders -->
  <div class="stat-card" style="padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);display:flex;align-items:center;gap:14px">
    <div class="stat-icon blue" style="width:44px;height:44px;border-radius:10px;background:rgba(15,76,129,0.1);color:var(--accent);display:flex;align-items:center;justify-content:center">
      <?= svgIcon('document', 22) ?>
    </div>
    <div class="stat-info">
      <div class="stat-value" style="font-size:1.5rem;font-weight:700;line-height:1.2"><?= $totalOrdersCount ?></div>
      <div class="stat-label" style="font-size:0.82rem;color:var(--text-secondary)">Total Orders</div>
    </div>
  </div>

  <!-- Ongoing Orders Card (Clickable tab switch) -->
  <a href="?<?= http_build_query(array_merge($_GET, ['page' => 'orders', 'tab' => 'ongoing', 'p' => 1, 'status' => '', 'active_filter' => ''])) ?>"
     class="stat-card" style="padding:16px;background:var(--surface);border:1px solid <?= $activeTab === 'ongoing' ? 'var(--warning)' : 'var(--border)' ?>;border-radius:var(--radius);display:flex;align-items:center;gap:14px;text-decoration:none;color:inherit;cursor:pointer;transition:transform 0.15s, border-color 0.15s">
    <div class="stat-icon yellow" style="width:44px;height:44px;border-radius:10px;background:rgba(217,119,6,0.1);color:var(--warning);display:flex;align-items:center;justify-content:center">
      <?= svgIcon('clock', 22) ?>
    </div>
    <div class="stat-info">
      <div class="stat-value" style="font-size:1.5rem;font-weight:700;line-height:1.2;color:#d97706"><?= $ongoingCount ?></div>
      <div class="stat-label" style="font-size:0.82rem;color:var(--text-secondary)">Ongoing Orders</div>
    </div>
  </a>

  <!-- Closed Orders Card (Clickable tab switch) -->
  <a href="?<?= http_build_query(array_merge($_GET, ['page' => 'orders', 'tab' => 'closed', 'p' => 1, 'status' => ''])) ?>"
     class="stat-card" style="padding:16px;background:var(--surface);border:1px solid <?= $activeTab === 'closed' ? 'var(--success)' : 'var(--border)' ?>;border-radius:var(--radius);display:flex;align-items:center;gap:14px;text-decoration:none;color:inherit;cursor:pointer;transition:transform 0.15s, border-color 0.15s">
    <div class="stat-icon green" style="width:44px;height:44px;border-radius:10px;background:rgba(5,150,105,0.1);color:var(--success);display:flex;align-items:center;justify-content:center">
      <?= svgIcon('check-circle', 22) ?>
    </div>
    <div class="stat-info">
      <div class="stat-value" style="font-size:1.5rem;font-weight:700;line-height:1.2;color:#059669"><?= $closedCount ?></div>
      <div class="stat-label" style="font-size:0.82rem;color:var(--text-secondary)">Closed Orders</div>
    </div>
  </a>

  <!-- Active Live Services -->
  <a href="?<?= http_build_query(array_merge($_GET, ['page' => 'orders', 'tab' => 'closed', 'active_filter' => '1', 'p' => 1, 'status' => ''])) ?>"
     class="stat-card" style="padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);display:flex;align-items:center;gap:14px;text-decoration:none;color:inherit;cursor:pointer;transition:transform 0.15s, border-color 0.15s"
     title="View Closed Orders with active live billing">
    <div class="stat-icon teal" style="width:44px;height:44px;border-radius:10px;background:rgba(13,148,136,0.1);color:#0d9488;display:flex;align-items:center;justify-content:center">
      <?= svgIcon('shield-check', 22) ?>
    </div>
    <div class="stat-info">
      <div class="stat-value" style="font-size:1.5rem;font-weight:700;line-height:1.2;color:#0d9488"><?= $activeLiveCount ?></div>
      <div class="stat-label" style="font-size:0.82rem;color:var(--text-secondary)">Active Live Services</div>
    </div>
  </a>
</div>

<!-- 2. Primary Tabs: Ongoing Orders vs Closed Orders -->
<div class="order-tabs-container" style="margin-bottom:20px;border-bottom:2px solid var(--border);display:flex;gap:10px">
  <a href="?<?= http_build_query(array_merge($_GET, ['page' => 'orders', 'tab' => 'ongoing', 'p' => 1, 'status' => '', 'active_filter' => ''])) ?>"
     class="order-tab-btn <?= $activeTab === 'ongoing' ? 'active' : '' ?>">
    <?= svgIcon('clock', 16) ?> Ongoing Orders
    <span class="badge badge-warning" style="margin-left:8px;font-size:0.75rem;padding:3px 8px">
      <?= $ongoingCount ?>
    </span>
  </a>
  <a href="?<?= http_build_query(array_merge($_GET, ['page' => 'orders', 'tab' => 'closed', 'p' => 1, 'status' => ''])) ?>"
     class="order-tab-btn <?= $activeTab === 'closed' ? 'active' : '' ?>">
    <?= svgIcon('check-circle', 16) ?> Closed Orders
    <span class="badge badge-success" style="margin-left:8px;font-size:0.75rem;padding:3px 8px">
      <?= $closedCount ?>
    </span>
  </a>
</div>

<!-- 3. Filter Card (Tab-Aware) -->
<div class="card mb-20" style="margin-bottom:20px">
  <div class="card-body" style="padding:16px">
    <form method="GET" action="<?= APP_URL ?>/" style="display:flex;flex-direction:column;gap:12px">
      <input type="hidden" name="page" value="orders">
      <input type="hidden" name="tab" value="<?= e($activeTab) ?>">

      <!-- Row 1: Period Presets + Custom Date Range -->
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;padding-bottom:12px;border-bottom:1px solid var(--border)">
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:0.82rem;font-weight:600;color:var(--text-secondary);margin-right:4px">Period:</span>
          <?php
            $presets = [
              'all'        => 'All Time',
              'today'      => 'Today',
              'this_month' => 'This Month',
              'last_month' => 'Last Month',
              'this_year'  => 'This Year',
            ];
            $curPreset = $filterPreset ?: 'all';
          ?>
          <?php foreach ($presets as $pKey => $pLabel): ?>
            <?php
              $pParams = $_GET;
              $pParams['page'] = 'orders';
              $pParams['tab'] = $activeTab;
              $pParams['preset'] = $pKey;
              unset($pParams['start_date'], $pParams['end_date'], $pParams['p']);
            ?>
            <a href="?<?= http_build_query($pParams) ?>"
               class="btn btn-sm <?= ($curPreset === $pKey && !$filterStart && !$filterEnd) ? 'btn-primary' : 'btn-secondary' ?>"
               style="font-size:0.78rem;padding:4px 10px">
              <?= $pLabel ?>
            </a>
          <?php endforeach; ?>
        </div>

        <!-- Custom Date Range -->
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <span style="font-size:0.82rem;color:var(--text-secondary)">Custom:</span>
          <input type="date" name="start_date" class="form-control" style="font-size:0.8rem;padding:4px 8px;width:auto;height:32px" value="<?= e($filterStart) ?>" placeholder="From">
          <span style="color:var(--text-muted)">to</span>
          <input type="date" name="end_date" class="form-control" style="font-size:0.8rem;padding:4px 8px;width:auto;height:32px" value="<?= e($filterEnd) ?>" placeholder="To">
        </div>
      </div>

      <!-- Row 2: Search & Column Filters -->
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
        <!-- Search Box -->
        <div style="flex:2;min-width:240px">
          <div class="search-box" style="width:100%">
            <?= svgIcon('search') ?>
            <input type="text" name="q" placeholder="Search order #, customer, circuit..." value="<?= e($filterSearch) ?>">
          </div>
        </div>

        <!-- Tab-Aware Status Filter -->
        <div style="flex:1;min-width:140px">
          <select name="status" class="form-control" style="font-size:0.85rem">
            <?php if ($activeTab === 'ongoing'): ?>
              <option value="">All Ongoing Statuses</option>
              <?php foreach($ongoingStatuses as $s): ?>
              <option value="<?= e($s) ?>" <?= $filterStatus === $s ? 'selected' : '' ?>><?= e($s) ?></option>
              <?php endforeach; ?>
            <?php else: ?>
              <option value="">All Closed Statuses</option>
              <?php foreach($closedStatuses as $s): ?>
              <option value="<?= e($s) ?>" <?= $filterStatus === $s ? 'selected' : '' ?>><?= e($s) ?></option>
              <?php endforeach; ?>
            <?php endif; ?>
          </select>
        </div>

        <!-- Service Type Filter -->
        <div style="flex:1;min-width:140px">
          <select name="service_type" class="form-control" style="font-size:0.85rem">
            <option value="">All Service Types</option>
            <?php foreach($serviceTypes as $s): ?>
            <option value="<?= e($s) ?>" <?= $filterService === $s ? 'selected' : '' ?>><?= e($s) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <?php if ($activeTab === 'closed' && (isAdmin() || isManagement())): ?>
        <!-- Active / Inactive Filter (Closed Orders Only) -->
        <div style="flex:1;min-width:140px">
          <select name="active_filter" class="form-control" style="font-size:0.85rem">
            <option value="">All (Active + Inactive)</option>
            <option value="1" <?= ($filterActive === '1') ? 'selected' : '' ?>>Active Only (Live)</option>
            <option value="0" <?= ($filterActive === '0') ? 'selected' : '' ?>>Inactive Only</option>
          </select>
        </div>
        <?php endif; ?>

        <button type="submit" class="btn btn-primary btn-sm" style="height:38px;padding:0 16px">
          <?= svgIcon('filter') ?> Filter
        </button>
        <?php if ($filterStart !== '' || $filterEnd !== '' || ($filterPreset !== '' && $filterPreset !== 'all') || $filterSearch !== '' || $filterStatus !== '' || $filterService !== '' || ($activeTab === 'closed' && $filterActive !== '')): ?>
        <a href="<?= APP_URL ?>/?page=orders&tab=<?= e($activeTab) ?>" class="btn btn-secondary btn-sm" style="height:38px;padding:0 14px;display:inline-flex;align-items:center">
          Clear
        </a>
        <?php endif; ?>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Order #</th>
          <?php if (!isPartnerUser()): ?><th>Partner</th><?php endif; ?>
          <th>Customer</th>
          <th>Service Type</th>
          <th>Assigned KAM</th>
          <th><?= $activeTab === 'ongoing' ? 'Current Stage' : 'Status' ?></th>
          <?php if (!isPartnerUser()): ?>
          <th>NRC</th>
          <th>MRC</th>
          <?php endif; ?>
          <?php if ($activeTab === 'closed'): ?>
          <th>Billing Date</th>
          <th>Active</th>
          <?php endif; ?>
          <th>Created</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($orders)): ?>
        <tr>
          <td colspan="<?= isPartnerUser() ? ($activeTab === 'closed' ? 10 : 8) : ($activeTab === 'closed' ? 12 : 10) ?>">
            <?php if ($activeTab === 'ongoing'): ?>
            <div class="empty-state" style="padding:40px 20px;text-align:center">
              <div style="color:var(--warning);margin-bottom:12px"><?= svgIcon('clock', 40) ?></div>
              <div class="empty-state-title" style="font-size:1.1rem;font-weight:600;margin-bottom:6px">No Ongoing Orders</div>
              <div class="empty-state-text" style="color:var(--text-secondary);font-size:0.88rem;max-width:420px;margin:0 auto">
                There are currently no active orders in the delivery or fulfillment pipeline matching your filter criteria.
              </div>
              <div style="margin-top:16px">
                <a href="<?= APP_URL ?>/?page=new_order" class="btn btn-primary btn-sm">
                  <?= svgIcon('plus') ?> Create New Order
                </a>
              </div>
            </div>
            <?php else: ?>
            <div class="empty-state" style="padding:40px 20px;text-align:center">
              <div style="color:var(--success);margin-bottom:12px"><?= svgIcon('check-circle', 40) ?></div>
              <div class="empty-state-title" style="font-size:1.1rem;font-weight:600;margin-bottom:6px">No Closed Orders Found</div>
              <div class="empty-state-text" style="color:var(--text-secondary);font-size:0.88rem;max-width:420px;margin:0 auto">
                No completed or closed orders match your current filters or date range.
              </div>
            </div>
            <?php endif; ?>
          </td>
        </tr>
        <?php else: ?>
        <?php foreach($orders as $o): ?>
        <?php
          $stVal = !empty($o['service_type']) ? $o['service_type'] : '';
          if (!$stVal) {
              if (!empty($o['fttx_package'])) {
                  $stVal = 'FTTH';
              } elseif (!empty($o['aggregate_capacity'])) {
                  $stVal = 'Layer 2 ( last mile)';
              } elseif (!empty($o['bandwidth'])) {
                  $stVal = 'BIA (Broadband Internet Access)';
              } elseif ((float)($o['remote_hands_nrc_usd'] ?? 0) > 0 || (float)($o['base_nrc_usd'] ?? 0) == 80000) {
                  $stVal = 'Remote Hands Only';
              } else {
                  $stVal = 'Not specified';
              }
          }
          // An order is active ONLY when Closed and has a billing date
          $isActive = isOrderActive($o);
          $billingDate = $o['billing_start_date'] ?? null;
        ?>
        <tr>
          <td>
            <a href="<?= APP_URL ?>/?page=order_detail&id=<?= $o['id'] ?>" class="font-600" style="color:var(--primary)">
              <?= e($o['order_number']) ?>
            </a>
          </td>
          <?php if (!isPartnerUser()): ?>
          <td class="font-sm"><?= e($o['partner_name']) ?></td>
          <?php endif; ?>
          <td>
            <div style="font-weight:500"><?= e($o['customer_name']) ?></div>
            <?php if (!empty($o['circuit_id'])): ?>
            <div class="font-sm text-muted" style="font-size:0.75rem">CID: <?= e($o['circuit_id']) ?></div>
            <?php endif; ?>
          </td>
          <td><span class="badge badge-primary"><?= e($stVal) ?></span></td>
          <td class="font-sm"><?= e($o['assigned_kam_name'] ?: '—') ?></td>
          <td><span class="badge <?= orderStatusClass($o['status']) ?>"><?= e($o['status']) ?></span></td>
          <?php if (!isPartnerUser()): ?>
          <td class="font-sm">TZS <?= money($o['total_nrc_incl_vat']) ?></td>
          <td class="font-sm"><?= $o['total_mrc_incl_vat'] > 0 ? e($o['mrc_currency']).' '.money($o['total_mrc_incl_vat']) : '—' ?></td>
          <?php endif; ?>
          <?php if ($activeTab === 'closed'): ?>
          <!-- Billing Date column -->
          <td class="font-sm">
            <?php if ($billingDate): ?>
              <span style="color:var(--text-primary);font-weight:500"><?= fmtDate($billingDate) ?></span>
            <?php else: ?>
              <span class="text-muted">—</span>
            <?php endif; ?>
          </td>
          <!-- Active/Inactive column -->
          <td>
            <?php if ($isActive): ?>
              <span class="badge badge-success" style="display:inline-flex;align-items:center;gap:4px">
                <span style="width:6px;height:6px;border-radius:50%;background:currentColor;display:inline-block"></span>
                Active
              </span>
            <?php else: ?>
              <span class="badge badge-secondary" style="display:inline-flex;align-items:center;gap:4px">
                <span style="width:6px;height:6px;border-radius:50%;background:currentColor;display:inline-block"></span>
                Inactive
              </span>
            <?php endif; ?>
          </td>
          <?php endif; ?>
          <td class="text-muted font-sm"><?= fmtDate($o['created_at']) ?></td>
          <td>
            <div class="actions">
              <a href="<?= APP_URL ?>/?page=order_detail&id=<?= $o['id'] ?>" class="btn btn-secondary btn-sm btn-icon" title="View Order"><?= svgIcon('eye') ?></a>
              <?php if (isAdmin() || hasRole('Management')): ?>
              <form method="POST" action="<?= APP_URL ?>/?page=orders&action=delete" style="display:inline" data-confirm="Permanently delete order <?= e($o['order_number']) ?>?">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                <input type="hidden" name="id" value="<?= $o['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete Order"><?= svgIcon('trash') ?></button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($pages > 1): ?>
  <div class="card-footer" style="display:flex;gap:8px;align-items:center;justify-content:center">
    <?php for($i=1;$i<=$pages;$i++): ?>
    <a href="?<?= http_build_query(array_merge($_GET, ['p'=>$i, 'tab'=>$activeTab])) ?>" class="btn <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?> btn-sm"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<style>
.order-tabs-container {
  border-bottom: 2px solid var(--border);
  display: flex;
  gap: 10px;
}
.order-tab-btn {
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  margin-bottom: -2px;
  padding: 12px 20px;
  font-size: 0.95rem;
  font-weight: 600;
  color: var(--text-muted);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  text-decoration: none;
  transition: all 0.2s ease;
}
.order-tab-btn:hover {
  color: var(--text-primary);
  background: var(--surface-2);
  border-radius: var(--radius-sm) var(--radius-sm) 0 0;
  text-decoration: none;
}
.order-tab-btn.active {
  color: var(--accent);
  border-bottom-color: var(--accent);
  font-weight: 700;
}
.stat-card:hover {
  transform: translateY(-2px);
}
</style>
